GROW COMPUTING — WEEKS 7–8

GET STARTED
Extract the complete ZIP. Keep the folders together and open
GROW_Computing_Weeks_07_08_Start_Here.html in your browser.
The hub links to each lesson, booklet, teacher guide and Scratch file.

THE TWO LESSONS
Week 7: Add one challenge — create one feature that changes how the game is played.
Week 8: Test and improve — run five checks, repair one cause and retest.

EVERY WEEK INCLUDES
An interactive HTML lesson; editable PowerPoint and slides PDF;
Main task, Step by step and Challenge booklets in Word and PDF;
a teacher guide with answers, support and evidence checks in Word and PDF;
Scratch access files and a separate teacher model.
Both weeks include an intentionally faulty bug-hunt project.
Planning contains the two-week completion of the original scheme.

GROW CHASSIS: ONE 40-MINUTE LESSON
Arrival 0–3 / Starter 3–6 / I Do 6–11 / We Do 11–18 /
I Do 2 18–21 / We Do 2 · Task 21–25 / Independent Task 25–35 /
Exit 35–40. Within Independent Task, allow 32–35 for an individual
demonstration and pupil voice: “What I said, and what it changed”.

WEEK 7 BEHAVIOUR
The Hazard sprite goes to one end of the middle corridor, then glides
between two points inside forever. The contact rule belongs to Player:
forever, if touching Hazard? then go to the safe start. A collectible is
the alternative: Star shows at the flag and hides on contact with Player.
No score variables. Scoring is the separate continuation unit AQA 122058,
and building it now would spend that unit's assessed construction early.

WEEK 8 BEHAVIOUR
W08_Bug_Hunt.sb3 carries three faults on purpose, one for each of three
checks. Down arrow uses change y by 10, so Player moves up. The wall check
sits under the green flag with no forever, so it runs once and never again.
The win script has no empty say, so the old message survives a restart.
The finish and feature checks pass: passing checks are results too, and they
are what a repair must not break. W08_Teacher_Model.sb3 is the repaired game.

SCRATCH FILES AND SAVING
Use the pupil’s own saved project first. Recovery files supply only earlier
work. They do not establish authorship of inherited content. Observe the pupil
creating this week’s new sprite, rule or repair.
Teacher_Only holds answers and complete demonstration models.
In Scratch choose File > Load from your computer to open an .sb3 file.
Save pupil projects as W07_Challenge.sb3, then W08_Final.sb3 in the school
folder. Reopen and check after saving.
HTML responses can be downloaded as a text file or printed before closing.
The HTML lessons use no external assets. The Scratch website needs internet;
the installed Scratch app can load these projects offline.

AQA
Unit 71638: Programming with Scratch (unit 6), Level One.
https://www.aqa.org.uk/programmes/unit-award-scheme/unit-details?unit=71638
Current unit checked 9 September 2026. These lessons cover outcomes 5 and 6.
Week 8 reviews all six outcomes. The school UAS lead records individually
demonstrated outcomes on summary sheets. A partly completed game receives a
recorded next step rather than automatic unit completion.

CHECKS
Every Scratch project in this pack was validated against the official
Scratch 3 project schema. Lesson JavaScript was syntax-checked and the
interactive lessons were rendered and driven in a headless browser: all
eight stages, both task routes, every model button and, in Week 8, all five
checks before and after each repair. Documents and slides were generated and
converted in one pass. A live Scratch-editor run was not available in this
session: open each project on the classroom device before teaching.
