# Town Life Gold Master v1.0 originality and safety notes

## Original identity

Town Life is an original Made by Matt top-down town-life and emergent-roleplay game. It does not use the names, logos, map, characters, code, audio, textures, models, UI assets or story content of Brookhaven, Roblox or another commercial title.

The project uses broad genre ideas—homes, vehicles, civic jobs, town businesses and roleplay—while its Northstar setting, named citizens, systems, fiction and procedural presentation remain distinct.

## Local-first privacy boundary

The Gold Master contains no:

- account or login system;
- public or private user chat;
- analytics or advertising;
- tracking pixels;
- remote database;
- network multiplayer;
- HTTP API calls;
- external asset requests.

Progress stays in the browser when storage is available. The player can export a versioned JSON backup. Denied storage degrades to session or volatile memory rather than silently failing.

## Fictional crime and police mechanics

The Mischief role, Civic Bank safe, police heat, fictional vault bonds and Exchange conversion are abstract game systems. They do not provide real security bypass, police evasion, money-laundering or criminal instructions.

- The safe uses random angular game targets and synthetic sound cues, not real lock construction.
- “Vault bonds” are fictional inventory currency.
- CCTV power cutting is a bounded coordinate interaction inside a fictional building, not an electrical or security tutorial.
- Police line of sight is transparent arcade geometry and a game state machine.
- Exchange conversion is a delayed economy mechanic with no real financial process.

## Electrical-system boundary

The plot grid is a simplified educational game simulation. Device wattages and source limits are calibrated for gameplay. It is not electrical-design software, wiring guidance, safety training or an instruction to work on mains systems.

The Wire Circuits tool assigns virtual props to abstract software branches. It does not depict real conductors, voltages, protective devices, regulations or safe isolation procedures.

## Healthcare, driving and civic boundaries

Paramedic timing, vehicle dynamics, weather, governance and town economy are arcade simulations. They are not:

- medical advice or clinical training;
- driving instruction or a vehicle-dynamics certification tool;
- legal, policing or public-administration guidance;
- investment, tax or financial advice.

## Classroom and comfort considerations

Town Life includes:

- optional reduced motion;
- high contrast;
- optional police vision cones;
- optional weather and audio;
- keyboard and touch controls;
- local-only play without strangers or user-generated chat.

The Mischief role is optional. Resident, Courier, Builder, Paramedic, Officer and Mayor loops remain available. Staff should still apply normal safeguarding, curriculum and behaviour judgement for their setting.

## Generative and user content

The game does not upload or publish user content. Player names and home layouts remain local unless the player deliberately exports a JSON save.
