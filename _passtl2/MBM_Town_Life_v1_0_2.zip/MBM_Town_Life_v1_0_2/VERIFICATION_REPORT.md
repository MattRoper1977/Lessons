# Town Life Gold v1.0.1 — TL-1 fix and recertification report

Generated: **2026-08-18T10:55:36.668071Z**  
Candidate status: **HELD — not published, not in a repository, no PR, no merge, no shelf/catalogue work**

## Overall result

The held candidate reports **99/99 distinct assertions passed/attempted** in executed injected Chromium contexts. Assertion names are unique; every attempted check has non-empty observed evidence; one suite-level runtime/console assertion recorded zero unexpected errors. The 10/10 hardening file is explicitly non-additive.

G1–G12 status at report generation: **12/12 passed**. D3 remains an explicit open real-origin gate even when the package-integrity gates are green.

No game design, balance, economy number, role permission, content name, Civic Bank flow, Washworks flow, Sylvia flow or Mischief behaviour was changed. No Git repository was created; required phase checkpoints are retained as `_tl1/` evidence artefacts instead of commits.

## Phase 0 — corrected BASE measurements

Byte counts below come from `wc -c` or `stat`. Character counts are labelled separately and come from UTF-8 `wc -m` or decoded Unicode length where applicable.

| Gate | Measurement | Expected | Measured | Result |
|---|---|---|---|---|
| B1 | `sha256sum -c CHECKSUMS.sha256` | 24/24 entries pass | 24/24 entries passed | **PASS** |
| B2 | HTML size / ending | 304,742 UTF-8 bytes; `</html>` + LF | 304,742 UTF-8 bytes / 304,462 characters; expected ending present | **PASS** |
| B3 | Script blocks | 1 | 1 | **PASS** |
| B4 | Inline script size | 265,585 UTF-8 bytes / 265,340 characters | 265,585 UTF-8 bytes / 265,340 characters | **PASS** |
| B5 | Inline script SHA-256 | `5d8389e…93200` | `5d8389e5e1669c17aa8186ce4378bb587ee1f19a733c4ae01784334a91693200` | **PASS** |
| B6 | `node --check` | exit 0 | exit 0 | **PASS** |
| B7 | URL tokens | 0 | 0 `http://`; 0 `https://` | **PASS** |
| B8 | HTML IDs | 164, all unique | 164 total / 164 unique / 0 duplicates | **PASS** |
| B9 | Viewport | exact required content; no restrictions | `width=device-width, initial-scale=1, viewport-fit=cover`; maximum-scale 0; user-scalable=no 0 | **PASS** |
| B10 | Version / save schema | 1.0.0 / 10 | 1.0.0 / 10 | **PASS** |
| B11 | Storage key contract | 2 write/remove; current + 9 legacy reads | measured statically at BASE and later by API instrumentation | **PASS** |

BASE HTML SHA-256: `06beeed09d469ca621dd7d1ef7ecba24fd05a98f9a6a692b16fdb3dace21d15f`  
BASE inline-script SHA-256: `5d8389e5e1669c17aa8186ce4378bb587ee1f19a733c4ae01784334a91693200`

## Candidate identity

- HTML: **304,742 UTF-8 bytes / 304,462 Unicode characters**; SHA-256 `7d31850989bd36849be29b2e53e72e1906ff4597ab62e81e9225fa95cae9afd2`.
- Inline script: **265,585 UTF-8 bytes / 265,340 Unicode characters**; SHA-256 `0a6b44170737dc71c8d04a9877eee62502617257489f5b924fe2d3dbbdca3bd1`.
- Executable diff from BASE: two equal-length version-marker substitutions only (`1.0.0` → `1.0.1`).

## D1 — inflated assertion count

**Reproduced: YES. Fixed: YES.**

Before: 100 result records, 91 distinct names, 10 occurrences of `No runtime or console errors`, 13 empty/missing detail objects and a separately advertised 11-check hardening total. After: **99/99 distinct assertions passed/attempted**, 99 unique names, one suite-level runtime assertion, zero empty details and a 10/10 non-additive hardening view. Two real-origin groups are recorded separately as UNEXECUTED and excluded from the denominator.

The documentation sweep removed the old advertised aggregate and uses the single distinct total. Incidental digit sequences inside raw measurements, hashes or immutable BASE evidence are not assertion-count claims and were not corrupted to alter their bytes.

## D2 — Auto render budget

**Reproduced: NO. Fixed: NOT REQUIRED. Final status: NOT-A-DEFECT.**

The game ships with **Auto adaptive** as the default, initially at High (`forced = null`).

| Profile | Pack single run | Five-run median | Full accepted spread | Accepted run-order fps | After fix |
|---|---:|---:|---:|---|---|
| Auto | 39.98 | 55.08 | 52.78–56.84 (Δ 4.06) | 54.42, 56.84, 56.24, 52.78, 55.08 | N/A — no fix |
| High | 48.04 | 57.16 | 54.75–57.84 (Δ 3.09) | 55.83, 54.75, 57.16, 57.84, 57.16 | N/A — no fix |
| Balanced | 53.30 | 58.29 | 55.43–58.91 (Δ 3.48) | 58.29, 58.91, 58.41, 55.43, 57.01 | N/A — no fix |
| Performance | 54.20 | 57.13 | 55.21–58.32 (Δ 3.11) | 57.60, 58.32, 56.82, 57.13, 55.21 | N/A — no fix |

Auto median was **55.08 fps**. The slowest fixed median was **Performance at 57.13 fps**. Auto was **-2.05 fps** relative to it. The much wider within-profile spreads show that the pack's one-run ordering did not reproduce as a stable Auto regression. Under Amendment E2, controller instrumentation and a code fix were skipped; therefore no mechanism is claimed and no after-fix dataset exists.

## D3 — no real-origin execution

**Reproduced: YES. Fixed: NO. Status: UNPROVEN-ON-REAL-ORIGIN.**

The existing pack used `page.set_content`, not a real origin. The authorised ladder was attempted and both browser navigations were blocked by managed Chromium `URLBlocklist: ["*"]` before document commit.

| Test | Route | Executed document | Exact resolved origin string | Result |
|---|---|---:|---|---|
| real file URL | `file:///mnt/data/TL1_RESUME_2026-08-18/source/MBM_Town_Life_GOLD_v1_0_2026-08-17/MBM_Town_Life_GOLD_v1_0.html?qa` | no document commit | **none** | `net::ERR_BLOCKED_BY_ADMINISTRATOR` |
| local static HTTP server on 127.0.0.1 | `http://127.0.0.1:47461/MBM_Town_Life_GOLD_v1_0.html?qa` | no document commit | **none** | `net::ERR_BLOCKED_BY_ADMINISTRATOR` |
| BASE storage API instrumentation | `about:blank?qa` + injected content | executed | `null` | supplemental key-contract evidence only |
| Candidate storage API instrumentation | `about:blank?qa` + injected content | executed | `null` | supplemental key-contract evidence only |
| v1.0 → v1.0.1 save compatibility | `about:blank?qa` + injected content | executed | `null` | schema/data proof only |
| Hardening storage fallbacks | `about:blank?qa` + injected content | executed | `null` | not a real-origin pass |

The loopback server was independently reachable and returned HTTP 200 with the correct 304,742-byte body. Because neither browser document committed, zero real-origin hardening/startup/accessibility/storage assertions executed and none were passed by substitution.

## D4 — roof-mask cache claim

**Reproduced: YES. Fixed: YES in the harness claim; rendering code unchanged.**

Opening snapshot: roof-mask cache **0**, roof-base cache **8**. Civic Bank cutaway: immediate cache 1; after 30 frames cache 11 with 21 hits; after 150 frames cache 11 with **142 hits**, 12 misses and 12 sets. Classification: **scene-dependent and actively read**. The repaired assertion now drives a cutaway scene and proves population plus repeated hits.

## D5 — legacy save provenance

**Runtime change: NO. Documentation correction: YES.**

| Legacy key | Verdict | Reachable | Basis |
|---|---|---:|---|
| `mbm_town_life_v09` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v08` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v07` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v06` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v05` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v04` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v03` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v02` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |
| `mbm_town_life_v01` | **PARTIAL** | yes | Generic field-compatible normaliser; no key-specific contract or genuine fixture |

The migration assertion uses a **synthetic in-memory fixture** (`profile = Legacy`, `cash = 777`) through `MBMTownLifeQA.migrate`; it does not use a genuine earlier build/save artefact. It proves the generic code path, not an installed-base history. Release wording now describes a field-compatible bridge and discloses synthetic provenance.

## Storage key contract — BASE and candidate

API instrumentation covered boot, save, load and synthetic legacy migration in both builds.

- Keys written or removed at BASE: `['__mbm_probe', 'mbm_town_life_v10']`
- Keys written or removed at candidate: `['__mbm_probe', 'mbm_town_life_v10']`
- Keys read at BASE: `['mbm_town_life_v01', 'mbm_town_life_v02', 'mbm_town_life_v03', 'mbm_town_life_v04', 'mbm_town_life_v05', 'mbm_town_life_v06', 'mbm_town_life_v07', 'mbm_town_life_v08', 'mbm_town_life_v09', 'mbm_town_life_v10']`
- Keys read at candidate: `['mbm_town_life_v01', 'mbm_town_life_v02', 'mbm_town_life_v03', 'mbm_town_life_v04', 'mbm_town_life_v05', 'mbm_town_life_v06', 'mbm_town_life_v07', 'mbm_town_life_v08', 'mbm_town_life_v09', 'mbm_town_life_v10']`
- Other keys observed: **none**
- Instrumentation origin: serialized `location.origin` **`null`** at `about:blank?qa`; supplemental only, not a D3 pass.

## Save compatibility proof

A v1.0 runtime wrote a schema-10 save, and a fresh v1.0.1 candidate loaded it. Profile `TL1 Compatibility`, Mayor role, claimed modern plot, five placed props, four Tier-4 businesses, three-driver fleet with nine runs, and the tested generator/solar/battery utility graph all survived exactly. The candidate retained schema 10 and updated runtime version to 1.0.1.

The first exploratory comparison is retained but rejected because active town time legitimately accrued income and consumed generator fuel between contexts. The accepted test freezes time and synchronises the utility timestamp before comparing preservation.

## Phase 2 — THROTTLED PROXIES, not devices

Each is one fresh Auto maximum-scene run after 240 warm-up frames, measuring 240 frames under CDP CPU throttling.

| Viewport | Coarse pointer observed | CPU throttle | Frames | Elapsed | Callback throughput | Final Auto budget |
|---|---:|---:|---:|---:|---:|---|
| 1440×900 | no | 4× | 240 | 20145.9 ms | **11.91 fps** | performance |
| 1440×900 | no | 6× | 240 | 33763.4 ms | **7.11 fps** | performance |
| 390×844 | yes | 4× | 240 | 8665.3 ms | **27.70 fps** | performance |
| 390×844 | yes | 6× | 240 | 14669.1 ms | **16.36 fps** | performance |

These numbers are constrained-browser proxies only. They are not Chromebook, Android, iOS or other physical-device measurements.

## Gates G1–G12

| Gate | Requirement | Result | Measured value |
|---|---|---:|---|
| G1 | node --check on inline script | **PASS** | node exit 0 |
| G2 | zero runtime network URL tokens | **PASS** | http 0; https 0 |
| G3 | single script, HTML ending and tag balance | **PASS** | scripts 1; ending True; tag balance 0 |
| G4 | unique HTML IDs | **PASS** | 164 IDs / 164 unique / 0 duplicate |
| G5 | candidate version 1.0.1 and schema 10 | **PASS** | version 1.0.1; schema 10 |
| G6 | v1.0 save compatibility | **PASS** | all 13 compatibility comparison fields passed |
| G7 | reduced-motion short circuits retained | **PASS** | camera trauma, drive look-ahead, speed zoom, follow lerp and interior alpha all short-circuited |
| G8 | storage key read/write sets unchanged | **PASS** | write/remove ['__mbm_probe', 'mbm_town_life_v10']; read ['mbm_town_life_v01', 'mbm_town_life_v02', 'mbm_town_life_v03', 'mbm_town_life_v04', 'mbm_town_life_v05', 'mbm_town_life_v06', 'mbm_town_life_v07', 'mbm_town_life_v08', 'mbm_town_life_v09', 'mbm_town_life_v10'] |
| G9 | Made by Matt brand intact | **PASS** | brand block byte-identical; SHA-256 `3fcd61c6618239265d62288563931afb0919563f7f0c0066cad73a2b9b1b66fd` |
| G10 | viewport byte-identical to BASE | **PASS** | `width=device-width, initial-scale=1, viewport-fit=cover`; restrictive tokens 0 |
| G11 | diff confined to authorised files | **PASS** | 185 changed/added records; 0 unauthorised; protected docs unchanged |
| G12 | fresh package checksums verify | **PASS** | exit 0; 196 entries checked |

## Files changed or added — line counts

Line counts compare the BASE package to the candidate. New evidence files have zero deleted lines. Binary values are labelled rather than invented.

| File | Status | Added | Deleted |
|---|---|---:|---:|
| `BROWSER_COMPATIBILITY_REPORT.md` | modified | +48 | −81 |
| `CHANGELOG.md` | modified | +21 | −6 |
| `CHECKSUMS.sha256` | modified | +184 | −12 |
| `GOLD_MASTER_RELEASE_NOTES.md` | modified | +14 | −11 |
| `MBM_Town_Life_GOLD_v1_0.html` | modified | +2 | −2 |
| `QUICK_START.txt` | modified | +18 | −3 |
| `README.md` | modified | +29 | −16 |
| `RELEASE_MANIFEST.json` | modified | +997 | −128 |
| `VERIFICATION_REPORT.md` | modified | +315 | −193 |
| `_tl1/D1_HARNESS_REPAIR/ALL_LITERAL_111_IN_NAMED_DOCS.txt` | added | +3 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_BASE_MEASUREMENTS.json` | added | +66 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_BEFORE_AFTER.json` | added | +91 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_CHECKSUMS.sha256` | added | +12 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_CHECKSUMS_VERIFY.txt` | added | +12 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_CURRENT_SUMMARY.log` | added | +17 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_EVENT_LOG.jsonl` | added | +22 | −0 |
| `_tl1/D1_HARNESS_REPAIR/D1_HARNESS_REPAIR.md` | added | +22 | −0 |
| `_tl1/D1_HARNESS_REPAIR/FINAL_HARNESS_RUN.log` | added | +8 | −0 |
| `_tl1/D1_HARNESS_REPAIR/FINAL_HARNESS_RUN_CURRENT.exit` | added | +1 | −0 |
| `_tl1/D1_HARNESS_REPAIR/FINAL_HARNESS_RUN_CURRENT.log` | added | +8 | −0 |
| `_tl1/D1_HARNESS_REPAIR/FINAL_HARNESS_RUN_EXIT.txt` | added | +1 | −0 |
| `_tl1/D1_HARNESS_REPAIR/FINAL_INLINE_SCRIPT.js` | added | +2720 | −0 |
| `_tl1/D1_HARNESS_REPAIR/OBSOLETE_111_CLAIMS.txt` | added | +0 | −0 |
| `_tl1/D2_REPRODUCTION/D2_CHECKSUMS.sha256` | added | +45 | −0 |
| `_tl1/D2_REPRODUCTION/D2_CHECKSUMS_VERIFY.txt` | added | +45 | −0 |
| `_tl1/D2_REPRODUCTION/D2_EVENT_LOG.jsonl` | added | +50 | −0 |
| `_tl1/D2_REPRODUCTION/D2_FIXED_REMAINING_PROGRESS.log` | added | +5 | −0 |
| `_tl1/D2_REPRODUCTION/D2_PERFORMANCE_PROGRESS.log` | added | +5 | −0 |
| `_tl1/D2_REPRODUCTION/D2_PROGRESS.log` | added | +5 | −0 |
| `_tl1/D2_REPRODUCTION/D2_REMAINING_PROGRESS.log` | added | +5 | −0 |
| `_tl1/D2_REPRODUCTION/D2_REPRODUCTION_RAW.json` | added | +143 | −0 |
| `_tl1/D2_REPRODUCTION/D2_REPRODUCTION_REPORT.md` | added | +14 | −0 |
| `_tl1/D2_REPRODUCTION/D2_REPRODUCTION_SUMMARY.json` | added | +842 | −0 |
| `_tl1/D2_REPRODUCTION/D2_REPRODUCTION_SUMMARY.pretty.json` | added | +842 | −0 |
| `_tl1/D2_REPRODUCTION/D2_RUNS.log` | added | +15 | −0 |
| `_tl1/D2_REPRODUCTION/D2_RUNS_ISOLATED.log` | added | +15 | −0 |
| `_tl1/D2_REPRODUCTION/PREFLIGHT_AUTO_0.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/SOURCE_HTML_AFTER.sha256` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/SOURCE_HTML_BEFORE.sha256` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/rejected/balanced_1_pipe_wait_timeout.json` | added | +270 | −0 |
| `_tl1/D2_REPRODUCTION/rejected/high_1_batch_teardown_timeout.json` | added | +270 | −0 |
| `_tl1/D2_REPRODUCTION/runs/auto_1.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/auto_2.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/auto_3.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/auto_4.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/auto_5.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/balanced_1.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/balanced_2.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/balanced_3.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/balanced_4.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/balanced_5.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/high_1.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/high_2.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/high_3.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/high_4.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/high_5.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/performance_1.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/performance_2.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/performance_3.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/performance_4.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/runs/performance_5.json` | added | +268 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/balanced_1.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/balanced_2.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/balanced_3.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/balanced_4.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/balanced_5.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/performance_1.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/performance_2.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/performance_3.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/performance_4.log` | added | +1 | −0 |
| `_tl1/D2_REPRODUCTION/worker_logs/performance_5.log` | added | +1 | −0 |
| `_tl1/D3_REAL_ORIGIN/CHROMIUM_POLICY_INSPECTION.txt` | added | +20 | −0 |
| `_tl1/D3_REAL_ORIGIN/D3_REAL_ORIGIN_RESULTS.json` | added | +49 | −0 |
| `_tl1/D3_REAL_ORIGIN/D3_REAL_ORIGIN_RUN.log` | added | +93 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/CHROMIUM_POLICY_DISCOVERY.txt` | added | +20 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/D3_EVENT_LOG.jsonl` | added | +9 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/D3_REAL_ORIGIN_RESULTS.json` | added | +93 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/D3_REAL_ORIGIN_RUN.log` | added | +93 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/HTTP_BODY.html` | added | +3226 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/HTTP_HEADERS.txt` | added | +7 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/HTTP_SERVER.log` | added | +1 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/harness_attempt_1/D3_EVENT_LOG.jsonl` | added | +2 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/harness_attempt_1/HARNESS_ATTEMPT_1_NOTE.md` | added | +3 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/harness_attempt_1/HTTP_BODY.html` | added | +3226 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/harness_attempt_1/HTTP_HEADERS.txt` | added | +7 | −0 |
| `_tl1/D3_REAL_ORIGIN_STORAGE/harness_attempt_1/HTTP_SERVER.log` | added | +1 | −0 |
| `_tl1/D4_ROOF_MASK/D4_CHECKSUMS.sha256` | added | +5 | −0 |
| `_tl1/D4_ROOF_MASK/D4_CHECKSUMS_VERIFY.txt` | added | +5 | −0 |
| `_tl1/D4_ROOF_MASK/D4_EVENT_LOG.jsonl` | added | +11 | −0 |
| `_tl1/D4_ROOF_MASK/D4_ROOF_MASK_REPORT.md` | added | +18 | −0 |
| `_tl1/D4_ROOF_MASK/D4_ROOF_MASK_RESULTS.json` | added | +51 | −0 |
| `_tl1/D4_ROOF_MASK/D4_RUN.log` | added | +1 | −0 |
| `_tl1/D4_ROOF_MASK/D4_RUNTIME_PROBE.json` | added | +1024 | −0 |
| `_tl1/D4_ROOF_MASK/D4_RUN_EXIT.txt` | added | +1 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE.json` | added | +121 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/D5_CHECKSUMS.sha256` | added | +6 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/D5_CHECKSUMS_VERIFY.txt` | added | +6 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/D5_EVENT_LOG.jsonl` | added | +22 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/D5_LEGACY_SAVE_PROVENANCE.json` | added | +179 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/D5_RUN.log` | added | +179 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/LEGACY_SAVE_PROVENANCE.md` | added | +29 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/LOAD_STATE_SOURCE.js` | added | +15 | −0 |
| `_tl1/D5_LEGACY_SAVE_PROVENANCE/MIGRATE_STATE_SOURCE.js` | added | +68 | −0 |
| `_tl1/G6_SAVE_COMPATIBILITY/FINAL_RUN.log` | added | +22 | −0 |
| `_tl1/G6_SAVE_COMPATIBILITY/V1_0_SAVE_PAYLOAD.json` | added | +1 | −0 |
| `_tl1/G6_SAVE_COMPATIBILITY/V1_0_SAVE_PAYLOAD.sha256` | added | +1 | −0 |
| `_tl1/G6_SAVE_COMPATIBILITY/V1_0_SAVE_PAYLOAD.stat.txt` | added | +1 | −0 |
| `_tl1/G6_SAVE_COMPATIBILITY/VALID_RUN.log` | added | +22 | −0 |
| `_tl1/G6_SAVE_COMPATIBILITY/VALID_RUN_EXIT.txt` | added | +1 | −0 |
| `_tl1/LEGACY_SAVE_PROVENANCE.md` | added | +29 | −0 |
| `_tl1/MISCHIEF_OPTIONS.md` | added | +87 | −0 |
| `_tl1/MISCHIEF_VERIFY.json` | added | +78 | −0 |
| `_tl1/MISCHIEF_VERIFY.log` | added | +78 | −0 |
| `_tl1/PHASE0_BASELINE/BRAND_BLOCK.bin` | added | +5 | −0 |
| `_tl1/PHASE0_BASELINE/CHECKSUM_VERIFICATION.txt` | added | +24 | −0 |
| `_tl1/PHASE0_BASELINE/HTML_ENDING.json` | added | +5 | −0 |
| `_tl1/PHASE0_BASELINE/HTML_SHA256.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/HTML_WC_C.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/HTML_WC_M.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/ID_LIST.txt` | added | +164 | −0 |
| `_tl1/PHASE0_BASELINE/INLINE_SCRIPT.js` | added | +2720 | −0 |
| `_tl1/PHASE0_BASELINE/NODE_CHECK.txt` | added | +0 | −0 |
| `_tl1/PHASE0_BASELINE/NODE_CHECK_EXIT.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/NON_ASCII_INVENTORY.json` | added | +91 | −0 |
| `_tl1/PHASE0_BASELINE/PHASE0_CHECKSUMS.sha256` | added | +24 | −0 |
| `_tl1/PHASE0_BASELINE/PHASE0_CHECKSUMS_VERIFY.txt` | added | +24 | −0 |
| `_tl1/PHASE0_BASELINE/PHASE0_EVENT_LOG.jsonl` | added | +41 | −0 |
| `_tl1/PHASE0_BASELINE/PHASE0_MEASUREMENTS.json` | added | +221 | −0 |
| `_tl1/PHASE0_BASELINE/PHASE0_REPORT.md` | added | +30 | −0 |
| `_tl1/PHASE0_BASELINE/PHASE0_ROOT.sha256` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/SCRIPT_EXTRACTION.json` | added | +5 | −0 |
| `_tl1/PHASE0_BASELINE/SCRIPT_SHA256.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/SCRIPT_WC_C.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/SCRIPT_WC_M.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/SOURCE_ZIP_SHA256.txt` | added | +1 | −0 |
| `_tl1/PHASE0_BASELINE/STORAGE_KEY_SUMMARY.json` | added | +91 | −0 |
| `_tl1/PHASE0_BASELINE/STORAGE_KEY_TRACE.json` | added | +654 | −0 |
| `_tl1/PHASE0_BASELINE/STORAGE_PROBE_RUN.log` | added | +57 | −0 |
| `_tl1/PHASE0_BASELINE/STORAGE_STATIC_CONTEXT.txt` | added | +16 | −0 |
| `_tl1/PHASE0_BASELINE/STRUCTURE_MEASUREMENTS.json` | added | +18 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/AGGREGATION.log` | added | +29 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/PHASE2_EVENT_LOG.jsonl` | added | +9 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/PHASE2_EVIDENCE.sha256` | added | +11 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/PHASE2_EVIDENCE_VERIFY.txt` | added | +11 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/PHASE2_PROGRESS.log` | added | +9 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/PHASE2_RUNNER_EXIT` | added | +1 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/RUNS.log` | added | +12 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/THROTTLED_PROXY_REPORT.md` | added | +18 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/THROTTLED_PROXY_RESULTS.json` | added | +194 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/runs/desktop1440_4x_1.json` | added | +277 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/runs/desktop1440_6x_1.json` | added | +277 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/runs/mobile390_4x_1.json` | added | +277 | −0 |
| `_tl1/PHASE2_THROTTLED_PROXY/runs/mobile390_6x_1.json` | added | +277 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/BROWSER_CANDIDATES.txt` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_CHECKSUMS.sha256` | added | +16 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_CHECKSUMS_VERIFY.txt` | added | +16 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_EVENT_LOG.jsonl` | added | +16 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_HTTP_BODY.html` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_HTTP_HEADERS.txt` | added | +7 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_HTTP_SERVER.log` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_MODE.txt` | added | +2 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_PROBE.json` | added | +56 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/CAPABILITY_PROBE.log` | added | +56 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/GIT_VERSION.txt` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/NODE_VERSION.txt` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/NPM_VERSION.txt` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/PHASE_MINUS1_REPORT.md` | added | +12 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/PLAYWRIGHT_IMPORT.txt` | added | +2 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/PYTHON_STDLIB_IMPORTS.txt` | added | +2 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/PYTHON_VERSION.txt` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/SHA256SUM_VERSION.txt` | added | +1 | −0 |
| `_tl1/PHASE_MINUS1_CAPABILITY/WC_VERSION.txt` | added | +1 | −0 |
| `_tl1/TL1_RECERTIFICATION_REPORT.md` | added | +371 | −0 |
| `qa/BUILD_RELEASE_MANIFEST.py` | added | +95 | −0 |
| `qa/BUILD_TL1_REPORT.py` | added | +258 | −0 |
| `qa/PERFORMANCE_PROFILE_GOLD.json` | modified | +330 | −1 |
| `qa/PRODUCTION_HARDENING_RESULTS.json` | modified | +789 | −90 |
| `qa/QA_CAPTURE_METADATA.json` | modified | +10 | −5 |
| `qa/QA_SYSTEM_RESULTS.json` | modified | +4003 | −1233 |
| `qa/TL1_FINAL_GATES.py` | added | +193 | −0 |
| `qa/TL1_GATE_RESULTS.json` | added | +1499 | −0 |
| `qa/TL1_QA_RUNNER.py` | added | +639 | −0 |
| `qa/TL1_SAVE_COMPATIBILITY.json` | added | +335 | −0 |
| `qa/TL1_SAVE_COMPATIBILITY_RUNNER.py` | added | +216 | −0 |
| `qa/TL1_STORAGE_KEY_TRACE.json` | added | +1862 | −0 |

Protected files `ORIGINALITY_AND_SAFETY_NOTES.md` and `TECHNICAL_ARCHITECTURE.md` remain byte-identical to BASE. The executable HTML diff is confined to two equal-length version-marker substitutions.

## Honest assertion total

**99/99 distinct assertions passed/attempted.**  
Unexecuted real-origin groups are outside the attempted denominator. The hardening view is non-additive.

## Still UNPROVEN or UNEXECUTED

- Shipped `file://` startup, hardening, accessibility and storage behaviour: **UNPROVEN-ON-REAL-ORIGIN**.
- Loopback HTTP startup, hardening, accessibility and storage behaviour: **UNPROVEN-ON-REAL-ORIGIN**.
- Firefox execution: **UNEXECUTED**.
- Safari/WebKit execution: **UNEXECUTED**.
- Chromebook hardware: **UNEXECUTED**.
- Android hardware: **UNEXECUTED**.
- iOS hardware: **UNEXECUTED**.
- Physical low-power/thermal performance: **UNEXECUTED**; Phase 2 values are throttled proxies only.
- Human screen-reader, motor-access and cognitive-access evaluation: **UNEXECUTED**.
- Genuine earlier Town Life save artefacts for v0.9…v0.1: **UNAVAILABLE/UNPROVEN**; all migration verdicts remain PARTIAL.
- Adaptive-controller thrash/hysteresis instrumentation and a D2 code fix: **NOT EXECUTED BY RULE**, because the defect did not reproduce beyond run variance.

## Mischief editorial options

No Mischief-related change was made. `_tl1/MISCHIEF_OPTIONS.md` costs exactly O1–O4, identifies files/functions/line footprints, states saved-state risk and recommends nothing.

## Rollback

Delete `MBM_Town_Life_v1_0_1_CANDIDATE/` (and its ZIP); the original uploaded v1.0 ZIP remains byte-for-byte untouched.
