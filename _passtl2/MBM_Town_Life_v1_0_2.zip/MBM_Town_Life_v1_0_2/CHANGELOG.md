# Town Life v1.0.2 — Washworks rename

## TL-2 Part A — 18 August 2026

- Renamed the player-facing business **Northstar Washworks** to **Northstar Exchange**, per Matt's
  2026-08-18 ruling to rename Washworks only. 17 player-visible occurrences changed across location
  and business names, notify text, action labels, HUD lines, the civic-decree description and the
  synergy descriptions. Grammatical agreement was re-read per string, not pattern-substituted: one
  article moved from `A` to `An`, and three strings gained or kept `the` to stay idiomatic.
- Left the internal identifier `businessSynergySnapshot().garageWashworks` unchanged (5 occurrences).
  It was proved **not persisted**: with Garage + Exchange both owned, the payload under
  `mbm_town_life_v10` contains neither the key nor the string `Washworks`.
- Left `state.laundering`, `LaunderingManager`, `state.dirtyBonds` and the `laundry` business id
  unchanged. The `laundry` id is a save-schema key; renaming it would invalidate existing saves.
- Corrected the executable version marker from `1.0.1` to `1.0.2`; save schema remains `10` and the
  save key remains `mbm_town_life_v10`.
- Changed no role, content, economy value, vehicle tuning, utility behaviour, business rule,
  Civic Bank flow, conversion flow, Sylvia flow or Mischief behaviour.

# Town Life v1.0.1 — TL-1 held candidate

## Fix and recertification pass — 18 August 2026

- Corrected the executable version marker from `1.0.0` to `1.0.1`; save schema remains `10`.
- Repaired the browser QA harness so assertion names are unique, every attempted check carries observed evidence, and runtime/console errors are asserted once at suite level.
- Replaced additive suite arithmetic with one honest result: **99/99 distinct assertions passed/attempted**. The hardening report is a non-additive filtered view.
- Reproduced the four render profiles with five isolated runs each. Auto’s 55.08-fps median was below the 57.13-fps slowest fixed median, but its complete 52.78–56.84-fps spread overlapped every fixed-profile spread; D2 therefore closed as `NOT-A-DEFECT` outside run variance, with no adaptive-controller code change.
- Proved the roof-mask cache is scene-dependent and actively read: `0` entries at the opening scene, `11` in the Civic Bank cutaway, with `142` hits after settling.
- Recorded all nine legacy keys as reachable through one generic normaliser but only `PARTIAL` by provenance because no version-specific contracts or genuine earlier save artefacts are packaged.
- Recorded `file:///` and loopback HTTP tests as `UNPROVEN-ON-REAL-ORIGIN` after managed Chromium blocked both before document commit.
- Proved v1.0 save compatibility into v1.0.1 for profile, role, claimed plot and props, all four Tier-4 businesses, three-driver fleet state and the complete tested utility graph; schema remains 10.
- Added one-run 4× and 6× CPU-throttled maximum-scene proxies at 1440×900 and 390×844 coarse-pointer layout, explicitly labelled as proxies rather than device measurements.
- Changed no role, content, economy, vehicle, utility, business, Civic Bank, Washworks, Sylvia or Mischief behaviour.

# Town Life Gold Master v1.0 changelog

Release date: **17 August 2026**

## Gold Master identity

- Promoted the professional v0.9 runtime to **Town Life Gold Master v1.0**.
- Advanced persistent state to **schema 10** and save key `mbm_town_life_v10`.
- Added a generic compatibility bridge that probes save keys v0.9 through v0.1 without deleting or overwriting the legacy key; TL-1 found no version-specific genuine fixtures in the package.
- Updated the welcome surface, browser title, in-game branding, help text and export filename.

## Plot electrical grid

- Added an isolated persistent utility graph to every home plot.
- Added Mains, Generator and Solar + Battery source hierarchy.
- Added live source capacity, total demand and circuit telemetry.
- Added master isolator, overload breaker, trip count and safe reset rejection.
- Added generator installation, fuel refill and time-based fuel consumption.
- Added rooftop solar installation, sun-elevation output and decree modifier.
- Added battery installation, charge, surplus charging and bounded night discharge.
- Added mains utility-bill accrual and payment.
- Added procedural 50 Hz transformer hum, switch clicks, breaker snap, sparks and restoration tones.
- Added electrical telemetry HUD while standing inside an owned home.

## Powered furniture and wiring

- Added Kitchen Fridge, Workshop Bench, CCTV Camera, Security Monitor, Electronic Safe and Smart Wall Switch.
- Added calibrated device wattage and default circuit assignments.
- Made lamps, televisions and new electrical props dependent on downstream power.
- Added **Wire Circuits** mode to Home Designer.
- Added colour-coded branch topology from breaker to each powered load.
- Added per-device circuit cycling through Lighting, Appliances, Security and Workshop.
- Added direct prop interactions for switching loads, opening CCTV monitors and toggling lighting circuits.

## CCTV and surveillance

- Added a multi-camera property CCTV system.
- Added cached 128 × 96 offscreen render targets for independent camera feeds.
- Added a 160 × 120 HUD picture-in-picture viewer with Prev, Next and Close controls.
- Added phosphor-green rendering, scanlines, timestamp, recording label and crosshair.
- Added independent camera positions and angles.
- Added in-world live monitor furniture.
- Added explicit no-signal/static output on breaker, source, circuit or camera power loss.
- Added Officer/Mayor civic dispatch feeds for Civic Bank, Police Yard, Garage and Town Hall.
- Added bounded Civic Bank power-cut counterplay and timed restoration.
- Added High/Balanced/Performance render cadence for PiP and monitor buffers.

## Context Steering AI 2.0

- Increased civilian traffic to 15 autonomous vehicles.
- Added directional context-ray evaluation against static and dynamic obstacles.
- Added route interest, road preference, avoidance danger and emergency yielding.
- Added roadblock and stalled-vehicle avoidance.
- Added pedestrian context steering through open town spaces.
- Added police obstacle steering.
- Added bounded stuck detection and deadlock recovery.
- Connected steering queries to the existing 128-pixel spatial hash broadphase.

## Governance and civic legacy

- Added the **Mayor** role.
- Added Northstar Town Hall with an interior decree console.
- Added Resident once-per-day civic voting.
- Added civic-fund contributions.
- Added Night Curfew Ordinance, Infrastructure Subsidy and Civic Green Initiative.
- Connected decrees to night patrols, courier rewards, deed prices, upgrade prices, conversion duration, solar costs, solar output and business yield.
- Added decree duration and automatic expiry back to the Standard Civic Charter.
- Added the Town Prosperity Index.
- Connected prosperity to contracts, heat, businesses, tiers, fleets, solar and vehicle condition.
- Added four visual fountain tiers in Northstar Park.

## Commercial economy closure

- Expanded all four businesses to Tier 4.
- Added prosperity- and decree-sensitive deed, upgrade and yield calculations.
- Expanded the NPC courier fleet from one driver to a bounded three-driver network.
- Added driver scaling, insurance/recruitment costs and automated run yield.
- Retained Cafe + Clinic, Garage + Washworks and Town Network synergies.
- Preserved delayed fictional bond conversion and connected it to governance modifiers.

## Production hardening

- Added Canvas 2D `roundRect()` compatibility fallback.
- Verified graceful operation when Web Audio is unavailable.
- Verified local → session → volatile storage fallback.
- Verified malformed-save recovery.
- Verified persistent reload in a fresh browser context.
- Verified fatal errors set readiness false and expose a recovery overlay.
- Retained startup readiness only after migration, storage, interface and subsystem initialisation.
- Retained no external network dependencies.

## Accessibility and responsive design

- Added 44-pixel coarse-pointer floor to wardrobe swatches, compact selectors and CCTV controls.
- Verified 390 × 844 layout without horizontal document overflow.
- Retained pinch zoom by avoiding restrictive viewport directives.
- Retained reduced motion, high contrast, focus trapping, Escape closure and focus restoration.
- Added accessible labels to CCTV region and controls.

## Verification

- Historical v1.0 result file contained 100 records but only 91 distinct names.
- TL-1 candidate result: **99/99 distinct assertions passed/attempted**.
- The hardening report is a non-additive filtered view and is not summed into a second total.
- Captured page errors: **0** in normal release suites.
- Captured console errors: **0** in normal release suites.
- Stress population: 15 traffic vehicles, 1,200 updates, zero retained deadlock.
- Active dual-camera Balanced profile: approximately 58.7 callback FPS in managed Chromium.

## Deferred platform certification

- Direct Firefox execution remains unexecuted in this pass; no browser-install or network explanation is claimed.
- Direct Safari/WebKit execution remains unexecuted in this pass.
- Low-end physical Android thermal and long-session testing remain real-device gates.
