# TL-1 D4 — Roof-Mask Cache

**Reproduced: YES. Fixed in the QA claim: YES. Rendering code changed: NO.**

The original evidence reported `roofMaskCache: 0` while a static assertion claimed cached roof masks were retained. The zero is real, but scene-dependent: the opening player position does not lower a roof far enough to request a dither mask.

The unchanged v1.0 runtime was loaded through injected content at serialized origin `null`, then driven into the Civic Bank cutaway at world position `(1425, 1175)`. `Map.get` and `Map.set` were instrumented only for the roof-mask key shape.

| Snapshot | Cache entries | `Map.get` calls | Hits | Misses | Sets |
|---|---:|---:|---:|---:|---:|
| Before entering | 0 | 0 | 0 | 0 | 0 |
| Immediate cutaway | 1 | 1 | 0 | 1 | 1 |
| After 30 frames | 11 | 33 | 21 | 12 | 12 |
| After 150 frames | 11 | 154 | 142 | 12 | 12 |

The cache stabilised at 11 entries while successful lookups increased from 21 to 142. Classification: **SCENE-DEPENDENT AND ACTIVELY READ**.

The D1 harness repair must replace the old evidence-free static claim with a dynamic assertion that drives this scene and emits the opening/populated cache sizes and lookup counters. No roof-rendering code is to be removed or altered.
