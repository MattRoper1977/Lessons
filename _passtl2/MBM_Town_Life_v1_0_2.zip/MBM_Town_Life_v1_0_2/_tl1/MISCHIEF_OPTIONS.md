# TL-1 Mischief editorial options — cost only

No option below has been implemented. The candidate leaves **Mischief**, **Civic Bank**, **fictional vault bonds**, **Northstar Washworks** and **Sylvia** unchanged. Physical-line estimates are measured against the current one-file runtime and current TL-1 evidence layout; regenerated JSON/checksum files are identified separately because their line counts are output-dependent.

## O1 — Leave as shipped

**Implementation footprint:** 0 files, 0 functions, 0 changed physical lines.

**Files/functions:** none.

**Saved state:** no change. The existing schema-10 fields (`role`, `dirtyBonds`, `laundering`, `affinity.sylvia`, `unlocks.covertCourier`, businesses and mission data) retain their current meaning. **R3 risk: none introduced.**

**What would break:** nothing changes. The present editorial boundary remains documented in `ORIGINALITY_AND_SAFETY_NOTES.md` but is not surfaced in the player interface.

**Re-testing required:** no implementation retest. A future release decision would still need the existing Mischief operation, Civic Bank alarm/escape, covert courier and delayed conversion checks to remain green.

## O2 — Default Mischief off behind a settings toggle, unlockable in-game

**Estimated implementation footprint:** 10 hand-edited files; **31 hand-edited physical lines**; four generated evidence/manifest files rewritten.

| File | Functions or areas touched | Estimated physical lines |
|---|---|---:|
| `MBM_Town_Life_GOLD_v1_0.html` | role `<option>`; Comfort settings markup; `defaultState`; `migrateState`; new role-availability synchroniser; `setRole`; `wireInterface`; `updateUI`; `initialise` | 14 |
| `qa/TL1_QA_RUNNER.py` | startup, accessibility, operations and storage assertions for the disabled default, enabling toggle and old-save behaviour | 7 |
| `qa/TL1_SAVE_COMPATIBILITY_RUNNER.py` | add v1.0 Mischief-role fixture and preservation comparison | 3 |
| `README.md` | role/settings explanation | 1 |
| `QUICK_START.txt` | how to enable the optional role | 1 |
| `ORIGINALITY_AND_SAFETY_NOTES.md` | describe the optional gate without changing the content boundary | 1 |
| `GOLD_MASTER_RELEASE_NOTES.md` | changed default-availability statement | 1 |
| `VERIFICATION_REPORT.md` | gate and compatibility result | 1 |
| `CHANGELOG.md` | implementation and compatibility note | 1 |
| `_tl1/MISCHIEF_OPTIONS.md` | mark the selected option as implemented in a later pass | 1 |

Generated after implementation: `qa/QA_SYSTEM_RESULTS.json`, `qa/PRODUCTION_HARDENING_RESULTS.json`, `RELEASE_MANIFEST.json` and `CHECKSUMS.sha256`.

**Saved state:** yes. A minimal implementation would add a boolean such as `mischiefEnabled` inside the existing `mbm_town_life_v10` payload while keeping schema 10 and adding no storage key. Existing v1.0 saves whose active role is Mischief would need the loader to infer `mischiefEnabled: true`; otherwise they could silently fall back to Resident. **R3 risk: material.** The risk is semantic rather than key-level: an incorrect default or migration rule could change the role in an existing save.

**What could break:** loading a v1.0 save while playing Mischief; imported schema-10 saves; role selector focus/order; direct role changes in QA; Mischief job start; Civic Bank and Sylvia operation entry points; role-dependent vehicle/siren presentation; export/import round trips.

**Re-testing required:** G6 with Resident and Mischief source saves; boot/save/load/import/export; all role jobs; Civic Bank operation; Sylvia Rank-3 unlock; settings keyboard/touch accessibility; G8 runtime key trace; full 99-assertion suite; real-origin storage when an environment permits it.

## O3 — Rename Washworks, and only Washworks, to a non-laundering term

For costing, the replacement label is treated as a same-scope placeholder such as **Northstar Service Works**. The internal business ID `laundry` and all economy/state fields remain unchanged.

**Estimated implementation footprint:** eight existing files; **30 physical line changes**, including one new changelog line.

| File | Functions or areas touched | Measured/estimated physical lines |
|---|---|---:|
| `MBM_Town_Life_GOLD_v1_0.html` | location/business labels; decree copy; `businessSynergySnapshot`; `BusinessManager.yieldPerHour`; `LaunderingManager.start` and `.interaction`; ledger/operations copy; `thisLaunderingText`; `startCovertCourierOperation`; location interactions; repair copy | 17 |
| `README.md` | four player-facing references | 4 |
| `ORIGINALITY_AND_SAFETY_NOTES.md` | two boundary references | 2 |
| `TECHNICAL_ARCHITECTURE.md` | conversion-duration reference | 1 |
| `VERIFICATION_REPORT.md` | one feature reference | 1 |
| `CHANGELOG.md` | two existing references plus one new rename entry | 3 |
| `qa/TL1_QA_RUNNER.py` | assertion display name only | 1 |
| `qa/QA_SYSTEM_RESULTS.json` | regenerated assertion display name | 1 |

The immutable Phase-0 evidence copy would retain the old word because it records the original artefact; it would not be rewritten. `RELEASE_MANIFEST.json` and `CHECKSUMS.sha256` would be regenerated without changing gameplay data.

**Saved state:** no change. The persisted key remains `laundry`; business ownership, tier, stored revenue, laundering timing, missions and locations continue to resolve by the same IDs. **R3 risk: none expected.**

**What could break:** incomplete terminology replacement could leave mixed labels; replacing the internal `laundry` ID would break saves and is explicitly outside this option; UI copy could overflow narrow buttons; assertion names and documentation could disagree.

**Re-testing required:** v1.0 save load; business purchase/upgrade/dividend path; Garage synergy; covert courier destination; Civic Bank bond conversion; repair subsidy; 390×844 layout; text search proving no live player-facing old label remains; full assertion suite and checksums.

## O4 — Surface a short in-game boundary line where the loop first unlocks

The costed implementation is a **session-only transition notice** when `covertCourier` changes from false to true. It does not add a persisted “seen” flag; a player who starts a new session with the unlock already present may see the line once in that session.

**Estimated implementation footprint:** five hand-edited files; **10 hand-edited physical lines**; two generated evidence files rewritten.

| File | Functions or areas touched | Estimated physical lines |
|---|---|---:|
| `MBM_Town_Life_GOLD_v1_0.html` | one ephemeral session flag; `updateUnlocks` transition detection and short boundary notification | 4 |
| `qa/TL1_QA_RUNNER.py` | verify the Rank-3 transition surfaces the line without changing role/unlock mechanics | 3 |
| `README.md` | player-interface boundary note | 1 |
| `VERIFICATION_REPORT.md` | execution result | 1 |
| `CHANGELOG.md` | additive copy-only change | 1 |

Generated after implementation: `qa/QA_SYSTEM_RESULTS.json`, `RELEASE_MANIFEST.json` and `CHECKSUMS.sha256`.

**Saved state:** no change in the costed session-only form. No new field or storage key is added. **R3 risk: none expected.** Persisting “shown once ever” would be a different implementation, would touch saved state and would introduce R3 risk.

**What could break:** the notice could repeat if transition detection is wrong; it could be hidden by a simultaneous unlock toast; booting an already-unlocked save could produce an unexpected notice; assertive live-region timing could become noisy.

**Re-testing required:** Sylvia affinity across separate town days; exact Rank-3 transition; reload of already-unlocked v1.0 saves; toast/live-region behaviour; keyboard and screen-reader announcement order; covert courier start/completion; save payload diff proving no new field; full assertion suite and checksums.
