
window.__MBM_TOWN_LIFE_READY__ = false;
window.__MBM_TOWN_LIFE_STATUS__ = {ready:false,stage:'loading',version:'1.0.0'};
// Compatibility bridge for Canvas 2D implementations without roundRect().
if(typeof CanvasRenderingContext2D!=='undefined'&&!CanvasRenderingContext2D.prototype.roundRect){
  CanvasRenderingContext2D.prototype.roundRect=function(x,y,w,h,r=0){
    const radii=Array.isArray(r)?r:[r,r,r,r];
    const values=radii.map(value=>Math.max(0,Math.min(Math.abs(w)/2,Math.min(Math.abs(h)/2,Number(value)||0))));
    const [tl,tr,br,bl]=values;
    this.moveTo(x+tl,y);this.lineTo(x+w-tr,y);this.quadraticCurveTo(x+w,y,x+w,y+tr);this.lineTo(x+w,y+h-br);this.quadraticCurveTo(x+w,y+h,x+w-br,y+h);this.lineTo(x+bl,y+h);this.quadraticCurveTo(x,y+h,x,y+h-bl);this.lineTo(x,y+tl);this.quadraticCurveTo(x,y,x+tl,y);this.closePath();return this;
  };
}
(() => {
'use strict';
const VERSION = '1.0.0';
const SCHEMA_VERSION = 10;
const SAVE_KEY = 'mbm_town_life_v10';
const LEGACY_KEYS = ['mbm_town_life_v09','mbm_town_life_v08','mbm_town_life_v07','mbm_town_life_v06','mbm_town_life_v05','mbm_town_life_v04','mbm_town_life_v03','mbm_town_life_v02','mbm_town_life_v01'];
const WORLD = {w:2800,h:2200};
const FIXED_STEP = 1000 / 60;
const QA_MODE = new URLSearchParams(location.search).has('qa');
const $ = id => document.getElementById(id);
const canvas = $('game');
const ctx = canvas.getContext('2d');
const mini = $('mini');
const mctx = mini.getContext('2d');
const lightCanvas = document.createElement('canvas');
const lightCtx = lightCanvas.getContext('2d');
const roofCanvas = document.createElement('canvas');
const roofCtx = roofCanvas.getContext('2d');
roofCanvas.width = 700;
roofCanvas.height = 560;
const roofBaseCache=new Map();
const roofMaskCache=new Map();
const BAYER_8=[0,48,12,60,3,51,15,63,32,16,44,28,35,19,47,31,8,56,4,52,11,59,7,55,40,24,36,20,43,27,39,23,2,50,14,62,1,49,13,61,34,18,46,30,33,17,45,29,10,58,6,54,9,57,5,53,42,26,38,22,41,25,37,21];
let DPR = Math.min(devicePixelRatio || 1, 2);
let CW = innerWidth;
let CH = innerHeight;

function resize(){
  DPR = Math.min(devicePixelRatio || 1, 2);
  CW = innerWidth;
  CH = innerHeight;
  canvas.width = Math.round(CW * DPR);
  canvas.height = Math.round(CH * DPR);
  mini.width = Math.round(138 * DPR);
  mini.height = Math.round(104 * DPR);
  lightCanvas.width = canvas.width;
  lightCanvas.height = canvas.height;
  if(typeof window.__MBM_WEATHER_RESIZE__ === 'function')window.__MBM_WEATHER_RESIZE__();
}
addEventListener('resize', resize);
resize();

const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const lerp = (a,b,t) => a + (b-a) * t;
const rectContains = (r,x,y) => x >= r.x && x <= r.x+r.w && y >= r.y && y <= r.y+r.h;
const rectOverlap = (a,b) => a.x < b.x+b.w && a.x+a.w > b.x && a.y < b.y+b.h && a.y+a.h > b.y;
const pointDistance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
const angleDistance = (a,b) => Math.abs(((a-b+540)%360)-180);
const normaliseAngle = a => (a % 360 + 360) % 360;
const fmtTime = h => {
  h = (h + 24) % 24;
  const hh = Math.floor(h);
  const mm = Math.floor((h-hh)*60);
  return `${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`;
};
const deepClone = value => JSON.parse(JSON.stringify(value));
function hashSeedless(x,y){let n=(x*374761393+y*668265263)>>>0;n=(n^(n>>13))*1274126177>>>0;return((n^(n>>16))>>>0)/4294967295}
const ROOF_THRESHOLD_64=new Float32Array(64*64);
for(let y=0;y<64;y++)for(let x=0;x<64;x++)ROOF_THRESHOLD_64[y*64+x]=clamp((BAYER_8[(y%8)*8+(x%8)]+.5)/64+(hashSeedless(x,y)-.5)*.08,0,1);

class SpatialHashGrid{
  constructor(cellSize=128){this.cellSize=cellSize;this.buckets=new Map();this.insertions=0;this.queries=0;this.candidates=0}
  clear(){this.buckets.clear();this.insertions=0;this.queries=0;this.candidates=0}
  key(x,y){return`${x},${y}`}
  cell(value){return Math.floor(value/this.cellSize)}
  insert(item,bounds=item){
    if(!item||!bounds)return;
    const minX=this.cell(bounds.x),maxX=this.cell(bounds.x+Math.max(0,bounds.w||0));
    const minY=this.cell(bounds.y),maxY=this.cell(bounds.y+Math.max(0,bounds.h||0));
    for(let cy=minY;cy<=maxY;cy++)for(let cx=minX;cx<=maxX;cx++){
      const key=this.key(cx,cy);let bucket=this.buckets.get(key);if(!bucket){bucket=[];this.buckets.set(key,bucket)}bucket.push(item);
    }
    this.insertions++;
  }
  queryAABB(x,y,w,h){
    this.queries++;
    const found=new Set();const minX=this.cell(x),maxX=this.cell(x+Math.max(0,w));const minY=this.cell(y),maxY=this.cell(y+Math.max(0,h));
    for(let cy=minY;cy<=maxY;cy++)for(let cx=minX;cx<=maxX;cx++){
      const bucket=this.buckets.get(this.key(cx,cy));if(!bucket)continue;for(const item of bucket)found.add(item);
    }
    this.candidates+=found.size;return[...found];
  }
  queryCircle(x,y,r){return this.queryAABB(x-r,y-r,r*2,r*2)}
  stats(){return{cellSize:this.cellSize,buckets:this.buckets.size,insertions:this.insertions,queries:this.queries,candidates:this.candidates}}
}


const affinityRank = score => score >= 14 ? 5 : score >= 9 ? 4 : score >= 5 ? 3 : score >= 2 ? 2 : 1;
const absoluteHour = () => (Math.max(1,Number(state?.day)||1)-1)*24 + ((Number(state?.time)||0)%24+24)%24;

class CinematicCamera{
  constructor(){this.x=1400;this.y=1420;this.zoom=1;this.targetZoom=1;this.trauma=0;this.angle=0;this.shakeX=0;this.shakeY=0}
  snapTo(entity){this.x=entity.x;this.y=entity.y;this.zoom=1;this.targetZoom=1;this.trauma=0;this.angle=0;this.shakeX=0;this.shakeY=0}
  addTrauma(amount){if(state?.reducedMotion||state?.cameraEffects===false)return;this.trauma=clamp(this.trauma+amount,0,1)}
  update(focus,isDriving,speed,heading){
    const effects=state.cameraEffects!==false&&!state.reducedMotion;
    const look=effects&&isDriving?Math.min(138,speed*14):0;
    const targetX=focus.x+Math.cos(heading)*look;
    const targetY=focus.y+Math.sin(heading)*look;
    this.targetZoom=effects&&isDriving?1-Math.min(.20,(speed/Math.max(1,car.maxSpeed||12))*.20):1;
    const follow=effects?.085:1;
    this.x=lerp(this.x,targetX,follow);this.y=lerp(this.y,targetY,follow);this.zoom=lerp(this.zoom,this.targetZoom,effects?.05:1);
    const halfW=CW/(2*Math.max(.72,this.zoom)),halfH=CH/(2*Math.max(.72,this.zoom));
    this.x=clamp(this.x,Math.min(halfW,WORLD.w/2),Math.max(WORLD.w-halfW,WORLD.w/2));
    this.y=clamp(this.y,Math.min(halfH,WORLD.h/2),Math.max(WORLD.h-halfH,WORLD.h/2));
    if(effects&&this.trauma>.001){
      const magnitude=this.trauma*this.trauma*18;
      this.shakeX=(Math.random()*2-1)*magnitude;this.shakeY=(Math.random()*2-1)*magnitude;
      this.angle=(Math.random()*2-1)*this.trauma*this.trauma*.034;
      this.trauma=Math.max(0,this.trauma-.021);
    }else{this.shakeX=0;this.shakeY=0;this.angle=0;this.trauma=0}
  }
  apply(c,pixelRatio=DPR){c.setTransform(pixelRatio,0,0,pixelRatio,0,0);c.translate(CW/2,CH/2);c.scale(this.zoom,this.zoom);c.rotate(this.angle);c.translate(-(this.x+this.shakeX),-(this.y+this.shakeY))}
  screenToWorld(clientX,clientY){
    const px=clientX-CW/2,py=clientY-CH/2;const cos=Math.cos(-this.angle),sin=Math.sin(-this.angle);
    const rx=(px*cos-py*sin)/this.zoom,ry=(px*sin+py*cos)/this.zoom;
    return{x:rx+this.x+this.shakeX,y:ry+this.y+this.shakeY};
  }
}
const Camera=new CinematicCamera();
function cameraViewRect(margin=180){const zoom=Math.max(.72,Camera.zoom||1),halfW=CW/(2*zoom)+margin,halfH=CH/(2*zoom)+margin;return{x:Camera.x-halfW,y:Camera.y-halfH,w:halfW*2,h:halfH*2}}
function rectInCamera(rect,margin=180){const view=cameraViewRect(margin);return rectOverlap(view,rect)}
function pointInCamera(x,y,margin=180){const view=cameraViewRect(margin);return x>=view.x&&x<=view.x+view.w&&y>=view.y&&y<=view.y+view.h}

const defaultAvatar = () => ({
  skin:'#f5c6a5',
  hair:'crop',
  hairColour:'#2c1b18',
  outfit:'casual',
  topColour:'#64d8d4',
  accessory:'none'
});
const POWER_CIRCUITS=['lighting','appliance','security','workshop'];
const PROP_CIRCUIT_DEFAULTS={lamp:'lighting',tv:'appliance',fridge:'appliance',workbench:'workshop',cctvCam:'security',cctvMonitor:'security',safe:'security',smartSwitch:'lighting'};
function defaultUtilityState(plotId=0){return{plotId:Number(plotId)||0,source:'mains',mainSwitch:true,breakerTripped:false,generatorInstalled:false,generatorFuel:100,solarInstalled:false,batteryInstalled:false,batteryCharge:55,circuits:{lighting:true,appliance:true,security:true,workshop:true},loadWatts:0,availableWatts:2400,solarOutputWatts:0,powered:true,lastUpdateAt:null,trips:0,utilityBill:0}}
function sanitiseUtility(raw,plotId){const base=defaultUtilityState(plotId),source=raw&&typeof raw==='object'?raw:{};return{...base,...source,plotId:Number(plotId)||0,source:['mains','generator','solar'].includes(source.source)?source.source:'mains',mainSwitch:source.mainSwitch!==false,breakerTripped:Boolean(source.breakerTripped),generatorInstalled:Boolean(source.generatorInstalled),generatorFuel:clamp(Number(source.generatorFuel??100)||0,0,100),solarInstalled:Boolean(source.solarInstalled),batteryInstalled:Boolean(source.batteryInstalled),batteryCharge:clamp(Number(source.batteryCharge??55)||0,0,100),circuits:{...base.circuits,...(source.circuits&&typeof source.circuits==='object'?source.circuits:{})},loadWatts:Math.max(0,Number(source.loadWatts)||0),availableWatts:Math.max(0,Number(source.availableWatts)||2400),solarOutputWatts:Math.max(0,Number(source.solarOutputWatts)||0),powered:source.powered!==false,lastUpdateAt:Number.isFinite(Number(source.lastUpdateAt))?Number(source.lastUpdateAt):null,trips:Math.max(0,Math.floor(Number(source.trips)||0)),utilityBill:Math.max(0,Number(source.utilityBill)||0)}}

const defaultState = () => ({
  schema:SCHEMA_VERSION,
  version:VERSION,
  profile:'Player',
  cash:500,
  role:'Resident',
  day:1,
  time:8,
  freezeTime:false,
  audio:true,
  reducedMotion:false,
  highContrast:false,
  cameraEffects:true,
  telemetry:true,
  cctvPip:true,
  utilityTelemetry:true,
  policeCones:true,
  weatherEffects:true,
  weatherMode:'auto',
  claimedPlot:null,
  plots:{},
  plotUtilities:{1:defaultUtilityState(1),2:defaultUtilityState(2),3:defaultUtilityState(3),4:defaultUtilityState(4)},
  civicPower:{bank:{online:true,restoreAt:0},police:{online:true,restoreAt:0},garage:{online:true,restoreAt:0},townhall:{online:true,restoreAt:0}},
  cctv:{pipOpen:false,activeFeed:null,selectedIndex:0,views:0},
  governance:{decree:'standard',decreeEndsAt:0,prosperity:35,peak:35,civicFund:0,enacted:0,residentVotes:0,lastVoteDay:0,lastUpdateAt:null},
  mission:null,
  cargo:null,
  bankAlarm:false,
  firstRun:true,
  avatar:defaultAvatar(),
  heat:0,
  dirtyBonds:0,
  laundering:null,
  affinity:{arthur:0,valerie:0,jax:0,sylvia:0,maya:0},
  citizenMemory:{arthur:{},valerie:{},jax:{},sylvia:{},maya:{}},
  businesses:{cafe:{owned:false,tier:0,stored:0,lastAccruedAt:null},clinic:{owned:false,tier:0,stored:0,lastAccruedAt:null},garage:{owned:false,tier:0,stored:0,lastAccruedAt:null},laundry:{owned:false,tier:0,stored:0,lastAccruedAt:null}},
  fleet:{hired:false,drivers:0,stored:0,lastRunAt:null,runs:0},
  vehicleTune:{gearbox:'balanced',tyres:'street',underglow:'off',horn:'classic',nitrous:false,ownedMods:['gearbox-balanced','tyres-street','underglow-off','horn-classic']},
  vehicleCondition:100,
  unlocks:{impound:false,highYield:false,businessDeeds:false,policeScanner:false,covertCourier:false,medicalResponse:false},
  events:[],
  stats:{jobsCompleted:0,collisions:0,safeCracks:0,perfectDeliveries:0,medicalCalls:0,securityScans:0,businessesOwned:0,dividendsCollected:0,heatEscapes:0,namedConversations:0,roadblocksCleared:0,smugglingRuns:0,stealthEscapes:0,repairsPaid:0,policeSightings:0,breakerTrips:0,cctvViews:0,circuitRewires:0,generatorFuelUsed:0,solarHours:0,trafficAvoidances:0,deadlocksResolved:0,decreesEnacted:0,prosperityPeak:35,fleetDriversHired:0},
  position:{x:1400,y:1420},
  flags:{migratedFrom:null}
});

class StorageBridge{
  constructor(){
    this.mode = 'volatile';
    this.store = null;
    this.memory = new Map();
    try{
      localStorage.setItem('__mbm_probe','1');
      localStorage.removeItem('__mbm_probe');
      this.store = localStorage;
      this.mode = 'local';
    }catch(localError){
      try{
        sessionStorage.setItem('__mbm_probe','1');
        sessionStorage.removeItem('__mbm_probe');
        this.store = sessionStorage;
        this.mode = 'session';
      }catch(sessionError){
        this.store = null;
      }
    }
  }
  get(key){
    try{return this.store ? this.store.getItem(key) : (this.memory.get(key) ?? null)}catch(error){return null}
  }
  set(key,value){
    try{if(this.store)this.store.setItem(key,value);else this.memory.set(key,value);return true}catch(error){return false}
  }
  remove(key){
    try{if(this.store)this.store.removeItem(key);else this.memory.delete(key);return true}catch(error){return false}
  }
}
const storage = new StorageBridge();

function sanitiseAvatar(raw){
  const base = defaultAvatar();
  if(!raw || typeof raw !== 'object') return base;
  return {
    skin:typeof raw.skin === 'string' ? raw.skin : base.skin,
    hair:typeof raw.hair === 'string' ? raw.hair : base.hair,
    hairColour:typeof (raw.hairColour ?? raw.hairColor) === 'string' ? (raw.hairColour ?? raw.hairColor) : base.hairColour,
    outfit:typeof raw.outfit === 'string' ? raw.outfit : base.outfit,
    topColour:typeof (raw.topColour ?? raw.topColor) === 'string' ? (raw.topColour ?? raw.topColor) : base.topColour,
    accessory:typeof raw.accessory === 'string' ? raw.accessory : base.accessory
  };
}

function sanitiseProps(rawProps){
  if(!Array.isArray(rawProps)) return [];
  return rawProps.slice(0,160).map((prop,index)=>({
    id:String(prop?.id ?? `${Date.now()}-${index}`),
    type:String(prop?.type ?? 'sofa'),
    x:Number.isFinite(Number(prop?.x)) ? Number(prop.x) : 0,
    y:Number.isFinite(Number(prop?.y)) ? Number(prop.y) : 0,
    rot:[0,90,180,270].includes(Number(prop?.rot)) ? Number(prop.rot) : 0,
    on:Boolean(prop?.on),
    circuit:POWER_CIRCUITS.includes(prop?.circuit) ? prop.circuit : (PROP_CIRCUIT_DEFAULTS[String(prop?.type||'')] || 'appliance'),
    cameraAngle:Number.isFinite(Number(prop?.cameraAngle)) ? Number(prop.cameraAngle) : 0
  }));
}

function migrateState(raw,sourceKey){
  const base = defaultState();
  if(!raw || typeof raw !== 'object') return base;
  const merged = {
    ...base,
    profile:typeof raw.profile === 'string' ? raw.profile.slice(0,18) : base.profile,
    cash:Number.isFinite(Number(raw.cash)) ? clamp(Number(raw.cash),0,999999) : base.cash,
    role:['Resident','Officer','Paramedic','Courier','Builder','Mayor','Mischief'].includes(raw.role) ? raw.role : base.role,
    day:Number.isFinite(Number(raw.day)) ? clamp(Math.floor(Number(raw.day)),1,9999) : base.day,
    time:Number.isFinite(Number(raw.time)) ? ((Number(raw.time)%24)+24)%24 : base.time,
    freezeTime:Boolean(raw.freezeTime),
    audio:raw.audio !== false,
    reducedMotion:Boolean(raw.reducedMotion),
    highContrast:Boolean(raw.highContrast),
    cameraEffects:raw.cameraEffects !== false,
    telemetry:raw.telemetry !== false,
    cctvPip:raw.cctvPip !== false,
    utilityTelemetry:raw.utilityTelemetry !== false,
    policeCones:raw.policeCones !== false,
    weatherEffects:raw.weatherEffects !== false,
    weatherMode:['auto','clear','rain','fog'].includes(raw.weatherMode) ? raw.weatherMode : base.weatherMode,
    claimedPlot:Number.isFinite(Number(raw.claimedPlot)) ? Number(raw.claimedPlot) : null,
    mission:raw.mission && typeof raw.mission === 'object' ? deepClone(raw.mission) : null,
    cargo:raw.cargo && typeof raw.cargo === 'object' ? deepClone(raw.cargo) : null,
    bankAlarm:Boolean(raw.bankAlarm),
    firstRun:Boolean(raw.firstRun),
    avatar:sanitiseAvatar(raw.avatar),
    heat:clamp(Number(raw.heat)||0,0,5),
    dirtyBonds:clamp(Number(raw.dirtyBonds)||0,0,999999),
    laundering:raw.laundering && typeof raw.laundering === 'object' ? {amount:clamp(Number(raw.laundering.amount)||0,0,999999),readyAt:Number(raw.laundering.readyAt)||0,rate:clamp(Number(raw.laundering.rate)||.75,.5,.95)} : null,
    affinity:{...base.affinity,...(raw.affinity && typeof raw.affinity === 'object' ? raw.affinity : {})},
    citizenMemory:{...base.citizenMemory,...(raw.citizenMemory && typeof raw.citizenMemory === 'object' ? raw.citizenMemory : {})},
    businesses:{...base.businesses,...(raw.businesses && typeof raw.businesses === 'object' ? raw.businesses : {})},
    fleet:{...base.fleet,...(raw.fleet && typeof raw.fleet === 'object' ? raw.fleet : {}),drivers:Math.max(0,Math.floor(Number(raw.fleet?.drivers ?? (raw.fleet?.hired?1:0))||0))},
    vehicleTune:{...base.vehicleTune,...(raw.vehicleTune && typeof raw.vehicleTune === 'object' ? raw.vehicleTune : {}),nitrous:Boolean(raw.vehicleTune?.nitrous ?? raw.tuningBoost),ownedMods:Array.isArray(raw.vehicleTune?.ownedMods)?raw.vehicleTune.ownedMods.slice(0,40):base.vehicleTune.ownedMods},
    vehicleCondition:clamp(Number(raw.vehicleCondition ?? 100)||100,0,100),
    unlocks:{...base.unlocks,...(raw.unlocks && typeof raw.unlocks === 'object' ? raw.unlocks : {})},
    events:Array.isArray(raw.events) ? raw.events.slice(-30) : [],
    stats:{...base.stats,...(raw.stats && typeof raw.stats === 'object' ? raw.stats : {})},
    position:{
      x:Number.isFinite(Number(raw.position?.x)) ? clamp(Number(raw.position.x),20,WORLD.w-20) : base.position.x,
      y:Number.isFinite(Number(raw.position?.y)) ? clamp(Number(raw.position.y),20,WORLD.h-20) : base.position.y
    },
    flags:{...base.flags,migratedFrom:sourceKey && sourceKey !== SAVE_KEY ? sourceKey : (raw.flags?.migratedFrom ?? null)},
    civicPower:{...base.civicPower,...(raw.civicPower&&typeof raw.civicPower==='object'?raw.civicPower:{})},
    cctv:{...base.cctv,...(raw.cctv&&typeof raw.cctv==='object'?raw.cctv:{})},
    governance:{...base.governance,...(raw.governance&&typeof raw.governance==='object'?raw.governance:{})},
    plotUtilities:{},
    plots:{},
    schema:SCHEMA_VERSION,
    version:VERSION
  };
  const rawPlots = raw.plots && typeof raw.plots === 'object' ? raw.plots : {};
  const rawUtilities=raw.plotUtilities&&typeof raw.plotUtilities==='object'?raw.plotUtilities:{};
  for(const id of [1,2,3,4]){
    const p = rawPlots[id] ?? rawPlots[String(id)] ?? {};
    merged.plots[id] = {
      owner:typeof p.owner === 'string' ? p.owner.slice(0,18) : null,
      house:['modern','cottage','loft','bungalow'].includes(p.house) ? p.house : null,
      props:sanitiseProps(p.props)
    };
    merged.plotUtilities[id]=sanitiseUtility(rawUtilities[id]??rawUtilities[String(id)],id);
  }
  for(const id of ['bank','police','garage','townhall']){const value=merged.civicPower[id]||{};merged.civicPower[id]={online:value.online!==false,restoreAt:Number(value.restoreAt)||0}}
  merged.cctv.pipOpen=Boolean(merged.cctv.pipOpen);merged.cctv.selectedIndex=Math.max(0,Math.floor(Number(merged.cctv.selectedIndex)||0));merged.cctv.views=Math.max(0,Math.floor(Number(merged.cctv.views)||0));
  merged.governance.decree=['standard','curfew','subsidy','green'].includes(merged.governance.decree)?merged.governance.decree:'standard';merged.governance.decreeEndsAt=Math.max(0,Number(merged.governance.decreeEndsAt)||0);merged.governance.prosperity=clamp(Number(merged.governance.prosperity)||35,0,100);merged.governance.peak=clamp(Number(merged.governance.peak)||merged.governance.prosperity,0,100);merged.governance.civicFund=Math.max(0,Number(merged.governance.civicFund)||0);merged.governance.enacted=Math.max(0,Math.floor(Number(merged.governance.enacted)||0));merged.governance.residentVotes=Math.max(0,Math.floor(Number(merged.governance.residentVotes)||0));merged.governance.lastVoteDay=Math.max(0,Math.floor(Number(merged.governance.lastVoteDay)||0));
  return merged;
}

function loadState(){
  const keys = [SAVE_KEY,...LEGACY_KEYS];
  for(const key of keys){
    const rawText = storage.get(key);
    if(!rawText) continue;
    try{
      const migrated = migrateState(JSON.parse(rawText),key);
      if(key !== SAVE_KEY) storage.set(SAVE_KEY,JSON.stringify(migrated));
      return migrated;
    }catch(error){
      console.warn(`Ignoring malformed Town Life save: ${key}`,error);
    }
  }
  return defaultState();
}
let state = loadState();

function normaliseProgressState(){
  const base=defaultState();
  state.affinity={...base.affinity,...(state.affinity||{})};
  for(const id of Object.keys(base.citizenMemory))state.citizenMemory[id]={...base.citizenMemory[id],...(state.citizenMemory?.[id]||{})};
  for(const id of Object.keys(base.businesses)){
    const source=state.businesses?.[id]||{};
    state.businesses[id]={owned:Boolean(source.owned),tier:clamp(Math.floor(Number(source.tier)||0),0,4),stored:clamp(Number(source.stored)||0,0,99999),lastAccruedAt:Number.isFinite(Number(source.lastAccruedAt))?Number(source.lastAccruedAt):null};
  }
  state.fleet={...base.fleet,...(state.fleet||{})};
  state.fleet.drivers=clamp(Math.floor(Number(state.fleet.drivers ?? (state.fleet.hired?1:0))||0),0,3);state.fleet.hired=state.fleet.drivers>0;state.fleet.stored=clamp(Number(state.fleet.stored)||0,0,99999);state.fleet.lastRunAt=Number.isFinite(Number(state.fleet.lastRunAt))?Number(state.fleet.lastRunAt):null;state.fleet.runs=Math.max(0,Math.floor(Number(state.fleet.runs)||0));
  state.vehicleTune={...base.vehicleTune,...(state.vehicleTune||{})};
  state.vehicleTune.ownedMods=Array.from(new Set([...(base.vehicleTune.ownedMods||[]),...(Array.isArray(state.vehicleTune.ownedMods)?state.vehicleTune.ownedMods:[])]));
  state.unlocks={...base.unlocks,...(state.unlocks||{})};
  state.events=Array.isArray(state.events)?state.events.slice(-30):[];
  state.vehicleCondition=clamp(Number(state.vehicleCondition ?? 100)||100,0,100);
  state.heat=clamp(Number(state.heat)||0,0,5);state.dirtyBonds=clamp(Number(state.dirtyBonds)||0,0,999999);state.day=clamp(Math.floor(Number(state.day)||1),1,9999);
  state.plotUtilities=state.plotUtilities&&typeof state.plotUtilities==='object'?state.plotUtilities:{};for(const id of [1,2,3,4])state.plotUtilities[id]=sanitiseUtility(state.plotUtilities[id]??state.plotUtilities[String(id)],id);
  state.civicPower={...base.civicPower,...(state.civicPower||{})};for(const id of ['bank','police','garage','townhall']){const value=state.civicPower[id]||{};state.civicPower[id]={online:value.online!==false,restoreAt:Number(value.restoreAt)||0}}
  state.cctv={...base.cctv,...(state.cctv||{})};state.governance={...base.governance,...(state.governance||{})};state.governance.prosperity=clamp(Number(state.governance.prosperity)||35,0,100);state.governance.peak=clamp(Number(state.governance.peak)||state.governance.prosperity,0,100);
}
normaliseProgressState();
let saveTimer = null;
let saveDirty = false;

function updateSaveBadge(text){$('saveState').textContent = text}
function saveNow(){
  state.schema = SCHEMA_VERSION;
  state.version = VERSION;
  state.position = {x:player?.x ?? state.position.x,y:player?.y ?? state.position.y};
  syncPlots();
  const ok = storage.set(SAVE_KEY,JSON.stringify(state));
  saveDirty = false;
  updateSaveBadge(ok ? (storage.mode === 'local' ? 'LOCAL SAVE READY' : storage.mode === 'session' ? 'SESSION-ONLY SAVE' : 'VOLATILE SAVE') : 'SAVE FAILED');
  return ok;
}
function saveSoon(){
  saveDirty = true;
  clearTimeout(saveTimer);
  updateSaveBadge(storage.mode === 'volatile' ? 'VOLATILE SAVE' : 'SAVING…');
  saveTimer = setTimeout(saveNow,240);
}

const ROLES = {
  Resident:{colour:'#64d8d4',vehicle:'#ff6f61',top:'#64d8d4',hair:'crop',outfit:'casual'},
  Officer:{colour:'#6aa8ff',vehicle:'#244b7d',top:'#1e3a8a',hair:'policeCap',outfit:'uniform'},
  Paramedic:{colour:'#71e6a2',vehicle:'#f3f7fa',top:'#059669',hair:'medicBeanie',outfit:'uniform'},
  Courier:{colour:'#ffc857',vehicle:'#f0a93b',top:'#d97706',hair:'cap',outfit:'jacket'},
  Builder:{colour:'#ff9f68',vehicle:'#7a5c3c',top:'#ea580c',hair:'hardhat',outfit:'workwear'},
  Mayor:{colour:'#ffc857',vehicle:'#4b5364',top:'#7c3aed',hair:'cap',outfit:'uniform'},
  Mischief:{colour:'#c59bff',vehicle:'#301d47',top:'#18181b',hair:'beanie',outfit:'hoodie'}
};

const plots = [
  {id:1,x:120,y:120,w:620,h:520,interiorAlpha:1},
  {id:2,x:2060,y:120,w:620,h:520,interiorAlpha:1},
  {id:3,x:120,y:1560,w:620,h:520,interiorAlpha:1},
  {id:4,x:2060,y:1560,w:620,h:520,interiorAlpha:1}
];
for(const plot of plots){
  const saved = state.plots[plot.id] || {};
  plot.owner = saved.owner || null;
  plot.house = saved.house || null;
  plot.props = sanitiseProps(saved.props);
}
function syncPlots(){
  for(const plot of plots){state.plots[plot.id] = {owner:plot.owner,house:plot.house,props:plot.props}}
}

const locations = [
  {id:'police',name:'Northstar Police',x:920,y:720,w:320,h:220,colour:'#244b7d',door:{x:1080,y:940},interiorAlpha:1},
  {id:'clinic',name:'Community Clinic',x:1560,y:720,w:330,h:220,colour:'#1f6b62',door:{x:1725,y:940},interiorAlpha:1},
  {id:'bank',name:'Civic Bank',x:1260,y:1060,w:330,h:230,colour:'#4b5364',door:{x:1425,y:1290},interiorAlpha:1},
  {id:'cafe',name:'Corner Cafe',x:790,y:1060,w:300,h:230,colour:'#8a5b3c',door:{x:940,y:1290},interiorAlpha:1},
  {id:'market',name:'Town Market',x:1710,y:1060,w:330,h:230,colour:'#43663f',door:{x:1875,y:1290},interiorAlpha:1},
  {id:'depot',name:'Parcel Depot',x:1080,y:1520,w:300,h:220,colour:'#7b5a35',door:{x:1230,y:1740},interiorAlpha:1},
  {id:'garage',name:'Vehicle Garage',x:1450,y:1520,w:300,h:220,colour:'#3d4b63',door:{x:1600,y:1740},interiorAlpha:1},
  {id:'school',name:'Northstar Learning Hub',x:1120,y:350,w:560,h:220,colour:'#6c4d78',door:{x:1400,y:570},interiorAlpha:1},
  {id:'laundry',name:'Northstar Washworks',x:430,y:1060,w:270,h:230,colour:'#2f6072',door:{x:565,y:1290},interiorAlpha:1},
  {id:'townhall',name:'Northstar Town Hall',x:1180,y:70,w:440,h:220,colour:'#6a5a3f',door:{x:1400,y:290},interiorAlpha:1}
];
const locationById = id => locations.find(location => location.id === id);

const BUSINESS_DEFS={
  cafe:{id:'cafe',name:'Corner Cafe Franchise',locationId:'cafe',cost:900,baseYield:18,upgradeCosts:[0,360,720,1250],contact:'sylvia',rank:4,jobFallback:6,description:'Coffee, meals and town gossip create steady neighbourhood trade.'},
  clinic:{id:'clinic',name:'Community Clinic Partnership',locationId:'clinic',cost:1350,baseYield:24,upgradeCosts:[0,480,900,1480],contact:'maya',rank:4,jobFallback:9,description:'A civic health partnership that funds response equipment and wellbeing programmes.'},
  garage:{id:'garage',name:'Northstar Garage Partnership',locationId:'garage',cost:1400,baseYield:28,upgradeCosts:[0,520,980,1600],contact:'jax',rank:3,jobFallback:8,description:'Repairs, role vehicles and tuning work generate higher but costlier returns.'},
  laundry:{id:'laundry',name:'Northstar Washworks',locationId:'laundry',cost:1100,baseYield:22,upgradeCosts:[0,420,820,1380],contact:'sylvia',rank:4,jobFallback:10,description:'A dependable local service with a discreet fictional bond-processing room.'}
};

const CITIZEN_DB={
  arthur:{id:'arthur',name:'Arthur Pendelton',role:'Bank Manager',voicePitch:350,avatar:{skin:'#f5c6a5',hair:'crop',hairColour:'#e2e8f0',outfit:'uniform',topColour:'#334155',accessory:'shades'},baseBark:'Every account must balance before closing.',highBark:'Good to see you. I have kept a quiet ledger aside.',robbedBark:'The vault alarm has ruined my entire morning.',schedule:[
    {id:'home-night',from:0,to:6,x:535,y:515,activity:'At home'},
    {id:'breakfast',from:6,to:8,x:900,y:1215,activity:'Breakfast at Corner Cafe'},
    {id:'bank-shift',from:8,to:18,x:1370,y:1195,activity:'Managing Civic Bank'},
    {id:'park-walk',from:18,to:20,x:900,y:1810,activity:'Evening walk in Northstar Park'},
    {id:'home-evening',from:20,to:24,x:535,y:515,activity:'At home'}],
    tree:{root:{text:'Good day. Please keep financial enquiries orderly. What can the Civic Bank do for you?',choices:[
      {label:'Discuss town finances',next:'chat',affinity:1},{label:'Ask about vault security',next:'security'},{label:'Collect business dividends',action:'collectDividends'},{label:'Balance the security ledger',action:'bribeSecurity',rank:3},{label:'Ask for a tumbler hint',next:'hint',rank:3}]},
      chat:{text:'Northstar grows when residents invest responsibly. Even small businesses can stabilise an entire street.',choices:[{label:'Thanks, Arthur.',close:true}]},
      security:{text:'The safe uses three alternating gates. Direction matters as much as the final angle.',choices:[{label:'Understood.',next:'root'}]},
      hint:{text:'Between us, the first gate favours the upper quadrant. The brighter detent is never accidental.',choices:[{label:'I will remember that.',close:true}]}}
  },
  valerie:{id:'valerie',name:'Sgt. Valerie Cross',role:'Chief of Police',voicePitch:430,avatar:{skin:'#d19b75',hair:'policeCap',hairColour:'#2c1b18',outfit:'uniform',topColour:'#1e3a8a',accessory:'badge'},baseBark:'Eyes open. Keep the roads safe.',highBark:'Your civic record is looking better every day.',robbedBark:'The bank alert has every unit on edge.',schedule:[
    {id:'night-desk',from:0,to:6,x:1080,y:865,activity:'Night desk at Northstar Police'},
    {id:'precinct',from:6,to:14,x:1080,y:865,activity:'Running precinct operations'},
    {id:'bank-patrol',from:14,to:16,x:1445,y:1335,activity:'Bank perimeter patrol'},
    {id:'park-patrol',from:16,to:18,x:980,y:1760,activity:'Community foot patrol'},
    {id:'late-precinct',from:18,to:24,x:1080,y:865,activity:'Evening precinct shift'}],
    tree:{root:{text:'Keep your vehicle under control and respect the town. What is your report?',choices:[
      {label:'Offer civic assistance',next:'chat',affinity:1},{label:'Report suspicious activity',next:'report'},{label:'Ask about response clearance',next:'clearance',rank:2},{label:'Ask about impound access',next:'impound',rank:4}]},
      chat:{text:'Reliable residents make our job easier. I appreciate the support.',choices:[{label:'Stay safe, Sergeant.',close:true}]},
      report:{text:'Bank tampering, reckless driving and late-night garage activity all raise the response level.',choices:[{label:'I will keep watch.',next:'root'}]},
      clearance:{text:'I have marked your record for measured discretion. Minor heat will cool more quickly now.',choices:[{label:'Thank you.',close:true}]},
      impound:{text:'You have earned supervised access to an interceptor chassis from the impound lot.',choices:[{label:'Unlock interceptor trim.',action:'unlockImpound',close:true}]}}
  },
  jax:{id:'jax',name:"Jax 'Wrench' Carter",role:'Master Mechanic',voicePitch:245,avatar:{skin:'#8d5524',hair:'beanie',hairColour:'#2c1b18',outfit:'workwear',topColour:'#ea580c',accessory:'none'},baseBark:'That engine note needs a proper tune.',highBark:'I saved the good parts for you.',robbedBark:'Those sirens are bad for business.',schedule:[
    {id:'home',from:0,to:8,x:535,y:1900,activity:'Off duty at home'},
    {id:'garage-shift',from:8,to:18,x:1710,y:1685,activity:'Working at Northstar Garage'},
    {id:'depot-parts',from:18,to:21,x:1170,y:1660,activity:'Collecting parts at Parcel Depot'},
    {id:'cafe-late',from:21,to:24,x:975,y:1220,activity:'Late meal at Corner Cafe'}],
    tree:{root:{text:'Welcome to the garage. Are we chasing grip, drift angle or outright speed?',choices:[
      {label:'Talk mechanical craft',next:'chat',affinity:1},{label:'Open tuning bench',action:'openTuning'},{label:'Ask about drift suspension',next:'drift',rank:2},{label:'Ask about neon and nitro',next:'nitro',rank:4}]},
      chat:{text:'Treat the throttle like a conversation. The car tells you exactly when the rear tyres are ready to rotate.',choices:[{label:'That makes sense.',close:true}]},
      drift:{text:'I can fit a softer rear setup now. It will make the handbrake more expressive but less forgiving.',choices:[{label:'Open tuning bench.',action:'openTuning',close:true}]},
      nitro:{text:'You have earned access to the locked cabinet: underglow kits and a bounded nitrous injector.',choices:[{label:'Unlock advanced tuning.',action:'unlockNitro',close:true}]}}
  },
  sylvia:{id:'sylvia',name:'Sylvia Vance',role:'Cafe Owner and Information Broker',voicePitch:570,avatar:{skin:'#d19b75',hair:'ponytail',hairColour:'#b55239',outfit:'casual',topColour:'#8a5b3c',accessory:'none'},baseBark:'Fresh coffee and fresh gossip.',highBark:'I heard something useful for you.',robbedBark:'Arthur looked white as a sheet after those sirens.',schedule:[
    {id:'home',from:0,to:6,x:2320,y:520,activity:'At home'},
    {id:'cafe-shift',from:6,to:19,x:875,y:1215,activity:'Running Corner Cafe'},
    {id:'market-run',from:19,to:21,x:1810,y:1220,activity:'Shopping at Town Market'},
    {id:'home-late',from:21,to:24,x:2320,y:520,activity:'At home'}],
    tree:{root:{text:'Fresh roast is on. What is the latest around Northstar?',choices:[
      {label:'Chat about the neighbourhood',next:'chat',affinity:1},{label:'Ask for profitable work',next:'rumour',rank:2},{label:'Take a discreet courier operation',action:'startCovertCourier',rank:3},{label:'Buy police scanner frequencies',action:'buyScanner',rank:3},{label:'Discuss commercial deeds',action:'openBusinesses',rank:4}]},
      chat:{text:'Everyone talks eventually. The trick is knowing which detail matters and which is just steam from the coffee machine.',choices:[{label:'Good advice.',close:true}]},
      rumour:{text:'The laboratory glass manifests pay best, but only a careful driver brings them back intact. I also hear the patrol radios if you know where to listen.',choices:[{label:'I will remember that.',close:true}]}}
  },
  maya:{id:'maya',name:'Dr. Maya Cross',role:'Head Surgeon',voicePitch:500,avatar:{skin:'#f5c6a5',hair:'medicBeanie',hairColour:'#8d5b4c',outfit:'uniform',topColour:'#059669',accessory:'stethoscope'},baseBark:'Stay hydrated and drive carefully.',highBark:'You have become very steady under pressure.',robbedBark:'The sirens have unsettled half my waiting room.',schedule:[
    {id:'home',from:0,to:6,x:2470,y:520,activity:'Resting at home'},
    {id:'clinic-shift',from:6,to:18,x:1660,y:875,activity:'Leading Community Clinic'},
    {id:'cafe-dinner',from:18,to:20,x:980,y:1215,activity:'Dinner at Corner Cafe'},
    {id:'home-evening',from:20,to:24,x:2470,y:520,activity:'At home'}],
    tree:{root:{text:'Hello. Are you feeling well, or preparing for another response call?',choices:[
      {label:'Discuss health and wellbeing',next:'chat',affinity:1},{label:'Ask about pulse timing',next:'pulse'},{label:'Ask for advanced response guidance',next:'advanced',rank:4}]},
      chat:{text:'Safe driving prevents more emergencies than any treatment room can repair.',choices:[{label:'I will remember.',close:true}]},
      pulse:{text:'Anticipate the rhythm rather than chasing it. A calm operator creates a wider treatment window.',choices:[{label:'Thank you, Doctor.',close:true}]},
      advanced:{text:'I have authorised an enhanced response profile for your paramedic role.',choices:[{label:'Enable emergency perk.',action:'unlockMedical',close:true}]}}
  }
};

function scheduleSlotFor(citizen,hour=state.time){return citizen.schedule.find(slot=>hour>=slot.from&&hour<slot.to)||citizen.schedule[citizen.schedule.length-1]}
function citizenMemory(id){state.citizenMemory[id]=state.citizenMemory[id]||{};return state.citizenMemory[id]}
function recordTownEvent(type,detail={}){state.events.push({type,day:state.day,time:state.time,...detail});state.events=state.events.slice(-30);saveDirty=true}
function latestTownEvent(type,maxAgeHours=24){const now=absoluteHour();for(let i=state.events.length-1;i>=0;i--){const event=state.events[i];if(event.type===type&&now-((Number(event.day||1)-1)*24+Number(event.time||0))<=maxAgeHours)return event}return null}
function updateUnlocks(){
  const sylviaRank=affinityRank(Number(state.affinity.sylvia)||0);
  state.unlocks.highYield=sylviaRank>=2;
  state.unlocks.covertCourier=state.unlocks.covertCourier||sylviaRank>=3;
  state.unlocks.businessDeeds=sylviaRank>=4;
  state.unlocks.impound=state.unlocks.impound||affinityRank(Number(state.affinity.valerie)||0)>=4;
}
function heatGainMultiplier(){return affinityRank(Number(state.affinity.valerie)||0)>=2?.78:1}
function addHeat(amount,reason=''){const previous=state.heat;state.heat=clamp(previous+amount*heatGainMultiplier(),0,5);heatHoldTicks=Math.max(heatHoldTicks,600);if(state.heat>previous+.01){if(reason)notify(`Town heat +${(state.heat-previous).toFixed(1)} • ${reason}`,'danger');recordTownEvent('heat',{amount:state.heat-previous,reason})}saveSoon();updateUI(true)}
function heatStars(){const filled=Math.ceil(state.heat-.001);return'★'.repeat(filled)+'☆'.repeat(5-filled)}


const roads = [
  {x:0,y:640,w:WORLD.w,h:320},
  {x:0,y:1320,w:WORLD.w,h:260},
  {x:760,y:0,w:280,h:WORLD.h},
  {x:1760,y:0,w:280,h:WORLD.h},
  {x:1040,y:960,w:720,h:360}
];

const PROP = {
  sofa:{name:'Sofa',w:80,h:34,colour:'#6d7ef6',cost:40,solid:true,interaction:'sit'},
  bed:{name:'Bed',w:52,h:86,colour:'#68bff4',cost:60,solid:true,interaction:'rest'},
  table:{name:'Table',w:72,h:48,colour:'#8b5d35',cost:35,solid:true},
  lamp:{name:'Lamp',w:24,h:24,colour:'#ffe38b',cost:20,solid:false,light:160,interaction:'lamp',watts:60,circuit:'lighting',defaultOn:true},
  desk:{name:'Desk',w:68,h:38,colour:'#b27a4c',cost:45,solid:true},
  plant:{name:'Plant',w:28,h:28,colour:'#66c66e',cost:15,solid:true},
  tv:{name:'Television',w:54,h:18,colour:'#293447',cost:70,solid:true,interaction:'tv',watts:180,circuit:'appliance',defaultOn:false},
  rug:{name:'Rug',w:90,h:60,colour:'#b46a8c',cost:25,solid:false},
  fridge:{name:'Kitchen Fridge',w:36,h:62,colour:'#cbd5e1',cost:180,solid:true,interaction:'fridge',watts:450,circuit:'appliance',defaultOn:true},
  workbench:{name:'Workshop Bench',w:86,h:44,colour:'#d97706',cost:310,solid:true,interaction:'workbench',watts:1200,circuit:'workshop',defaultOn:false},
  cctvCam:{name:'CCTV Camera',w:20,h:20,colour:'#64748b',cost:190,solid:false,interaction:'cctvCam',watts:35,circuit:'security',defaultOn:true},
  cctvMonitor:{name:'Security Monitor',w:58,h:34,colour:'#0f172a',cost:260,solid:true,interaction:'cctvMonitor',watts:120,circuit:'security',defaultOn:true},
  safe:{name:'Electronic Safe',w:48,h:48,colour:'#475569',cost:340,solid:true,interaction:'safe',watts:25,circuit:'security',defaultOn:true},
  smartSwitch:{name:'Smart Wall Switch',w:18,h:18,colour:'#64d8d4',cost:85,solid:false,interaction:'smartSwitch',watts:2,circuit:'lighting',defaultOn:true}
};

const CARGO_TYPES = [
  {id:'express',name:'Express Parcels',mass:120,fragile:false,pay:95,icon:'PARCELS',description:'Light mail with agile handling.'},
  {id:'machinery',name:'Machinery Core',mass:900,fragile:false,pay:210,icon:'MACHINERY',description:'Heavy cargo with long braking distance.'},
  {id:'glassware',name:'Laboratory Glass',mass:320,fragile:true,pay:240,icon:'FRAGILE',description:'High reward, but hard drifts and impacts reduce integrity.'}
];

const player = {
  x:clamp(Number(state.position?.x)||1400,20,WORLD.w-20),
  y:clamp(Number(state.position?.y)||1420,20,WORLD.h-20),
  r:16,
  speed:4.25,
  angle:0,
  walkCycle:0,
  moving:false,
  seatedOn:null
};
const car = {
  active:false,x:player.x+44,y:player.y,vx:0,vy:0,angle:0,w:76,h:40,
  baseMass:800,maxSpeed:12,baseAccel:.24,baseBrake:.16,baseHandling:.052,wheelbase:58,
  grip:.88,driftGrip:.18,inCar:false,lights:true,siren:false,slip:0,rpm:.1,
  gear:1,shiftCooldown:0,shiftTimer:0,steerAngle:0,yawRate:0,weightTransfer:0,frontLoad:50,rearLoad:50,lastForwardVelocity:0,
  collisionCooldown:0,nitroTimer:0,nitroCooldown:0,nitroCharge:1,handbrakeLast:false,lastThrottle:false,lastSkidLeft:null,lastSkidRight:null
};
let keys = Object.create(null);
let buildMode = false;
let demolishMode = false;
let wiringMode = false;
let selectedProp = 'sofa';
let rotation = 0;
let mouse = {x:player.x,y:player.y};
let currentInteraction = null;
let previousFocus = null;
let toastTimer = null;
let uiTimer = 0;
let economyTimer = 0;
let heatHoldTicks = 0;
let colliderDirty = true;
let playerColliders = [];
let vehicleColliders = [];
let structuralRectsByPlot = new Map();
const playerColliderGrid=new SpatialHashGrid(128);
const vehicleColliderGrid=new SpatialHashGrid(128);
const dynamicEntityGrid=new SpatialHashGrid(128);
let spatialFrameCandidates=0;
const ContextSteeringStats={evaluations:0,rays:0,avoidances:0,deadlocksResolved:0,lastFrameAvoidances:0};
const gridSparks=[];
const skidCanvas = document.createElement('canvas');
const skidCtx = skidCanvas.getContext('2d');
skidCanvas.width = WORLD.w;
skidCanvas.height = WORLD.h;
const tyreSmoke=[];
function emitTyreSmoke(x,y,intensity){
  const driftSetup=state.vehicleTune?.tyres==='drift'&&state.heat>=3;const colour=driftSetup?'100,216,212':'225,232,235';const count=Math.min(3,1+Math.floor(intensity*2));
  for(let i=0;i<count;i++)tyreSmoke.push({x:x+(Math.random()-.5)*14,y:y+(Math.random()-.5)*14,vx:(Math.random()-.5)*.45,vy:-.08-Math.random()*.25,r:3+Math.random()*5,life:28+Math.random()*24,colour});
  if(tyreSmoke.length>140)tyreSmoke.splice(0,tyreSmoke.length-140);
}
function updateTyreSmoke(){for(const p of tyreSmoke){p.x+=p.vx;p.y+=p.vy;p.r+=.12;p.life--}for(let i=tyreSmoke.length-1;i>=0;i--)if(tyreSmoke[i].life<=0)tyreSmoke.splice(i,1)}
function drawTyreSmoke(c){c.save();const stride=RenderBudget.profile().smokeStride;for(let i=0;i<tyreSmoke.length;i+=stride){const p=tyreSmoke[i];c.fillStyle=`rgba(${p.colour},${clamp(p.life/52,0,.34)})`;c.beginPath();c.arc(p.x,p.y,p.r,0,Math.PI*2);c.fill()}c.restore()}

class AudioEngine{
  constructor(){
    this.ctx=null;this.master=null;this.output=null;this.dryFilter=null;this.wetGains=[];this.initialised=false;this.engine={};this.skid={};this.siren={};this.grid={};this.alarmTimer=null;this.alarmActive=false;this.lastThrottle=false;this.lastGear=1;this.zone='outdoor';this.lastZoneUpdate=0;
  }
  init(){
    if(this.initialised||!state.audio)return;
    const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
    this.ctx=new AC();const t=this.ctx.currentTime;
    this.master=this.ctx.createGain();this.master.gain.value=1;
    this.output=this.ctx.createGain();this.output.gain.value=.52;this.output.connect(this.ctx.destination);
    this.dryFilter=this.ctx.createBiquadFilter();this.dryFilter.type='lowpass';this.dryFilter.frequency.value=16000;this.master.connect(this.dryFilter);this.dryFilter.connect(this.output);
    for(const [delayTime,level] of [[.045,.07],[.085,.045],[.132,.025]]){
      const delay=this.ctx.createDelay(.3),gain=this.ctx.createGain();delay.delayTime.value=delayTime;gain.gain.value=level;this.master.connect(delay);delay.connect(gain);gain.connect(this.output);this.wetGains.push(gain);
    }

    const o1=this.ctx.createOscillator(),o2=this.ctx.createOscillator(),sub=this.ctx.createOscillator(),filter=this.ctx.createBiquadFilter(),drive=this.ctx.createWaveShaper(),gain=this.ctx.createGain();
    o1.type='sawtooth';o2.type='sawtooth';sub.type='triangle';o1.frequency.value=45;o2.frequency.value=45.6;sub.frequency.value=22.5;filter.type='lowpass';filter.frequency.value=320;filter.Q.value=3.2;gain.gain.value=0;
    const curve=new Float32Array(256);for(let i=0;i<curve.length;i++){const x=i*2/(curve.length-1)-1;curve[i]=Math.tanh(1.7*x)}drive.curve=curve;drive.oversample='2x';
    o1.connect(filter);o2.connect(filter);sub.connect(filter);filter.connect(drive);drive.connect(gain);gain.connect(this.master);o1.start();o2.start();sub.start();this.engine={o1,o2,sub,filter,drive,gain};

    const noiseBuffer=this.ctx.createBuffer(1,this.ctx.sampleRate*2,this.ctx.sampleRate),data=noiseBuffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;
    const noise=this.ctx.createBufferSource(),skidFilter=this.ctx.createBiquadFilter(),skidGain=this.ctx.createGain();noise.buffer=noiseBuffer;noise.loop=true;skidFilter.type='bandpass';skidFilter.frequency.value=1050;skidFilter.Q.value=4;skidGain.gain.value=0;noise.connect(skidFilter);skidFilter.connect(skidGain);skidGain.connect(this.master);noise.start();this.skid={noise,filter:skidFilter,gain:skidGain};

    const sirenOsc=this.ctx.createOscillator(),sirenLfo=this.ctx.createOscillator(),lfoGain=this.ctx.createGain(),sirenGain=this.ctx.createGain();sirenOsc.type='sawtooth';sirenOsc.frequency.value=760;sirenLfo.type='sine';sirenLfo.frequency.value=1.35;lfoGain.gain.value=270;sirenGain.gain.value=0;sirenLfo.connect(lfoGain);lfoGain.connect(sirenOsc.frequency);sirenOsc.connect(sirenGain);sirenGain.connect(this.master);sirenOsc.start();sirenLfo.start();this.siren={osc:sirenOsc,lfo:sirenLfo,lfoGain,gain:sirenGain};
    const gridOsc=this.ctx.createOscillator(),gridFilter=this.ctx.createBiquadFilter(),gridGain=this.ctx.createGain();gridOsc.type='sawtooth';gridOsc.frequency.value=50;gridFilter.type='lowpass';gridFilter.frequency.value=145;gridGain.gain.value=0;gridOsc.connect(gridFilter);gridFilter.connect(gridGain);gridGain.connect(this.master);gridOsc.start();this.grid={osc:gridOsc,filter:gridFilter,gain:gridGain};
    this.initialised=true;
  }
  resume(){if(this.ctx&&this.ctx.state==='suspended')this.ctx.resume()}
  setEnabled(value){state.audio=Boolean(value);if(state.audio){this.init();this.resume();if(this.output)this.output.gain.setTargetAtTime(.52,this.ctx.currentTime,.05);if(state.bankAlarm)this.setAlarm(true)}else if(this.output){this.output.gain.setTargetAtTime(0,this.ctx.currentTime,.05);this.setAlarm(false)}}
  updateAcousticZone(){
    if(!this.initialised)return;const focus=car.inCar?car:player;let zone='outdoor';if(car.inCar)zone='cabin';else{const location=locations.find(l=>rectContains(l,focus.x,focus.y));if(location)zone=location.id==='bank'?'bank':location.id==='garage'?'garage':'indoor'}
    if(zone===this.zone&&performance.now()-this.lastZoneUpdate<500)return;this.zone=zone;this.lastZoneUpdate=performance.now();const t=this.ctx.currentTime;
    const settings=zone==='bank'?{cutoff:11500,wet:[.15,.10,.06]}:zone==='indoor'?{cutoff:12500,wet:[.10,.065,.035]}:zone==='garage'?{cutoff:9000,wet:[.12,.085,.045]}:zone==='cabin'?{cutoff:3600,wet:[.018,.01,.004]}:{cutoff:state.weatherEffects&&WeatherSystem.type()==='rain'?9000:16000,wet:[.045,.025,.012]};
    this.dryFilter.frequency.setTargetAtTime(settings.cutoff,t,.12);this.wetGains.forEach((g,i)=>g.gain.setTargetAtTime(settings.wet[i],t,.12));
  }
  updateEngine(rpm,driving,throttle,gear=1,load=1){
    if(!this.initialised)return;this.updateAcousticZone();const t=this.ctx.currentTime;if(!driving){this.engine.gain.gain.setTargetAtTime(0,t,.08);this.lastThrottle=false;return}
    const normalRpm=clamp(rpm,0,1.12),base=40+Math.pow(normalRpm,1.22)*(150+Math.max(1,gear)*22);this.engine.o1.frequency.setTargetAtTime(base,t,.025);this.engine.o2.frequency.setTargetAtTime(base*1.014,t,.025);this.engine.sub.frequency.setTargetAtTime(base*.5,t,.03);
    this.engine.filter.frequency.setTargetAtTime(250+normalRpm*1900+(throttle?720:0),t,.04);this.engine.gain.gain.setTargetAtTime(.055+normalRpm*.10+clamp(load,0,1)*.025,t,.045);
    if(this.lastThrottle&&!throttle&&normalRpm>.62)this.exhaustPop();this.lastThrottle=throttle;
    if(gear!==this.lastGear){this.gearShift(this.lastGear,gear);this.lastGear=gear}
  }
  updateSkid(slip,surface='asphalt'){if(!this.initialised)return;const t=this.ctx.currentTime,compound=state.vehicleTune?.tyres||'street',boost=compound==='drift'?1.22:compound==='grip'?.82:1,wet=WeatherSystem.type()==='rain'?.78:1;this.skid.gain.gain.setTargetAtTime(slip>.20?Math.min(.24,(slip-.20)*.44*boost*wet):0,t,.03);this.skid.filter.frequency.setTargetAtTime((surface==='grass'?620:930)+slip*820,t,.04)}
  setSiren(value){if(!this.initialised)return;this.siren.gain.gain.setTargetAtTime(value?.14:0,this.ctx.currentTime,.05)}
  beep(frequency=520,duration=.06,volume=.12,type='triangle'){if(!this.initialised)return;const t=this.ctx.currentTime,osc=this.ctx.createOscillator(),gain=this.ctx.createGain();osc.type=type;osc.frequency.setValueAtTime(Math.max(30,frequency),t);gain.gain.setValueAtTime(Math.max(.001,volume),t);gain.gain.exponentialRampToValueAtTime(.001,t+duration);osc.connect(gain);gain.connect(this.master);osc.start(t);osc.stop(t+duration)}
  noiseBurst(duration=.05,volume=.1,frequency=900){if(!this.initialised)return;const t=this.ctx.currentTime,buffer=this.ctx.createBuffer(1,Math.max(1,Math.floor(this.ctx.sampleRate*duration)),this.ctx.sampleRate),data=buffer.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*(1-i/data.length);const source=this.ctx.createBufferSource(),filter=this.ctx.createBiquadFilter(),gain=this.ctx.createGain();source.buffer=buffer;filter.type='bandpass';filter.frequency.value=frequency;filter.Q.value=1.2;gain.gain.value=volume;source.connect(filter);filter.connect(gain);gain.connect(this.master);source.start(t)}
  gearShift(from,to){if(!this.initialised||from===to)return;this.beep(to>from?115:92,.045,.075,'triangle');this.noiseBurst(.035,.045,520+to*90)}
  exhaustPop(){if(!this.initialised)return;const count=1+Math.floor(Math.random()*2);for(let i=0;i<count;i++)setTimeout(()=>{this.beep(135+Math.random()*55,.045,.12,'triangle');this.noiseBurst(.035,.06,480)},i*65)}
  collision(strength=1){this.beep(92,.10,.18*Math.min(1.5,strength),'sawtooth');this.noiseBurst(.09,.08*Math.min(1.5,strength),320);setTimeout(()=>this.beep(48,.14,.14*Math.min(1.5,strength),'sine'),12)}
  horn(){const style=state.vehicleTune?.horn||'classic';if(style==='low'){this.beep(220,.26,.17,'sawtooth');setTimeout(()=>this.beep(275,.19,.11,'triangle'),40)}else if(style==='chime'){this.beep(660,.18,.12,'sine');setTimeout(()=>this.beep(880,.18,.10,'sine'),95)}else if(style==='pulse'){this.beep(420,.08,.14,'square');setTimeout(()=>this.beep(520,.08,.12,'square'),110)}else{this.beep(390,.22,.15,'sawtooth');setTimeout(()=>this.beep(470,.16,.09,'triangle'),35)}}
  speakVoice(basePitch=440){if(!this.initialised)return;for(let i=0;i<4;i++)setTimeout(()=>this.beep(basePitch+(Math.random()-.5)*76,.032,.055,'triangle'),i*48)}
  dialTick(near=false){this.beep(near?1880:520,near?.018:.008,near?.13:.035,near?'sine':'triangle')}
  gateDrop(){this.beep(920,.04,.22,'triangle');setTimeout(()=>this.beep(180,.08,.24,'sine'),18)}
  glassRattle(){this.beep(1600,.035,.12,'sawtooth');setTimeout(()=>this.beep(1370,.045,.09,'triangle'),24)}
  heartbeat(){this.beep(86,.06,.13,'sine');setTimeout(()=>this.beep(64,.08,.09,'sine'),90)}
  scanPing(success=true){this.beep(success?880:170,success?.08:.14,success?.14:.18,success?'sine':'sawtooth')}
  repair(){this.beep(420,.08,.09,'square');setTimeout(()=>this.beep(620,.12,.10,'triangle'),90)}
  setGridHum(loadRatio,powered){if(!this.initialised||!this.grid.gain)return;const target=powered&&loadRatio>.38?clamp((loadRatio-.38)*.085,0,.065):0;this.grid.gain.gain.setTargetAtTime(target,this.ctx.currentTime,.08)}
  switchClick(){this.beep(760,.032,.11,'sine');this.noiseBurst(.018,.025,1200)}
  breakerTrip(){this.beep(118,.09,.27,'sawtooth');this.noiseBurst(.055,.15,2100);setTimeout(()=>this.beep(2300,.026,.12,'triangle'),16)}
  powerRestore(){this.beep(440,.05,.12,'triangle');setTimeout(()=>this.beep(680,.08,.10,'sine'),55)}
  setAlarm(value){this.alarmActive=Boolean(value);if(this.alarmTimer){clearInterval(this.alarmTimer);this.alarmTimer=null}if(!this.alarmActive||!this.initialised||!state.audio)return;let flip=false;const chirp=()=>{if(!this.alarmActive)return;this.beep(flip?1380:930,.16,.10,flip?'sawtooth':'square');flip=!flip};chirp();this.alarmTimer=setInterval(chirp,460)}
}
const audio = new AudioEngine();
function wakeAudio(){if(state.audio){audio.init();audio.resume();if(state.bankAlarm)audio.setAlarm(true)}}

const CIRCUIT_LABELS={lighting:'Lighting',appliance:'Appliances',security:'Security',workshop:'Workshop'};
const SOURCE_LABELS={mains:'Mains 240V',generator:'Generator',solar:'Solar + battery'};
const DECREE_DEFS={
  standard:{id:'standard',name:'Standard Civic Charter',cost:0,duration:0,description:'Normal patrols, prices and utility performance.'},
  curfew:{id:'curfew',name:'Night Curfew Ordinance',cost:320,duration:24,description:'Adds night patrol pressure and doubles lawful night courier rewards.'},
  subsidy:{id:'subsidy',name:'Infrastructure Subsidy',cost:420,duration:30,description:'Reduces deed and upgrade costs and accelerates Washworks processing.'},
  green:{id:'green',name:'Civic Green Initiative',cost:360,duration:30,description:'Subsidises solar installation, raises solar output and improves prosperity.'}
};
function activeDecree(){const g=state.governance;if(!g||g.decree==='standard')return'standard';if(Number(g.decreeEndsAt)>0&&absoluteHour()>=Number(g.decreeEndsAt)){g.decree='standard';g.decreeEndsAt=0;saveDirty=true;return'standard'}return g.decree}
function decreeActive(id){return activeDecree()===id}
function solarElevation(hour=state.time){return Math.max(0,Math.sin(((hour-6)/12)*Math.PI))}
function breakerPosition(plot){const shell=houseShell(plot);return{x:shell.x+24,y:shell.y+24}}
function utilityFor(plotOrId){const id=typeof plotOrId==='object'?plotOrId?.id:Number(plotOrId);if(!id)return null;const existing=state.plotUtilities[id];if(existing&&typeof existing==='object'){const clean=sanitiseUtility(existing,id);Object.assign(existing,clean);state.plotUtilities[id]=existing}else state.plotUtilities[id]=sanitiseUtility(existing,id);return state.plotUtilities[id]}
function circuitForPlaced(placed){return POWER_CIRCUITS.includes(placed?.circuit)?placed.circuit:(PROP_CIRCUIT_DEFAULTS[placed?.type]||'appliance')}
function emitGridSpark(plot){const p=breakerPosition(plot);for(let i=0;i<18;i++)gridSparks.push({x:p.x,y:p.y,vx:(Math.random()-.5)*3.2,vy:(Math.random()-.8)*3.0,life:26+Math.random()*18,r:1+Math.random()*1.8});if(gridSparks.length>90)gridSparks.splice(0,gridSparks.length-90)}
function updateGridSparks(){for(const spark of gridSparks){spark.x+=spark.vx;spark.y+=spark.vy;spark.vy+=.07;spark.life--}for(let i=gridSparks.length-1;i>=0;i--)if(gridSparks[i].life<=0)gridSparks.splice(i,1)}
function drawGridSparks(c){c.save();c.globalCompositeOperation='screen';for(const spark of gridSparks){c.fillStyle=`rgba(255,200,87,${clamp(spark.life/42,0,.9)})`;c.beginPath();c.arc(spark.x,spark.y,spark.r,0,Math.PI*2);c.fill()}c.restore()}

const UtilityManager={
  installCosts(type){const green=decreeActive('green');return type==='generator'?650:type==='solar'?(green?480:900):type==='battery'?(green?360:620):0},
  sourceCapacity(util){if(util.source==='generator')return util.generatorInstalled&&util.generatorFuel>0?3500:0;if(util.source==='solar'){const base=util.solarInstalled?2200*solarElevation()*(decreeActive('green')?1.32:1):0;const battery=util.batteryInstalled&&util.batteryCharge>0?Math.min(1200,250+util.batteryCharge*9.5):0;return base+battery}return 2400},
  demand(plot){const util=utilityFor(plot);let total=0;for(const placed of plot.props){const def=PROP[placed.type];if(!def?.watts||!placed.on)continue;const circuit=circuitForPlaced(placed);if(util.circuits[circuit]===false)continue;total+=def.watts}return total},
  evaluate(plot,elapsedHours=0,allowTrip=true){
    if(!plot?.house)return null;const util=utilityFor(plot);const demand=this.demand(plot);const solarOut=util.solarInstalled?2200*solarElevation()*(decreeActive('green')?1.32:1):0;util.solarOutputWatts=Math.round(solarOut);let available=this.sourceCapacity(util);
    if(util.source==='solar'&&util.batteryInstalled&&elapsedHours>0){const direct=Math.min(demand,solarOut),surplus=Math.max(0,solarOut-demand),shortfall=Math.max(0,demand-solarOut);if(surplus>0)util.batteryCharge=clamp(util.batteryCharge+surplus/2200*elapsedHours*20,0,100);else if(shortfall>0)util.batteryCharge=clamp(util.batteryCharge-shortfall/1200*elapsedHours*14,0,100)}
    if(util.source==='generator'&&util.generatorInstalled&&util.generatorFuel>0&&elapsedHours>0){const before=util.generatorFuel;util.generatorFuel=clamp(util.generatorFuel-elapsedHours*(.42+2.1*Math.min(1,demand/3500)),0,100);state.stats.generatorFuelUsed=Number(state.stats.generatorFuelUsed||0)+(before-util.generatorFuel);if(util.generatorFuel<=0){util.generatorFuel=0;available=0}}
    if(util.source==='mains'&&elapsedHours>0)util.utilityBill=clamp(util.utilityBill+elapsedHours*(.55+demand/1700*.38),0,9999);
    if(util.source==='solar'&&solarOut>50&&elapsedHours>0)state.stats.solarHours=Number(state.stats.solarHours||0)+elapsedHours;
    util.loadWatts=Math.round(demand);util.availableWatts=Math.round(available);
    const sourceReady=util.source==='mains'||(util.source==='generator'&&util.generatorInstalled&&util.generatorFuel>0)||(util.source==='solar'&&util.solarInstalled&&(available>0));
    if(allowTrip&&!util.breakerTripped&&util.mainSwitch&&sourceReady&&demand>available+1)this.trip(plot,'overload');
    util.powered=Boolean(util.mainSwitch&&!util.breakerTripped&&sourceReady&&demand<=available+1);return util;
  },
  trip(plot,reason='overload'){const util=utilityFor(plot);if(util.breakerTripped)return;util.breakerTripped=true;util.powered=false;util.trips++;state.stats.breakerTrips=Number(state.stats.breakerTrips||0)+1;emitGridSpark(plot);audio.breakerTrip();recordTownEvent('breaker-trip',{plot:plot.id,reason,load:util.loadWatts,capacity:util.availableWatts});saveSoon();notify(`Circuit ${reason}: Plot ${plot.id} breaker tripped`,'danger');UtilityConsole.refresh();updateUI(true)},
  reset(plot){const util=utilityFor(plot);util.breakerTripped=false;this.evaluate(plot,0,false);if(!util.mainSwitch||util.loadWatts>util.availableWatts+1||util.availableWatts<=0){util.breakerTripped=true;audio.breakerTrip();notify('Reset rejected: reduce load or restore a valid power source.','danger');return false}util.powered=true;audio.powerRestore();recordTownEvent('breaker-reset',{plot:plot.id});saveSoon();notify('Breaker reset • power restored','lime');UtilityConsole.refresh();updateUI(true);return true},
  propPowered(plot,placed){const util=utilityFor(plot);if(!util||!placed?.on)return false;return Boolean(util.powered&&util.circuits[circuitForPlaced(placed)]!==false)},
  togglePlaced(plot,placed){placed.on=!placed.on;audio.switchClick();this.evaluate(plot,0,true);syncPlots();saveSoon();notify(`${PROP[placed.type]?.name||'Device'} ${placed.on?'on':'off'}`);UtilityConsole.refresh();updateUI(true)},
  setCircuit(plot,circuit,value){const util=utilityFor(plot);util.circuits[circuit]=Boolean(value);audio.switchClick();this.evaluate(plot,0,true);saveSoon();UtilityConsole.refresh();updateUI(true)},
  setMainSwitch(plot,value){const util=utilityFor(plot);util.mainSwitch=Boolean(value);audio.switchClick();this.evaluate(plot,0,true);recordTownEvent('main-isolator',{plot:plot.id,on:util.mainSwitch});saveSoon();notify(util.mainSwitch?'Main isolator closed':'Main isolator opened • property disconnected',util.mainSwitch?'lime':'gold');UtilityConsole.refresh();updateUI(true)},
  selectSource(plot,source){const util=utilityFor(plot);if(source==='generator'&&!util.generatorInstalled)return notify('Install the generator before selecting it.','gold');if(source==='solar'&&!util.solarInstalled)return notify('Install rooftop solar before selecting it.','gold');util.source=source;audio.switchClick();this.evaluate(plot,0,true);saveSoon();UtilityConsole.refresh();updateUI(true)},
  install(plot,type){const util=utilityFor(plot),key=`${type}Installed`;if(util[key])return notify(`${type} is already installed.`,'lime');const cost=this.installCosts(type);if(state.cash<cost)return notify(`Installation costs £${cost}.`,'gold');state.cash-=cost;util[key]=true;if(type==='battery')util.batteryCharge=Math.max(util.batteryCharge,55);audio.repair();recordTownEvent('utility-install',{plot:plot.id,type,cost});saveSoon();notify(`${type.charAt(0).toUpperCase()+type.slice(1)} installed`,'lime');UtilityConsole.refresh();updateUI(true)},
  buyFuel(plot){const util=utilityFor(plot);if(!util.generatorInstalled)return notify('No generator is installed.','gold');const missing=100-util.generatorFuel;if(missing<1)return notify('Generator tank is already full.','lime');const cost=Math.ceil(missing*1.6);if(state.cash<cost)return notify(`Fuel refill costs £${cost}.`,'gold');state.cash-=cost;util.generatorFuel=100;audio.switchClick();saveSoon();notify('Generator fuel refilled','lime');UtilityConsole.refresh();updateUI(true)},
  collectBill(plot){const util=utilityFor(plot),bill=Math.ceil(util.utilityBill||0);if(bill<=0)return notify('No utility bill is due.','lime');if(state.cash<bill)return notify(`Utility bill is £${bill}.`,'gold');state.cash-=bill;util.utilityBill=0;saveSoon();notify(`Paid £${bill} utility bill`,'lime');UtilityConsole.refresh();updateUI(true)},
  updateAll(){const now=absoluteHour();for(const plot of plots){const util=utilityFor(plot);if(!plot.house){util.lastUpdateAt=now;continue}if(util.lastUpdateAt==null)util.lastUpdateAt=now;const elapsed=clamp(now-util.lastUpdateAt,0,6);this.evaluate(plot,elapsed,true);util.lastUpdateAt=now}this.updateHum()},
  updateHum(){const plot=ownedPlot();const util=plot?utilityFor(plot):null;const inside=plot&&plot.house&&rectContains(houseShell(plot),player.x,player.y);audio.setGridHum(util?clamp(util.loadWatts/Math.max(1,util.availableWatts),0,1.4):0,Boolean(inside&&util?.powered))},
  breakerInteraction(){const plot=ownedPlot();if(!plot?.house||car.inCar)return null;const p=breakerPosition(plot),distance=Math.hypot(player.x-p.x,player.y-p.y);if(distance>56)return null;const util=utilityFor(plot);return{label:util.breakerTripped?'Reset tripped breaker':'Open electrical grid console',run:()=>util.breakerTripped?this.reset(plot):UtilityConsole.open(plot)}}
};

const UtilityConsole={
  plot:null,
  open(plot=ownedPlot()){if(!plot?.house||plot.owner!==state.profile)return notify('Claim and build a home before managing utilities.','gold');this.plot=plot;this.render();openModal('utilityModal')},
  refresh(){if(this.plot&&$('utilityModal')?.style.display==='grid')this.render()},
  render(){const plot=this.plot||ownedPlot(),root=$('utilityContent');if(!plot||!root)return;this.plot=plot;UtilityManager.evaluate(plot,0,true);const util=utilityFor(plot);root.innerHTML='';
    const status=document.createElement('div');status.className='card';status.innerHTML=`<div class="eyebrow">Plot ${plot.id} grid</div><h3>${util.breakerTripped?'Breaker tripped':util.powered?'Power online':'Power unavailable'}</h3><p>${util.loadWatts} W demand • ${util.availableWatts} W available • Source ${SOURCE_LABELS[util.source]}</p><div class="meter-bg"><div class="meter-fill" style="width:${clamp(util.loadWatts/Math.max(1,util.availableWatts)*100,0,100)}%;background:${util.breakerTripped?'var(--danger)':util.loadWatts>util.availableWatts*.8?'var(--gold)':'var(--lime)'}"></div></div>`;const sa=document.createElement('div');sa.className='actions';const reset=document.createElement('button');reset.className='btn '+(util.breakerTripped?'danger':'');reset.textContent=util.breakerTripped?'Reset breaker':'Test breaker';reset.onclick=()=>util.breakerTripped?UtilityManager.reset(plot):UtilityManager.evaluate(plot,0,true);sa.appendChild(reset);const isolator=document.createElement('button');isolator.className='btn';isolator.textContent=util.mainSwitch?'Open main isolator':'Close main isolator';isolator.onclick=()=>UtilityManager.setMainSwitch(plot,!util.mainSwitch);sa.appendChild(isolator);const bill=document.createElement('button');bill.className='btn';bill.textContent=`Pay utility bill • £${Math.ceil(util.utilityBill||0)}`;bill.disabled=(util.utilityBill||0)<1;bill.onclick=()=>UtilityManager.collectBill(plot);sa.appendChild(bill);status.appendChild(sa);root.appendChild(status);
    const sources=document.createElement('div');sources.className='card';sources.innerHTML='<div class="eyebrow">Power source hierarchy</div><h3>Select active source</h3>';const sg=document.createElement('div');sg.className='utility-source-grid';for(const source of ['mains','generator','solar']){const b=document.createElement('button');b.className='btn'+(util.source===source?' active':'');b.textContent=SOURCE_LABELS[source]+(source==='generator'?` • ${Math.round(util.generatorFuel)}% fuel`:source==='solar'?` • ${Math.round(util.solarOutputWatts)} W sun`:' • 2400 W');b.disabled=(source==='generator'&&!util.generatorInstalled)||(source==='solar'&&!util.solarInstalled);b.onclick=()=>UtilityManager.selectSource(plot,source);sg.appendChild(b)}sources.appendChild(sg);const ia=document.createElement('div');ia.className='actions';for(const type of ['generator','solar','battery']){const installed=util[`${type}Installed`],button=document.createElement('button');button.className='btn '+(installed?'secondary':'');button.textContent=installed?`${type} installed`:`Install ${type} • £${UtilityManager.installCosts(type)}`;button.disabled=installed;button.onclick=()=>UtilityManager.install(plot,type);ia.appendChild(button)}const fuel=document.createElement('button');fuel.className='btn';fuel.textContent='Refill generator fuel';fuel.disabled=!util.generatorInstalled||util.generatorFuel>=99;fuel.onclick=()=>UtilityManager.buyFuel(plot);ia.appendChild(fuel);sources.appendChild(ia);root.appendChild(sources);
    const circuits=document.createElement('div');circuits.className='card';circuits.innerHTML='<div class="eyebrow">Circuit graph</div><h3>Downstream circuits</h3>';const cg=document.createElement('div');cg.className='circuit-grid';for(const circuit of POWER_CIRCUITS){const b=document.createElement('button');b.className='btn'+(util.circuits[circuit]!==false?' active':'');const draw=plot.props.filter(p=>p.on&&circuitForPlaced(p)===circuit).reduce((sum,p)=>sum+(PROP[p.type]?.watts||0),0);b.textContent=`${CIRCUIT_LABELS[circuit]} • ${draw} W`;b.onclick=()=>UtilityManager.setCircuit(plot,circuit,util.circuits[circuit]===false);cg.appendChild(b)}circuits.appendChild(cg);const cp=document.createElement('p');cp.textContent='Use Wire Circuits in Home Designer to assign individual devices to these branches.';circuits.appendChild(cp);root.appendChild(circuits);
    const security=document.createElement('div');security.className='card';const cameras=plot.props.filter(p=>p.type==='cctvCam').length,monitors=plot.props.filter(p=>p.type==='cctvMonitor').length;security.innerHTML=`<div class="eyebrow">Powered security</div><h3>${cameras} camera${cameras===1?'':'s'} • ${monitors} monitor${monitors===1?'':'s'}</h3><p>Security feeds require an online breaker, enabled security circuit and powered camera node.</p>`;const open=document.createElement('button');open.className='btn secondary';open.textContent='Open property CCTV';open.disabled=cameras<1;open.onclick=()=>CCTVManager.open('property');security.appendChild(open);root.appendChild(security);
    $('utilitySparkStatus').textContent=util.breakerTripped?'Switch off heavy loads before attempting another reset.':'';
  }
};

const STATIC_CCTV=[
  {id:'bank-vault',name:'Civic Bank Vault',locationId:'bank',x:1532,y:1094,angle:Math.PI*.72,range:330,access:()=>state.role==='Officer'||state.role==='Mayor'||state.unlocks.policeScanner},
  {id:'police-yard',name:'Police Dispatch Yard',locationId:'police',x:1210,y:748,angle:Math.PI*.78,range:380,access:()=>state.role==='Officer'||state.role==='Mayor'},
  {id:'garage-entry',name:'Northstar Garage Entrance',locationId:'garage',x:1718,y:1548,angle:Math.PI*.72,range:360,access:()=>state.role==='Officer'||state.role==='Mayor'||ownsBusiness('garage')},
  {id:'townhall-square',name:'Town Hall Square',locationId:'townhall',x:1400,y:276,angle:Math.PI/2,range:420,access:()=>state.role==='Mayor'||state.role==='Officer'}
];
const cctvCanvas=$('cctvFeed'),cctvCtx=cctvCanvas.getContext('2d');
const cctvFeedCache=new Map();
function cctvBufferFor(feed){let entry=cctvFeedCache.get(feed.id);if(!entry){const canvas=document.createElement('canvas');canvas.width=128;canvas.height=96;entry={canvas,ctx:canvas.getContext('2d'),frame:-1};cctvFeedCache.set(feed.id,entry)}return entry}
const CCTVManager={
  feeds(){const feeds=[];for(const plot of plots){if(plot.owner!==state.profile||!plot.house)continue;for(const placed of plot.props){if(placed.type!=='cctvCam')continue;const box=propBox(PROP.cctvCam,placed.x,placed.y,placed.rot);feeds.push({id:`plot-${plot.id}-${placed.id}`,name:`Plot ${plot.id} Camera`,plotId:plot.id,placed,x:box.x+box.w/2,y:box.y+box.h/2,angle:Number(placed.cameraAngle)||placed.rot*Math.PI/180,range:300})}}for(const feed of STATIC_CCTV)if(feed.access())feeds.push(feed);return feeds},
  propertyFeeds(plot){return this.feeds().filter(feed=>feed.plotId===plot?.id)},
  civicPowered(id){const power=state.civicPower[id];if(!power)return true;if(!power.online&&absoluteHour()>=Number(power.restoreAt||0)){power.online=true;power.restoreAt=0;saveDirty=true}return power.online!==false},
  feedPowered(feed){if(feed.plotId){const plot=plots.find(p=>p.id===feed.plotId);return Boolean(plot&&UtilityManager.propPowered(plot,feed.placed))}return this.civicPowered(feed.locationId)},
  open(context='auto'){if(state.cctvPip===false)return notify('Enable CCTV picture-in-picture in Settings.','gold');const feeds=this.feeds();if(!feeds.length)return notify('No accessible CCTV cameras are available. Place a camera or use an authorised civic role.','gold');state.cctv.pipOpen=true;let index=feeds.findIndex(f=>f.id===state.cctv.activeFeed);if(index<0)index=0;if(context==='property'){const propertyIndex=feeds.findIndex(f=>f.plotId);if(propertyIndex>=0)index=propertyIndex}state.cctv.selectedIndex=index;state.cctv.activeFeed=feeds[index].id;state.cctv.views=Number(state.cctv.views||0)+1;state.stats.cctvViews=Number(state.stats.cctvViews||0)+1;$('cctvPip').style.display='block';$('cctvPip').setAttribute('aria-hidden','false');this.render(true);saveSoon()},
  close(){state.cctv.pipOpen=false;$('cctvPip').style.display='none';$('cctvPip').setAttribute('aria-hidden','true');saveSoon()},
  cycle(direction=1){const feeds=this.feeds();if(!feeds.length)return this.close();state.cctv.selectedIndex=(Number(state.cctv.selectedIndex||0)+direction+feeds.length)%feeds.length;state.cctv.activeFeed=feeds[state.cctv.selectedIndex].id;audio.switchClick();this.render(true);saveSoon()},
  current(){const feeds=this.feeds();if(!feeds.length)return null;let index=feeds.findIndex(f=>f.id===state.cctv.activeFeed);if(index<0)index=clamp(Number(state.cctv.selectedIndex)||0,0,feeds.length-1);state.cctv.selectedIndex=index;state.cctv.activeFeed=feeds[index].id;return feeds[index]},
  cutCivicPower(id,hours=2){if(!state.civicPower[id])return false;state.civicPower[id].online=false;state.civicPower[id].restoreAt=absoluteHour()+hours;audio.breakerTrip();recordTownEvent('civic-power-cut',{location:id,hours});saveSoon();notify(`${locationById(id)?.name||id} security power disabled for ${hours} town hours`,'danger');this.render(true);return true},
  worldToFeed(feed,x,y,w,h){const dx=x-feed.x,dy=y-feed.y,cos=Math.cos(-feed.angle),sin=Math.sin(-feed.angle),rx=dx*cos-dy*sin,ry=dx*sin+dy*cos,scale=Math.min(w,h)/(feed.range*.72);return{x:w*.18+rx*scale,y:h/2+ry*scale,forward:rx}},
  drawEntity(c,feed,entity,w,h,colour,r=4){const p=this.worldToFeed(feed,entity.x,entity.y,w,h);if(p.forward<-35||p.x<-12||p.x>w+12||p.y<-12||p.y>h+12)return;c.fillStyle=colour;c.beginPath();c.arc(p.x,p.y,r,0,Math.PI*2);c.fill()},
  drawFrame(feed,targetCanvas,targetCtx,powered=this.feedPowered(feed),updateHud=false){const c=targetCtx,w=targetCanvas.width,h=targetCanvas.height;if(updateHud){$('cctvFeedLabel').textContent=feed.name.toUpperCase();$('cctvStatusText').textContent=powered?'● LIVE':'● NO SIGNAL';$('cctvStatusText').className=powered?'live':'offline'}c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,w,h);if(!powered){c.fillStyle='#050707';c.fillRect(0,0,w,h);for(let y=0;y<h;y+=4){const v=(hashNoise(y,RenderBudget.frameIndex,feed.id.length)*80)|0;c.fillStyle=`rgba(${v},${v},${v},.65)`;c.fillRect(0,y,w,2)}c.fillStyle='#ff4d6d';c.font=`900 ${Math.max(7,Math.round(w/18))}px monospace`;c.textAlign='center';c.fillText('NO SIGNAL / POWER LOSS',w/2,h/2);return false}c.fillStyle='#03140d';c.fillRect(0,0,w,h);c.save();c.beginPath();c.moveTo(4,h/2);c.lineTo(w-4,5);c.lineTo(w-4,h-5);c.closePath();c.clip();for(const location of locations){const corners=[[location.x,location.y],[location.x+location.w,location.y],[location.x+location.w,location.y+location.h],[location.x,location.y+location.h]].map(([x,y])=>this.worldToFeed(feed,x,y,w,h));if(corners.every(p=>p.x<-20||p.x>w+20||p.y<-20||p.y>h+20))continue;c.strokeStyle='rgba(52,211,153,.42)';c.lineWidth=1;c.beginPath();corners.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();c.stroke()}for(const entity of traffic)this.drawEntity(c,feed,entity,w,h,'#34d399',Math.max(1.7,w/50));for(const entity of pedestrians)this.drawEntity(c,feed,entity,w,h,'#6ee7b7',Math.max(1.5,w/55));for(const entity of Object.values(anchorCitizens))if(entity.visible)this.drawEntity(c,feed,entity,w,h,'#fef08a',Math.max(1.8,w/48));for(const unit of interceptors)this.drawEntity(c,feed,unit,w,h,'#60a5fa',Math.max(2,w/45));if(car.active)this.drawEntity(c,feed,car,w,h,'#fb7185',Math.max(2.4,w/38));if(!car.inCar)this.drawEntity(c,feed,player,w,h,'#a7f3d0',Math.max(2.2,w/40));c.restore();c.fillStyle='rgba(16,185,129,.11)';for(let y=0;y<h;y+=3)c.fillRect(0,y,w,1);c.strokeStyle='rgba(110,231,183,.46)';c.strokeRect(w/2-10,h/2-10,20,20);c.fillStyle='#6ee7b7';c.font=`800 ${Math.max(7,Math.round(w/20))}px monospace`;c.textAlign='left';c.fillText(`REC • ${fmtTime(state.time)} • D${state.day}`,6,11);return true},
  render(force=false){if(!state.cctv.pipOpen||state.cctvPip===false){$('cctvPip').style.display='none';return}const cadence=RenderBudget.profile().level==='high'?2:RenderBudget.profile().level==='balanced'?3:5;if(!force&&RenderBudget.frameIndex%cadence!==0)return;const feed=this.current();if(!feed)return this.close();$('cctvPip').style.display='block';this.drawFrame(feed,cctvCanvas,cctvCtx,this.feedPowered(feed),true)},
  monitorFeed(plot,placed){const cameras=this.propertyFeeds(plot);if(!cameras.length)return null;const monitors=plot.props.filter(p=>p.type==='cctvMonitor'),index=Math.max(0,monitors.indexOf(placed));return cameras[index%cameras.length]},
  drawMonitor(c,plot,placed,box){const monitorPowered=UtilityManager.propPowered(plot,placed),feed=this.monitorFeed(plot,placed),feedPowered=Boolean(feed&&monitorPowered&&this.feedPowered(feed));c.fillStyle='#08100d';c.fillRect(-PROP.cctvMonitor.w/2,-PROP.cctvMonitor.h/2,PROP.cctvMonitor.w,PROP.cctvMonitor.h);if(feed){const entry=cctvBufferFor(feed),cadence=RenderBudget.profile().level==='high'?3:RenderBudget.profile().level==='balanced'?5:8;if(entry.frame<0||RenderBudget.frameIndex%cadence===0){this.drawFrame(feed,entry.canvas,entry.ctx,feedPowered,false);entry.frame=RenderBudget.frameIndex}c.drawImage(entry.canvas,-PROP.cctvMonitor.w/2+3,-PROP.cctvMonitor.h/2+3,PROP.cctvMonitor.w-6,PROP.cctvMonitor.h-6)}else{c.fillStyle='#191f24';c.fillRect(-PROP.cctvMonitor.w/2+3,-PROP.cctvMonitor.h/2+3,PROP.cctvMonitor.w-6,PROP.cctvMonitor.h-6)}c.strokeStyle=feedPowered?'#64d8d4':'#475569';c.strokeRect(-PROP.cctvMonitor.w/2,-PROP.cctvMonitor.h/2,PROP.cctvMonitor.w,PROP.cctvMonitor.h)},
  drawCamera(c,plot,placed){const powered=UtilityManager.propPowered(plot,placed);c.rotate(Number(placed.cameraAngle)||0);c.fillStyle='#64748b';c.fillRect(-8,-6,16,12);c.fillStyle=powered?'#b9f27c':'#ff4d6d';c.beginPath();c.arc(8,0,3,0,Math.PI*2);c.fill()},
  renderAccessibleBuffers(force=true){const feeds=this.feeds();for(const feed of feeds){const entry=cctvBufferFor(feed);this.drawFrame(feed,entry.canvas,entry.ctx,this.feedPowered(feed),false);entry.frame=RenderBudget.frameIndex}return feeds.length},
  update(){for(const id of Object.keys(state.civicPower))this.civicPowered(id);if(state.cctv.pipOpen)this.render(false)}
};

const CivicManager={
  effect(){const decree=activeDecree();return{decree,deedFactor:decree==='subsidy'?.72:1,upgradeFactor:decree==='subsidy'?.75:1,launderFactor:decree==='subsidy'?.64:1,solarFactor:decree==='green'?1.32:1,nightPatrolBonus:decree==='curfew'&&nightTime()?1:0,nightCourierFactor:decree==='curfew'&&nightTime()?2:1,yieldFactor:decree==='subsidy'?1.08:decree==='green'?1.05:1}},
  calculateProsperity(){const jobs=Math.min(24,Number(state.stats.jobsCompleted||0)*1.35),businesses=ownedBusinessCount()*7,businessTiers=businessTierTotal()*2.1,fleet=Math.min(9,Number(state.fleet.runs||0)*.16),solar=plots.filter(p=>utilityFor(p)?.solarInstalled).length*3,heatPenalty=state.heat*7,condition=(state.vehicleCondition-50)*.04,decree=activeDecree()!=='standard'?4:0;return clamp(22+jobs+businesses+businessTiers+fleet+solar+condition+decree-heatPenalty,0,100)},
  update(){const target=this.calculateProsperity(),g=state.governance;g.prosperity=lerp(Number(g.prosperity)||35,target,.18);g.peak=Math.max(Number(g.peak)||0,g.prosperity);state.stats.prosperityPeak=Math.max(Number(state.stats.prosperityPeak||0),g.peak);g.lastUpdateAt=absoluteHour();if(activeDecree()==='standard'&&g.decree!=='standard')g.decree='standard';saveDirty=true},
  donate(amount=100){amount=Math.max(25,Math.floor(Number(amount)||100));if(state.cash<amount)return notify(`Civic contribution costs £${amount}.`,'gold');state.cash-=amount;state.governance.civicFund+=amount;state.governance.prosperity=clamp(state.governance.prosperity+amount/100,0,100);recordTownEvent('civic-donation',{amount});saveSoon();notify(`£${amount} added to Northstar civic fund`,'lime');TownLedger.render();updateUI(true)},
  vote(id){if(state.role!=='Resident')return notify('Switch to Resident to cast a civic vote.','gold');if(state.governance.lastVoteDay===state.day)return notify('You have already voted today.','gold');if(!DECREE_DEFS[id]||id==='standard')return;state.governance.lastVoteDay=state.day;state.governance.residentVotes++;state.governance.civicFund+=45;state.governance.prosperity=clamp(state.governance.prosperity+1.5,0,100);recordTownEvent('resident-vote',{decree:id});saveSoon();notify(`Resident vote recorded for ${DECREE_DEFS[id].name}`,'lime');TownLedger.render();updateUI(true)},
  enact(id){const def=DECREE_DEFS[id];if(!def||id==='standard')return;if(state.role!=='Mayor')return notify('Only the Mayor role can enact a decree.','gold');if(state.governance.civicFund<def.cost)return notify(`Civic fund needs £${def.cost}.`,'gold');state.governance.civicFund-=def.cost;state.governance.decree=id;state.governance.decreeEndsAt=absoluteHour()+def.duration;state.governance.enacted++;state.stats.decreesEnacted=Number(state.stats.decreesEnacted||0)+1;state.governance.prosperity=clamp(state.governance.prosperity+3,0,100);recordTownEvent('decree',{decree:id,duration:def.duration});audio.beep(720,.16,.12,'triangle');saveSoon();notify(`${def.name} enacted for ${def.duration} town hours`,'lime');TownLedger.render();updateUI(true)},
  fountainTier(){const p=Number(state.governance.prosperity)||0;return p>=85?3:p>=60?2:p>=35?1:0}
};

const WeatherSystem={
  rain:[],splashes:[],fog:[],lastType:null,
  type(){if(!state.weatherEffects)return'clear';if(state.weatherMode!=='auto')return state.weatherMode;const block=Math.floor(state.time/4);const code=(state.day*5+block*3)%13;return code<=2?'rain':code===3||code===4?'fog':'clear'},
  label(){return this.type()==='rain'?'Rain':this.type()==='fog'?'Fog':'Clear'},
  reset(){
    this.rain=Array.from({length:150},()=>({x:Math.random()*CW,y:Math.random()*CH,len:8+Math.random()*18,speed:9+Math.random()*12,drift:2+Math.random()*3}));
    this.fog=Array.from({length:34},()=>({x:Math.random()*WORLD.w,y:Math.random()*WORLD.h,r:80+Math.random()*170,vx:(Math.random()-.5)*.22,vy:(Math.random()-.5)*.14,a:.025+Math.random()*.055}));
    this.splashes=[];
  },
  update(){
    const type=this.type();if(type!==this.lastType){this.lastType=type;recordTownEvent('weather',{weather:type})}
    if(type==='rain')for(const drop of this.rain){drop.x+=drop.drift;drop.y+=drop.speed;if(drop.y>CH+30){drop.x=Math.random()*CW-40;drop.y=-30;if(Math.random()<.18)this.splashes.push({x:drop.x,y:CH-20-Math.random()*70,life:18,r:2+Math.random()*4})}}
    for(const fog of this.fog){fog.x=(fog.x+fog.vx+WORLD.w)%WORLD.w;fog.y=(fog.y+fog.vy+WORLD.h)%WORLD.h}
    for(const splash of this.splashes)splash.life--;this.splashes=this.splashes.filter(s=>s.life>0).slice(-40);
  },
  drawWorld(c){if(this.type()!=='fog')return;c.save();const stride=RenderBudget.profile().fogStride;for(let i=0;i<this.fog.length;i+=stride){const fog=this.fog[i];if(!pointInCamera(fog.x,fog.y,fog.r+80))continue;const g=c.createRadialGradient(fog.x,fog.y,0,fog.x,fog.y,fog.r);g.addColorStop(0,`rgba(210,225,230,${fog.a})`);g.addColorStop(1,'rgba(210,225,230,0)');c.fillStyle=g;c.beginPath();c.arc(fog.x,fog.y,fog.r,0,Math.PI*2);c.fill()}c.restore()},
  drawScreen(c){if(this.type()!=='rain')return;c.save();c.setTransform(DPR,0,0,DPR,0,0);c.globalCompositeOperation='screen';c.strokeStyle=skyAlpha()>.1?'rgba(185,220,235,.34)':'rgba(145,180,198,.24)';c.lineWidth=1.15;c.beginPath();const stride=RenderBudget.profile().rainStride;for(let i=0;i<this.rain.length;i+=stride){const drop=this.rain[i];c.moveTo(drop.x,drop.y);c.lineTo(drop.x-drop.drift,drop.y-drop.len)}c.stroke();c.strokeStyle='rgba(185,220,235,.28)';for(let i=0;i<this.splashes.length;i+=stride){const splash=this.splashes[i];c.globalAlpha=splash.life/18;c.beginPath();c.ellipse(splash.x,splash.y,splash.r*(1-splash.life/18+.2),splash.r*.35,0,0,Math.PI*2);c.stroke()}c.restore()}
};
window.__MBM_WEATHER_RESIZE__=()=>WeatherSystem.reset();
WeatherSystem.reset();

// Adaptive render budget: simulation remains fixed at 60 Hz while expensive visual
// passes scale independently on constrained devices. The quality changes are bounded,
// reversible and never alter collisions, AI, economy or saved progression.
const RenderBudget={
  level:'high',forced:null,samples:[],frameIndex:0,lastSwitch:0,measuredFps:60,
  current(){return this.forced||this.level},
  profile(){
    const level=this.current();
    if(level==='performance')return{level,policeRays:8,rainStride:4,fogStride:4,smokeStride:2,reflectionStride:2,lightScale:1,lightEvery:4,miniEvery:4};
    if(level==='balanced')return{level,policeRays:18,rainStride:2,fogStride:2,smokeStride:1,reflectionStride:1,lightScale:1,lightEvery:2,miniEvery:2};
    return{level:'high',policeRays:28,rainStride:1,fogStride:1,smokeStride:1,reflectionStride:1,lightScale:1,lightEvery:1,miniEvery:1};
  },
  label(){const level=this.current();return level==='performance'?'Performance':level==='balanced'?'Balanced':'High'},
  observe(elapsed){
    this.frameIndex++;
    if(!Number.isFinite(elapsed)||elapsed<=0||elapsed>160)return;
    this.samples.push(elapsed);if(this.samples.length>120)this.samples.shift();
    if(this.samples.length<45||this.frameIndex%45!==0)return;
    const recent=this.samples.slice(-45).sort((a,b)=>a-b),trim=Math.min(5,Math.floor(recent.length*.1)),windowed=recent.slice(trim,recent.length-trim||recent.length),average=windowed.reduce((sum,value)=>sum+value,0)/Math.max(1,windowed.length);
    this.measuredFps=1000/Math.max(1,average);
    if(this.forced||performance.now()-this.lastSwitch<1500)return;
    let next=this.level;
    if(average>22.5)next='performance';
    else if(average>19&&this.level==='high')next='balanced';
    else if(average<16.9&&this.level==='balanced')next='high';
    else if(average<17.3&&this.level==='performance')next='balanced';
    if(next!==this.level){this.level=next;this.lastSwitch=performance.now();this.samples.length=0}
  },
  force(level=null){
    this.forced=['high','balanced','performance'].includes(level)?level:null;
    if(this.forced)this.level=this.forced;
    this.samples.length=0;this.lastSwitch=performance.now();
    return this.snapshot();
  },
  snapshot(){return{level:this.current(),adaptiveLevel:this.level,forced:this.forced,measuredFps:Number(this.measuredFps.toFixed(1)),frameIndex:this.frameIndex,...this.profile()}}
};

const VehicleTuning={
  optionCost(type,value){const table={gearbox:{balanced:0,short:160,long:220},tyres:{street:0,grip:180,drift:180},underglow:{off:0,cyan:120,coral:120,gold:120,purple:120},horn:{classic:0,low:80,chime:80,pulse:100}};return table[type]?.[value]??0},
  modKey(type,value){return`${type}-${value}`},
  unlocked(type,value){if(type==='underglow'&&value!=='off')return affinityRank(Number(state.affinity.jax)||0)>=4||state.businesses.garage.tier>=2;if(type==='tyres'&&value==='drift')return affinityRank(Number(state.affinity.jax)||0)>=2;return true},
  set(type,value){
    if(!this.unlocked(type,value))return notify('Jax has not unlocked that component yet.','gold');
    const key=this.modKey(type,value),owned=state.vehicleTune.ownedMods.includes(key),cost=this.optionCost(type,value);
    if(!owned&&cost>0){if(state.cash<cost)return notify(`You need £${cost} for that modification.`,'gold');state.cash-=cost;state.vehicleTune.ownedMods.push(key);audio.beep(520,.08,.11,'square')}
    state.vehicleTune[type]=value;saveSoon();notify(`${type} set to ${value}`,'lime');TownLedger.render();updateUI(true);
  },
  unlockNitro(){
    if(affinityRank(Number(state.affinity.jax)||0)<4)return notify('Reach Affinity Rank 4 with Jax first.','gold');
    if(state.vehicleTune.nitrous)return notify('Nitrous injector already installed.','lime');
    const cost=650;if(state.cash<cost)return notify(`The bounded nitrous kit costs £${cost}.`,'gold');state.cash-=cost;state.vehicleTune.nitrous=true;state.vehicleTune.ownedMods.push('nitrous');audio.beep(980,.18,.16,'sawtooth');recordTownEvent('tuning',{mod:'nitrous'});saveSoon();notify('Nitrous injector installed • press N while driving','lime');TownLedger.render();updateUI(true);
  },
  specs(){
    const tune=state.vehicleTune;let accel=1,max=1,handling=1,grip=.88,driftGrip=.18;
    if(tune.gearbox==='short'){accel=1.18;max=.92}else if(tune.gearbox==='long'){accel=.90;max=1.18}
    if(tune.tyres==='grip'){handling=1.12;grip=.94;driftGrip=.34}else if(tune.tyres==='drift'){handling=1.06;grip=.80;driftGrip=.08}
    if(state.unlocks.impound){handling*=1.04;max*=1.04}
    return{accel,max,handling,grip,driftGrip};
  },
  activateNitro(){
    wakeAudio();if(!car.inCar||!car.active)return notify('Enter your vehicle before using nitro.','gold');if(!state.vehicleTune.nitrous)return notify('Jax must install the nitrous injector first.','gold');if(car.nitroCooldown>0)return notify(`Nitro cooling • ${Math.ceil(car.nitroCooldown/60)}s`,'gold');
    car.nitroTimer=78;car.nitroCooldown=480;Camera.addTrauma(.12);audio.beep(120,.35,.18,'sawtooth');recordTownEvent('nitro');notify('Nitro engaged','cyan');
  }
};

function ownsBusiness(id){return Boolean(state.businesses?.[id]?.owned)}
function ownedBusinessCount(){return Object.values(state.businesses||{}).filter(business=>business?.owned).length}
function businessTierTotal(){return Object.values(state.businesses||{}).reduce((total,business)=>total+(business?.owned?Math.max(1,Number(business.tier)||1):0),0)}
function businessSynergySnapshot(){
  return{
    garageWashworks:ownsBusiness('garage')&&ownsBusiness('laundry'),
    cafeClinic:ownsBusiness('cafe')&&ownsBusiness('clinic'),
    townNetwork:ownedBusinessCount()>=3,
    fleetReady:ownedBusinessCount()>=2
  };
}

const BusinessManager={
  canBuy(def){return state.unlocks.businessDeeds||affinityRank(Number(state.affinity[def.contact])||0)>=def.rank||Number(state.stats.jobsCompleted||0)>=def.jobFallback},
  deedCost(def){return Math.ceil(def.cost*CivicManager.effect().deedFactor)},
  upgradeCost(def,tier){return Math.ceil((def.upgradeCosts[tier]||9999)*CivicManager.effect().upgradeFactor)},
  yieldPerHour(id){
    const def=BUSINESS_DEFS[id],business=state.businesses[id];
    if(!def||!business?.owned)return 0;
    let yieldValue=def.baseYield*(business.tier||1)*(1+.10*Math.max(0,(business.tier||1)-1));
    const synergy=businessSynergySnapshot();
    if(synergy.garageWashworks&&['garage','laundry'].includes(id))yieldValue*=1.10;
    if(synergy.cafeClinic&&['cafe','clinic'].includes(id))yieldValue*=1.12;
    if(synergy.townNetwork)yieldValue*=1.05;yieldValue*=CivicManager.effect().yieldFactor;yieldValue*=.82+clamp(Number(state.governance.prosperity)||35,0,100)/100*.36;
    return yieldValue;
  },
  update(){
    const now=absoluteHour();
    for(const [id] of Object.entries(BUSINESS_DEFS)){
      const business=state.businesses[id];
      if(!business.owned){business.lastAccruedAt=now;continue}
      if(business.lastAccruedAt==null)business.lastAccruedAt=now;
      const elapsed=clamp(now-business.lastAccruedAt,0,12);
      if(elapsed>0){business.stored=clamp(business.stored+elapsed*this.yieldPerHour(id),0,5000);business.lastAccruedAt=now;saveDirty=true}
    }
    FleetManager.update(now);
  },
  buy(id){
    const def=BUSINESS_DEFS[id],business=state.businesses[id];if(!def||business.owned)return;
    if(!this.canBuy(def))return notify(`Build rapport with ${CITIZEN_DB[def.contact].name} or complete more jobs first.`,'gold');
    const cost=this.deedCost(def);if(state.cash<cost)return notify(`The deed costs £${cost}.`,'gold');
    state.cash-=cost;business.owned=true;business.tier=1;business.lastAccruedAt=absoluteHour();state.stats.businessesOwned=Number(state.stats.businessesOwned||0)+1;recordTownEvent('business-bought',{business:id});saveSoon();notify(`${def.name} purchased`,'lime');TownLedger.render();updateUI(true);
  },
  upgrade(id){
    const def=BUSINESS_DEFS[id],business=state.businesses[id];if(!business?.owned||business.tier>=4)return;
    const cost=this.upgradeCost(def,business.tier);if(state.cash<cost)return notify(`Upgrade package costs £${cost}.`,'gold');
    state.cash-=cost;business.tier++;recordTownEvent('business-upgrade',{business:id,tier:business.tier});saveSoon();notify(`${def.name} upgraded to Tier ${business.tier}`,'lime');TownLedger.render();updateUI(true);
  },
  collect(id=null){
    this.update();let total=0;
    const ids=id&&id!=='fleet'?[id]:Object.keys(BUSINESS_DEFS);
    for(const key of ids){const business=state.businesses[key];if(business?.owned&&business.stored>0){const amount=Math.floor(business.stored);total+=amount;business.stored-=amount}}
    if(!id||id==='fleet'){const fleetAmount=Math.floor(state.fleet.stored||0);total+=fleetAmount;state.fleet.stored=Math.max(0,(state.fleet.stored||0)-fleetAmount)}
    if(total<=0)return notify('No dividends or fleet proceeds are ready to collect.','gold');
    state.cash+=total;state.stats.dividendsCollected=Number(state.stats.dividendsCollected||0)+total;audio.beep(760,.12,.14,'triangle');recordTownEvent('dividend',{amount:total});saveSoon();notify(`Collected £${total} in town income`,'lime');TownLedger.render();updateUI(true);
  }
};

const FleetManager={
  eligible(){return ownedBusinessCount()>=2},
  maxDrivers(){return clamp(Math.floor(ownedBusinessCount()/2)+Math.floor(businessTierTotal()/8),1,3)},
  hire(){const drivers=Number(state.fleet.drivers)||0;if(!this.eligible())return notify('Own at least two commercial properties before hiring a fleet driver.','gold');if(drivers>=this.maxDrivers())return notify('Upgrade the commercial network before expanding the fleet again.','gold');const cost=850+drivers*575;if(state.cash<cost)return notify(`Fleet recruitment and insurance cost £${cost}.`,'gold');state.cash-=cost;state.fleet.drivers=drivers+1;state.fleet.hired=true;state.fleet.lastRunAt=absoluteHour();state.stats.fleetDriversHired=Number(state.stats.fleetDriversHired||0)+1;recordTownEvent('fleet-hired',{drivers:state.fleet.drivers,cost});audio.beep(580,.15,.12,'square');saveSoon();notify(`Courier driver ${state.fleet.drivers} hired • automated supply runs expanded`,'lime');TownLedger.render();updateUI(true)},
  update(now=absoluteHour()){const drivers=Number(state.fleet.drivers)||0;if(drivers<=0){state.fleet.hired=false;state.fleet.lastRunAt=now;return}state.fleet.hired=true;if(state.fleet.lastRunAt==null)state.fleet.lastRunAt=now;const elapsed=clamp(now-state.fleet.lastRunAt,0,24),runs=Math.floor(elapsed/3);if(runs<=0)return;const perRun=(35+businessTierTotal()*8)*(1+(drivers-1)*.72);state.fleet.stored=clamp(Number(state.fleet.stored||0)+runs*perRun,0,9000);state.fleet.runs=Number(state.fleet.runs||0)+runs*drivers;state.fleet.lastRunAt+=runs*3;recordTownEvent('fleet-supply',{runs:runs*drivers,amount:runs*perRun,drivers});saveDirty=true},
  collect(){BusinessManager.collect('fleet')},
  status(){const drivers=Number(state.fleet.drivers)||0;return drivers>0?`${drivers} driver${drivers===1?'':'s'} active • £${Math.floor(state.fleet.stored||0)} waiting • ${Number(state.fleet.runs||0)} completed runs`:'Hire an NPC courier to automate a supply run every three town hours.'}
};

const LaunderingManager={
  ready(){return state.laundering&&absoluteHour()>=Number(state.laundering.readyAt)},
  start(){if(state.heat>=2)return notify('Town response is too active. Cool heat below 2 stars first.','danger');if(state.laundering)return notify('A Washworks conversion is already running.','gold');if(state.dirtyBonds<=0)return notify('You have no fictional vault bonds to process.','gold');const amount=state.dirtyBonds;state.dirtyBonds=0;let rate=.75;if(state.businesses.laundry.owned)rate+=.07;if(affinityRank(Number(state.affinity.jax)||0)>=4)rate+=.05;rate=clamp(rate,.65,.90);const synergy=businessSynergySnapshot().garageWashworks;if(synergy)rate+=.03;rate=clamp(rate,.65,.93);const duration=(synergy?1.3:2)*CivicManager.effect().launderFactor;state.laundering={amount,readyAt:absoluteHour()+duration,rate};recordTownEvent('bond-process-start',{amount,duration,synergy});saveSoon();notify(`Washworks conversion started • ready in ${duration.toFixed(1)} town hours`,'cyan');TownLedger.render();updateUI(true)},
  collect(){if(!state.laundering)return notify('No conversion is active.','gold');if(!this.ready())return notify(`Conversion ready in ${(state.laundering.readyAt-absoluteHour()).toFixed(1)} town hours.`,'gold');const payout=Math.floor(state.laundering.amount*state.laundering.rate);state.laundering=null;state.cash+=payout;recordTownEvent('bond-process-complete',{amount:payout});audio.beep(680,.16,.15,'triangle');saveSoon();notify(`Converted fictional bonds into £${payout}`,'lime');TownLedger.render();updateUI(true)},
  interaction(){if(state.laundering)return{label:this.ready()?'Collect processed vault bonds':'Check Washworks conversion',run:()=>this.ready()?this.collect():notify(`Ready in ${(state.laundering.readyAt-absoluteHour()).toFixed(1)} town hours.`,'gold')};if(state.dirtyBonds>0)return{label:'Start Washworks bond conversion',run:()=>this.start()};return null}
};

const TownLedger={
  tab:'citizens',
  open(tab='citizens'){this.tab=tab;openModal('ledgerModal');this.render()},
  render(){if(!$('ledgerContent'))return;document.querySelectorAll('[data-ledger-tab]').forEach(button=>button.classList.toggle('active',button.dataset.ledgerTab===this.tab));const root=$('ledgerContent');root.innerHTML='';if(this.tab==='citizens')this.renderCitizens(root);else if(this.tab==='businesses')this.renderBusinesses(root);else if(this.tab==='garage')this.renderGarage(root);else if(this.tab==='operations')this.renderOperations(root);else if(this.tab==='governance')this.renderGovernance(root);else this.renderHeat(root)},
  card(title,eyebrow=''){const card=document.createElement('div');card.className='ledger-card';if(eyebrow){const e=document.createElement('div');e.className='eyebrow';e.textContent=eyebrow;card.appendChild(e)}const h=document.createElement('h3');h.textContent=title;card.appendChild(h);return card},
  pips(card,rank){const p=document.createElement('div');p.className='rank-pips';for(let i=1;i<=5;i++){const s=document.createElement('span');if(i<=rank)s.className='on';p.appendChild(s)}card.appendChild(p)},
  renderCitizens(root){for(const citizen of Object.values(CITIZEN_DB)){const score=Number(state.affinity[citizen.id])||0,rank=affinityRank(score),slot=scheduleSlotFor(citizen);const card=this.card(citizen.name,citizen.role);this.pips(card,rank);const p=document.createElement('p');p.textContent=`Rank ${rank} • ${score} affinity • ${slot.activity}`;card.appendChild(p);const perks=document.createElement('p');perks.textContent=rank>=4?'Senior perk unlocked':rank>=2?'Relationship perk active':'Talk once per town day to build rapport';card.appendChild(perks);root.appendChild(card)}},
  renderBusinesses(root){
    for(const [id,def] of Object.entries(BUSINESS_DEFS)){
      const business=state.businesses[id];
      const card=this.card(def.name,business.owned?`Tier ${business.tier}`:'Commercial deed');
      const summary=document.createElement('p');summary.textContent=def.description;card.appendChild(summary);
      const detail=document.createElement('p');detail.textContent=business.owned?`Yield £${this.money(BusinessManager.yieldPerHour(id))}/town hour • Stored £${Math.floor(business.stored)}`:`Purchase £${BusinessManager.deedCost(def)} • Unlock via ${CITIZEN_DB[def.contact].name} Rank ${def.rank} or ${def.jobFallback} jobs`;card.appendChild(detail);
      const actions=document.createElement('div');actions.className='actions';
      if(!business.owned){const buy=document.createElement('button');buy.className='btn primary';buy.textContent='Purchase deed';buy.disabled=!BusinessManager.canBuy(def);buy.onclick=()=>BusinessManager.buy(id);actions.appendChild(buy)}
      else{const collect=document.createElement('button');collect.className='btn secondary';collect.textContent='Collect income';collect.onclick=()=>BusinessManager.collect(id);actions.appendChild(collect);if(business.tier<4){const upgrade=document.createElement('button');upgrade.className='btn';upgrade.textContent=`Upgrade £${BusinessManager.upgradeCost(def,business.tier)}`;upgrade.onclick=()=>BusinessManager.upgrade(id);actions.appendChild(upgrade)}}
      card.appendChild(actions);root.appendChild(card);
    }
    const synergy=businessSynergySnapshot();
    const synergyCard=this.card('Commercial synergies','Supply-chain network');
    const synergyText=document.createElement('p');
    const active=[];
    if(synergy.garageWashworks)active.push('Garage + Washworks: free repairs, 35% faster bond conversion and higher joint yield');
    if(synergy.cafeClinic)active.push('Cafe + Clinic: quicker on-foot movement and a wider medical timing window');
    if(synergy.townNetwork)active.push('Town network: 5% yield bonus across every owned business');
    synergyText.textContent=active.length?active.join('\n'):'Purchase complementary businesses to activate systemic bonuses.';synergyText.style.whiteSpace='pre-line';synergyCard.appendChild(synergyText);root.appendChild(synergyCard);
    const fleetCard=this.card('NPC courier fleet','Automated supply chain');
    const fleetText=document.createElement('p');fleetText.textContent=FleetManager.status();fleetCard.appendChild(fleetText);
    const fleetActions=document.createElement('div');fleetActions.className='actions';
    const drivers=Number(state.fleet.drivers)||0;if(drivers<FleetManager.maxDrivers()){const hire=document.createElement('button');hire.className='btn primary';hire.textContent=`Hire driver ${drivers+1} • £${850+drivers*575}`;hire.disabled=!FleetManager.eligible();hire.onclick=()=>FleetManager.hire();fleetActions.appendChild(hire)}if(drivers>0){const collectFleet=document.createElement('button');collectFleet.className='btn secondary';collectFleet.textContent='Collect fleet proceeds';collectFleet.disabled=(state.fleet.stored||0)<1;collectFleet.onclick=()=>FleetManager.collect();fleetActions.appendChild(collectFleet)}
    fleetCard.appendChild(fleetActions);root.appendChild(fleetCard);
  },
  money(value){return Math.round(value)},
  renderGarage(root){
    const conditionCard=this.card('Vehicle condition','Maintenance and economic friction');
    const conditionText=document.createElement('p');
    const missing=Math.max(0,100-state.vehicleCondition),synergy=businessSynergySnapshot().garageWashworks,repairCost=synergy?0:Math.ceil(missing*2.4);
    conditionText.textContent=`Condition ${Math.round(state.vehicleCondition)}% • ${missing<.5?'No maintenance required':synergy?'Garage + Washworks network covers this repair':`Full repair £${repairCost}`}`;
    conditionCard.appendChild(conditionText);
    const repair=document.createElement('button');repair.className='btn primary';repair.textContent=missing<.5?'Vehicle healthy':synergy?'Repair through business network':'Repair vehicle';repair.disabled=missing<.5;repair.onclick=()=>{repairVehicle();this.render()};conditionCard.appendChild(repair);root.appendChild(conditionCard);
    const groups=[['gearbox','Gearbox',[['balanced','Balanced'],['short','Short ratios'],['long','Long ratios']]],['tyres','Tyre compound',[['street','Street'],['grip','High grip'],['drift','Drift rubber']]],['underglow','Underglow',[['off','Off'],['cyan','Cyan'],['coral','Coral'],['gold','Gold'],['purple','Purple']]],['horn','Horn synth',[['classic','Classic'],['low','Low brass'],['chime','Chime'],['pulse','Pulse']]]];
    for(const [type,title,items] of groups){const card=this.card(title,'Vehicle tuning');const grid=document.createElement('div');grid.className='choice-grid';for(const [value,label] of items){const button=document.createElement('button');button.className='btn'+(state.vehicleTune[type]===value?' secondary':'');const cost=VehicleTuning.optionCost(type,value),owned=state.vehicleTune.ownedMods.includes(VehicleTuning.modKey(type,value));button.textContent=`${label}${!owned&&cost?` • £${cost}`:''}`;button.disabled=!VehicleTuning.unlocked(type,value);button.onclick=()=>VehicleTuning.set(type,value);grid.appendChild(button)}card.appendChild(grid);root.appendChild(card)}
    const nitro=this.card('Bounded nitrous injector','Advanced Jax tuning');const p=document.createElement('p');p.textContent=state.vehicleTune.nitrous?'Installed. Press N or Nitro while driving; an eight-second cooldown prevents constant boost.':'Requires Jax Affinity Rank 4 and £650.';nitro.appendChild(p);const button=document.createElement('button');button.className='btn primary';button.textContent=state.vehicleTune.nitrous?'Installed':'Install nitrous';button.disabled=state.vehicleTune.nitrous||affinityRank(Number(state.affinity.jax)||0)<4;button.onclick=()=>VehicleTuning.unlockNitro();nitro.appendChild(button);root.appendChild(nitro);
  },
  renderOperations(root){
    const activeCard=this.card('Active operation','Live contract state');
    const activeText=document.createElement('p');
    if(state.mission){
      const target=missionPoint();
      const parts=[missionText(state.mission),`Stage: ${state.mission.stage||'active'}`];
      if(state.cargo)parts.push(`Cargo: ${state.cargo.name} • ${Math.round(Number(state.cargo.integrity)||0)}% integrity`);
      if(state.mission.type==='covert-courier')parts.push(`Exposure: ${(Number(state.mission.exposure)||0).toFixed(1)}s • ${state.mission.detected?'Identity compromised':'No confirmed visual contact'}`);
      if(target)parts.push(`Target coordinates: ${Math.round(target.x)}, ${Math.round(target.y)}`);
      activeText.textContent=parts.join('\n');
    }else activeText.textContent='No active operation. Choose a contract chain below.';
    activeText.style.whiteSpace='pre-line';activeCard.appendChild(activeText);
    if(state.mission){const abort=document.createElement('button');abort.className='btn danger';abort.textContent='Abandon operation';abort.onclick=()=>abandonOperation();activeCard.appendChild(abort)}
    root.appendChild(activeCard);

    const covert=this.card('Sylvia’s covert courier chain','Stealth contract');
    const covertText=document.createElement('p');covertText.textContent=state.unlocks.covertCourier?'Cafe hand-off → low-slip evasion → Washworks transfer → delayed fictional bond conversion. Police visual contact reduces the final bond value.':'Requires Sylvia Affinity Rank 3. Talk with her at Corner Cafe on separate town days.';covert.appendChild(covertText);
    const covertButton=document.createElement('button');covertButton.className='btn primary';covertButton.textContent=state.mission?'Operation already active':'Start covert courier';covertButton.disabled=!state.unlocks.covertCourier||Boolean(state.mission)||state.heat>=2;covertButton.onclick=()=>{closeModal('ledgerModal');startCovertCourierOperation()};covert.appendChild(covertButton);root.appendChild(covert);

    const heist=this.card('Civic Bank escape chain','Mischief operation');
    const heistText=document.createElement('p');heistText.textContent='Reach the vault on foot → solve three directional tumblers → break police line of sight → secure unprocessed bonds at Northstar Garage → cool heat → convert at Washworks.';heist.appendChild(heistText);
    const heistButton=document.createElement('button');heistButton.className='btn warn';heistButton.textContent=state.bankAlarm?'Bank security already active':'Begin bank operation';heistButton.disabled=Boolean(state.mission)||state.bankAlarm;heistButton.onclick=()=>{closeModal('ledgerModal');state.role='Mischief';startRoleJob()};heist.appendChild(heistButton);root.appendChild(heist);

    const civic=this.card('Civic role contracts','Repeatable work');
    const civicText=document.createElement('p');civicText.textContent='Courier manifests, pulse stabilisation, police evidence scans, builder contracts and resident errands remain available through the Job control. High-grade businesses and citizen affinity improve their timing and yield.';civic.appendChild(civicText);
    const civicButton=document.createElement('button');civicButton.className='btn secondary';civicButton.textContent=state.mission?'Finish current operation':'Start current role job';civicButton.disabled=Boolean(state.mission);civicButton.onclick=()=>{closeModal('ledgerModal');startRoleJob()};civic.appendChild(civicButton);root.appendChild(civic);
  },
  renderGovernance(root){
    CivicManager.update();const g=state.governance,effect=CivicManager.effect();const summary=this.card('Town Prosperity Index','Civic legacy');const meter=document.createElement('div');meter.className='governance-meter';const fill=document.createElement('span');fill.style.width=`${clamp(g.prosperity,0,100)}%`;meter.appendChild(fill);summary.appendChild(meter);const p=document.createElement('p');p.textContent=`Prosperity ${Math.round(g.prosperity)} / 100 • Peak ${Math.round(g.peak)} • Fountain tier ${CivicManager.fountainTier()} • Civic fund £${Math.floor(g.civicFund)}`;summary.appendChild(p);const active=document.createElement('p');const def=DECREE_DEFS[effect.decree];active.textContent=effect.decree==='standard'?'No temporary decree is active.':`${def.name} active • ${(state.governance.decreeEndsAt-absoluteHour()).toFixed(1)} town hours remaining`;summary.appendChild(active);const donate=document.createElement('button');donate.className='btn secondary';donate.textContent='Contribute £100 to civic fund';donate.onclick=()=>CivicManager.donate(100);summary.appendChild(donate);root.appendChild(summary);
    for(const [id,defn] of Object.entries(DECREE_DEFS)){if(id==='standard')continue;const card=this.card(defn.name,`£${defn.cost} civic fund • ${defn.duration} hours`);card.classList.add('decree-card');if(effect.decree===id)card.classList.add('active');const desc=document.createElement('p');desc.textContent=defn.description;card.appendChild(desc);const actions=document.createElement('div');actions.className='actions';if(state.role==='Mayor'){const enact=document.createElement('button');enact.className='btn primary';enact.textContent=effect.decree===id?'Active decree':'Enact decree';enact.disabled=effect.decree===id||g.civicFund<defn.cost;enact.onclick=()=>CivicManager.enact(id);actions.appendChild(enact)}else{const vote=document.createElement('button');vote.className='btn';vote.textContent=state.role==='Resident'?'Cast resident vote':'Switch to Resident to vote';vote.disabled=state.role!=='Resident'||g.lastVoteDay===state.day;vote.onclick=()=>CivicManager.vote(id);actions.appendChild(vote)}card.appendChild(actions);root.appendChild(card)}
  },
  renderHeat(root){
    const overview=this.card('Town response','Heat, line of sight and fictional bonds');
    const response=document.createElement('p');response.textContent=`${heatStars()} • ${state.heat.toFixed(1)} / 5 heat • Police ${aggregatePoliceState().toLowerCase()} • £${Math.floor(state.dirtyBonds)} unprocessed fictional vault bonds`;overview.appendChild(response);
    const intelligence=document.createElement('p');intelligence.textContent=state.unlocks.policeScanner?'Scanner intelligence active: interceptor blips remain visible through fog.':'Police scanner locked: reach Sylvia Rank 3, then purchase frequencies for £220 cash or £150 in fictional bonds.';overview.appendChild(intelligence);
    if(!state.unlocks.policeScanner&&affinityRank(Number(state.affinity.sylvia)||0)>=3){const scan=document.createElement('button');scan.className='btn secondary';scan.textContent='Purchase scanner frequencies';scan.onclick=()=>{buyPoliceScanner();this.render()};overview.appendChild(scan)}
    if(state.laundering){const status=document.createElement('p');status.textContent=thisLaunderingText();overview.appendChild(status);const collect=document.createElement('button');collect.className='btn secondary';collect.textContent=LaunderingManager.ready()?'Collect conversion':'Conversion running';collect.disabled=!LaunderingManager.ready();collect.onclick=()=>LaunderingManager.collect();overview.appendChild(collect)}
    root.appendChild(overview);

    const operations=this.card('Operations record','Emergent contract outcomes');
    const operationText=document.createElement('p');operationText.textContent=`Covert supply runs ${Number(state.stats.smugglingRuns||0)} • Stealth escapes ${Number(state.stats.stealthEscapes||0)} • Police sightings ${Number(state.stats.policeSightings||0)} • Repair spend £${Number(state.stats.repairsPaid||0)}`;operations.appendChild(operationText);
    if(state.unlocks.covertCourier&&!state.mission){const covert=document.createElement('button');covert.className='btn warn';covert.textContent='Start Sylvia covert courier operation';covert.disabled=state.heat>=2;covert.onclick=()=>{closeModal('ledgerModal');startCovertCourierOperation()};operations.appendChild(covert)}
    root.appendChild(operations);

    const events=this.card('Recent town memory','Event and rumour ledger');
    const list=document.createElement('p');list.textContent=state.events.length?state.events.slice(-10).reverse().map(e=>`Day ${e.day} ${fmtTime(e.time)} • ${String(e.type).replaceAll('-',' ')}`).join('\n'):'No major town events recorded yet.';list.style.whiteSpace='pre-line';events.appendChild(list);root.appendChild(events);
  },
  refresh(){if($('ledgerModal').style.display==='grid')this.render()}
};
function thisLaunderingText(){if(!state.laundering)return'';return LaunderingManager.ready()?`Washworks conversion ready: £${Math.floor(state.laundering.amount*state.laundering.rate)}`:`Washworks conversion ready in ${(state.laundering.readyAt-absoluteHour()).toFixed(1)} town hours`}

function bribeArthurSecurity(){
  if(affinityRank(Number(state.affinity.arthur)||0)<3)return notify('Arthur will not discuss a private ledger at this affinity rank.','gold');
  if(!state.bankAlarm&&state.heat<.8)return notify('The Civic Bank ledger is already calm.','lime');
  const cost=state.bankAlarm?240:150;
  if(state.cash<cost)return notify(`Balancing the security ledger requires £${cost}.`,'gold');
  state.cash-=cost;
  state.bankAlarm=false;audio.setAlarm(false);$('alert').style.display='none';
  state.heat=Math.max(0,state.heat-1.45);heatHoldTicks=90;
  for(const unit of interceptors){unit.detection=0;unit.searchTicks=Math.min(unit.searchTicks||0,90);unit.state='LOST'}
  const memory=citizenMemory('arthur');memory.bribes=Number(memory.bribes||0)+1;memory.lastBribeDay=state.day;
  recordTownEvent('security-ledger-balanced',{cost});saveSoon();notify(`Arthur balanced the security ledger • heat reduced • £${cost}`,'lime');updateUI(true);
}

function buyPoliceScanner(){
  if(state.unlocks.policeScanner)return notify('Police scanner frequencies already loaded.','lime');const bondCost=150,cashCost=220;if(state.dirtyBonds>=bondCost){state.dirtyBonds-=bondCost;notify(`Scanner frequencies exchanged for £${bondCost} in fictional bonds`,'gold')}else if(state.cash>=cashCost){state.cash-=cashCost;notify(`Police scanner frequencies purchased • £${cashCost}`,'gold')}else return notify(`Scanner access needs £${cashCost} cash or £${bondCost} in fictional bonds.`,'gold');state.unlocks.policeScanner=true;recordTownEvent('police-scanner');audio.beep(1040,.12,.12,'square');saveSoon();updateUI(true)
}
function startCovertCourierOperation(){
  if(state.mission)return notify('Finish the current operation first.','gold');if(state.heat>=2)return notify('Sylvia will not release the package while town heat is this high.','danger');state.role='Courier';state.cargo={id:'covert',name:'Unregistered Signal Crate',mass:280,fragile:true,pay:420,integrity:100,covert:true};state.mission={type:'covert-courier',stage:'deliver',target:'laundry',startedAt:absoluteHour(),exposure:0};addHeat(1.35,'covert manifest flagged');recordTownEvent('covert-operation-start');audio.beep(520,.08,.10,'square');notify('Covert operation active • deliver Sylvia’s crate to Washworks without visual contact','danger');updateCargoHUD();saveSoon();updateUI(true)
}

const DialogueManager={
  active:null,node:'root',ctx:$('speakerCanvas').getContext('2d'),
  open(id){const citizen=CITIZEN_DB[id];if(!citizen)return;keys=Object.create(null);previousFocus=document.activeElement;this.active=citizen;this.node='root';$('dialogueBox').style.display='flex';$('dialogueBox').setAttribute('aria-hidden','false');this.render();requestAnimationFrame(()=>focusFirstControl($('dialogueBox')));audio.speakVoice?.(citizen.voicePitch)},
  contextualText(citizen,node){if(node!=='root')return citizen.tree[node].text;const memory=citizenMemory(citizen.id);if(state.bankAlarm&&citizen.robbedBark)return citizen.robbedBark;if(memory.bumped>0)return`I remember that close call with your vehicle. Keep your distance this time.`;if(state.heat>=3)return`The whole town can feel the response pressure. You should lower that heat.`;return citizen.tree.root.text},
  render(){if(!this.active)return;const citizen=this.active,tree=citizen.tree[this.node]||citizen.tree.root,score=Number(state.affinity[citizen.id])||0,rank=affinityRank(score),slot=scheduleSlotFor(citizen);$('diaRole').textContent=citizen.role;$('diaName').textContent=citizen.name;$('diaAffinity').textContent=`Affinity Rank ${rank} • ${score}`;$('diaActivity').textContent=slot.activity;$('dialogueText').textContent=`“${this.contextualText(citizen,this.node)}”`;this.drawPortrait();const wrap=$('dialogueChoices');wrap.innerHTML='';tree.choices.forEach((choice,index)=>{const button=document.createElement('button');button.className='btn '+(choice.affinity?'warn':'secondary');button.textContent=`${index+1}. ${choice.label}${choice.rank&&rank<choice.rank?` • Rank ${choice.rank}`:''}`;button.disabled=Boolean(choice.rank&&rank<choice.rank);button.onclick=()=>this.choose(index);wrap.appendChild(button)});const leave=document.createElement('button');leave.className='btn';leave.textContent='0. Goodbye';leave.onclick=()=>this.close();wrap.appendChild(leave)},
  drawPortrait(){const c=this.ctx;c.clearRect(0,0,58,58);c.save();c.translate(29,29);c.scale(1.45,1.45);drawAvatarRig(c,this.active.avatar,0,0,false,null);c.restore()},
  choose(index){if(!this.active)return;const node=this.active.tree[this.node]||this.active.tree.root,choice=node.choices[index];if(!choice)return;const rank=affinityRank(Number(state.affinity[this.active.id])||0);if(choice.rank&&rank<choice.rank)return;
    if(choice.affinity){const memory=citizenMemory(this.active.id);if(Number(memory.lastAffinityDay)===state.day)notify(`${this.active.name} has already had a meaningful chat with you today.`,'gold');else{state.affinity[this.active.id]=(Number(state.affinity[this.active.id])||0)+choice.affinity;memory.lastAffinityDay=state.day;memory.conversations=Number(memory.conversations||0)+1;state.stats.namedConversations=Number(state.stats.namedConversations||0)+1;recordTownEvent('rapport',{citizen:this.active.id});audio.beep(650,.07,.09,'sine');notify(`Rapport increased with ${this.active.name}`,'lime');updateUnlocks();saveSoon()}}
    if(choice.action)this.action(choice.action);if(choice.close){this.close();return}if(choice.next){this.node=choice.next;this.render();audio.speakVoice?.(this.active.voicePitch)}else if(!choice.action)this.close();
  },
  action(action){if(action==='collectDividends')BusinessManager.collect();else if(action==='openBusinesses'){this.close();TownLedger.open('businesses')}else if(action==='openTuning'){this.close();TownLedger.open('garage')}else if(action==='unlockNitro')VehicleTuning.unlockNitro();else if(action==='startCovertCourier'){this.close();startCovertCourierOperation()}else if(action==='buyScanner')buyPoliceScanner();else if(action==='bribeSecurity')bribeArthurSecurity();else if(action==='unlockImpound'){state.unlocks.impound=true;recordTownEvent('impound-unlocked');saveSoon();notify('Interceptor chassis trim unlocked','lime')}else if(action==='unlockMedical'){state.unlocks.medicalResponse=true;saveSoon();notify('Advanced paramedic response profile enabled','lime')}},
  close(){$('dialogueBox').style.display='none';$('dialogueBox').setAttribute('aria-hidden','true');this.active=null;this.node='root';if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});previousFocus=null}
};


function notify(message,tone='cyan'){
  const element = $('toast');
  element.textContent = message;
  element.style.borderColor = tone === 'danger' ? 'var(--danger)' : tone === 'gold' ? 'var(--gold)' : tone === 'lime' ? 'var(--lime)' : 'var(--cyan)';
  element.style.display = 'block';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=>{element.style.display='none'},2300);
}
function addMoney(amount,reason=''){
  state.cash = clamp(state.cash + amount,0,999999);
  notify(`${amount>=0?'+':''}£${Math.round(amount)}${reason?` • ${reason}`:''}`,amount>=0?'cyan':'gold');
  saveSoon();
}
function completeJob(amount,message){
  if(amount) addMoney(amount,message);
  state.stats.jobsCompleted = Number(state.stats.jobsCompleted||0)+1;
  recordTownEvent('job-complete',{role:state.role,reward:Number(amount)||0});
  state.mission = null;
  state.cargo = null;
  updateCargoHUD();
  saveSoon();
  updateUI(true);
}

function houseShell(plot){return{x:plot.x+52,y:plot.y+52,w:plot.w-104,h:plot.h-104,doorX:plot.x+plot.w/2}}
function addOuterWalls(target,rect,doorX,tag){
  const thickness = 12;
  const doorWidth = 72;
  target.push({x:rect.x,y:rect.y,w:rect.w,h:thickness,tag});
  target.push({x:rect.x,y:rect.y,w:thickness,h:rect.h,tag});
  target.push({x:rect.x+rect.w-thickness,y:rect.y,w:thickness,h:rect.h,tag});
  const leftWidth = doorX-doorWidth/2-rect.x;
  const rightX = doorX+doorWidth/2;
  const rightWidth = rect.x+rect.w-rightX;
  if(leftWidth>0) target.push({x:rect.x,y:rect.y+rect.h-thickness,w:leftWidth,h:thickness,tag});
  if(rightWidth>0) target.push({x:rightX,y:rect.y+rect.h-thickness,w:rightWidth,h:thickness,tag});
}
function housePartitionRects(plot){
  if(!plot.house) return [];
  const s = houseShell(plot);
  const t = 10;
  const parts = [];
  if(plot.house === 'cottage'){
    const x = s.x+s.w/2-t/2;
    parts.push({x,y:s.y,w:t,h:s.h/2-34,tag:`plot-${plot.id}-partition`});
    parts.push({x,y:s.y+s.h/2+34,w:t,h:s.h/2-34,tag:`plot-${plot.id}-partition`});
  }else if(plot.house === 'modern'){
    parts.push({x:s.x,y:s.y+136,w:176,h:t,tag:`plot-${plot.id}-partition`});
    parts.push({x:s.x+176,y:s.y,w:t,h:88,tag:`plot-${plot.id}-partition`});
  }else if(plot.house === 'bungalow'){
    parts.push({x:s.x+136,y:s.y+118,w:t,h:s.h-118,tag:`plot-${plot.id}-partition`});
    parts.push({x:s.x+136,y:s.y+118,w:s.w-136,h:t,tag:`plot-${plot.id}-partition`});
  }else if(plot.house === 'loft'){
    parts.push({x:s.x+52,y:s.y+54,w:96,h:t,tag:`plot-${plot.id}-partition`});
  }
  return parts;
}
function civicInteriorSolids(location){
  const r=[];
  const x=location.x,y=location.y,w=location.w,h=location.h;
  if(location.id==='bank'){
    r.push({x:x+18,y:y+68,w:w-112,h:24,tag:'bank-counter'});
    r.push({x:x+w-82,y:y+18,w:64,h:94,tag:'bank-vault'});
  }else if(location.id==='police'){
    r.push({x:x+18,y:y+58,w:114,h:24,tag:'police-desk'});
    r.push({x:x+158,y:y+18,w:144,h:84,tag:'police-cells'});
  }else if(location.id==='clinic'){
    r.push({x:x+18,y:y+58,w:94,h:24,tag:'clinic-desk'});
    for(let i=0;i<3;i++)r.push({x:x+138+i*56,y:y+24,w:42,h:67,tag:'clinic-bed'});
  }else if(location.id==='cafe'){
    r.push({x:x+18,y:y+58,w:w-36,h:24,tag:'cafe-counter'});
    for(const tx of [x+58,x+150,x+240])r.push({x:tx-20,y:y+122,w:40,h:40,tag:'cafe-table'});
  }else if(location.id==='market'){
    for(const ax of [x+28,x+128,x+228])r.push({x:ax,y:y+38,w:72,h:124,tag:'market-aisle'});
  }else if(location.id==='depot'){
    r.push({x:x+28,y:y+48,w:w-56,h:34,tag:'depot-belt'});
  }else if(location.id==='garage'){
    r.push({x:x+78,y:y+38,w:144,h:124,tag:'garage-lift'});
  }else if(location.id==='school'){
    r.push({x:x+w/2-42,y:y+33,w:84,h:25,tag:'school-teacher-desk'});
    for(let row=0;row<2;row++)for(let col=0;col<4;col++)r.push({x:x+48+col*125,y:y+88+row*55,w:82,h:28,tag:'school-desk'});
  }else if(location.id==='laundry'){
    for(let i=0;i<4;i++)r.push({x:x+22+i*57,y:y+32,w:48,h:66,tag:'laundry-machine'});r.push({x:x+28,y:y+130,w:w-56,h:28,tag:'laundry-counter'});
  }else if(location.id==='townhall'){
    r.push({x:x+24,y:y+42,w:w-48,h:28,tag:'townhall-dais'});r.push({x:x+w/2-44,y:y+112,w:88,h:42,tag:'townhall-console'});
  }
  return r;
}
function propBox(def,x,y,rot){const rotated=rot===90||rot===270;return{x,y,w:rotated?def.h:def.w,h:rotated?def.w:def.h}}
function markCollidersDirty(){colliderDirty=true}
function rebuildColliders(){
  playerColliders=[];
  vehicleColliders=[];
  structuralRectsByPlot=new Map();
  for(const location of locations){
    const shell={x:location.x,y:location.y,w:location.w,h:location.h};
    addOuterWalls(playerColliders,shell,location.door.x,location.id);
    playerColliders.push(...civicInteriorSolids(location));
    vehicleColliders.push({...shell,tag:`vehicle-${location.id}`});
  }
  for(const plot of plots){
    const structural=[];
    if(plot.house){
      const shell=houseShell(plot);
      addOuterWalls(playerColliders,shell,shell.doorX,`plot-${plot.id}`);
      const partitions=housePartitionRects(plot);
      playerColliders.push(...partitions);
      structural.push(...partitions);
      const doorwayKeepClear={x:shell.doorX-42,y:shell.y+shell.h-60,w:84,h:72,tag:'doorway-clear'};
      structural.push(doorwayKeepClear);
      vehicleColliders.push({x:shell.x,y:shell.y,w:shell.w,h:shell.h,tag:`vehicle-plot-${plot.id}`});
      for(const placed of plot.props){
        const def=PROP[placed.type];
        if(!def||!def.solid)continue;
        const box=propBox(def,placed.x,placed.y,placed.rot);
        playerColliders.push({...box,tag:`prop-${placed.id}`});
      }
    }
    structuralRectsByPlot.set(plot.id,structural);
  }
  playerColliderGrid.clear();vehicleColliderGrid.clear();
  for(const rect of playerColliders)playerColliderGrid.insert(rect,rect);
  for(const rect of vehicleColliders)vehicleColliderGrid.insert(rect,rect);
  colliderDirty=false;
}
function ensureColliders(){if(colliderDirty)rebuildColliders()}
function circleRectPenetration(x,y,r,rect){
  const nearestX=clamp(x,rect.x,rect.x+rect.w);
  const nearestY=clamp(y,rect.y,rect.y+rect.h);
  const dx=x-nearestX;
  const dy=y-nearestY;
  const distanceSq=dx*dx+dy*dy;
  if(distanceSq>0 && distanceSq<r*r){
    const distance=Math.sqrt(distanceSq);
    return{nx:dx/distance,ny:dy/distance,depth:r-distance};
  }
  if(distanceSq===0 && rectContains(rect,x,y)){
    const left=x-rect.x;
    const right=rect.x+rect.w-x;
    const top=y-rect.y;
    const bottom=rect.y+rect.h-y;
    const minimum=Math.min(left,right,top,bottom);
    if(minimum===left)return{nx:-1,ny:0,depth:r+left};
    if(minimum===right)return{nx:1,ny:0,depth:r+right};
    if(minimum===top)return{nx:0,ny:-1,depth:r+top};
    return{nx:0,ny:1,depth:r+bottom};
  }
  return null;
}
function resolveCircleAgainst(entity,radius,colliders,grid=null){
  let hit=null;
  for(let pass=0;pass<3;pass++){
    let changed=false;
    const candidates=grid?grid.queryCircle(entity.x,entity.y,radius+4):colliders;
    spatialFrameCandidates+=candidates.length;
    for(const rect of candidates){
      const penetration=circleRectPenetration(entity.x,entity.y,radius,rect);
      if(!penetration)continue;
      entity.x+=penetration.nx*penetration.depth;
      entity.y+=penetration.ny*penetration.depth;
      changed=true;
      hit={...penetration,rect};
    }
    if(!changed)break;
  }
  return hit;
}
function movePlayer(dx,dy){
  ensureColliders();
  const steps=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))/5));
  const sx=dx/steps,sy=dy/steps;
  for(let i=0;i<steps;i++){
    player.x=clamp(player.x+sx,player.r,WORLD.w-player.r);
    resolveCircleAgainst(player,player.r,playerColliders,playerColliderGrid);
    player.y=clamp(player.y+sy,player.r,WORLD.h-player.r);
    resolveCircleAgainst(player,player.r,playerColliders,playerColliderGrid);
  }
}
function resolveVehicleWorldCollision(preImpactSpeed){
  ensureColliders();
  const forward={x:Math.cos(car.angle),y:Math.sin(car.angle)};
  const probes=[
    {offset:27,r:17},
    {offset:0,r:18},
    {offset:-27,r:17}
  ];
  let strongest=null;
  for(let pass=0;pass<3;pass++){
    let changed=false;
    for(const probe of probes){
      const point={x:car.x+forward.x*probe.offset,y:car.y+forward.y*probe.offset};
      const candidates=vehicleColliderGrid.queryCircle(point.x,point.y,probe.r+6);
      if(roadblock.active&&roadblock.rect&&rectOverlap({x:point.x-probe.r,y:point.y-probe.r,w:probe.r*2,h:probe.r*2},roadblock.rect))candidates.push(roadblock.rect);
      spatialFrameCandidates+=candidates.length;
      for(const rect of candidates){
        const p=circleRectPenetration(point.x,point.y,probe.r,rect);
        if(!p)continue;
        car.x+=p.nx*p.depth;
        car.y+=p.ny*p.depth;
        point.x+=p.nx*p.depth;
        point.y+=p.ny*p.depth;
        const into=car.vx*p.nx+car.vy*p.ny;
        if(into<0 && (!strongest||into<strongest.into))strongest={...p,into};
        changed=true;
      }
    }
    if(!changed)break;
  }
  if(strongest){
    const restitution=.25;
    const impulse=(1+restitution)*strongest.into;
    car.vx=(car.vx-impulse*strongest.nx)*.44;
    car.vy=(car.vy-impulse*strongest.ny)*.44;
    if(car.collisionCooldown<=0 && preImpactSpeed>1.6){
      car.collisionCooldown=18;
      state.stats.collisions=Number(state.stats.collisions||0)+1;
      audio.collision(clamp(preImpactSpeed/7,.5,1.5));
      Camera.addTrauma(clamp(preImpactSpeed*.075,.12,.75));
      if(preImpactSpeed>3.4)addHeat(.18+preImpactSpeed*.025,'reckless collision');
      damageCargoFromImpact(preImpactSpeed);damageVehicleCondition(Math.max(.5,(preImpactSpeed-1.2)*1.6),'world impact');
    }
  }
}
function damageCargoFromImpact(speed){
  if(!state.cargo||!state.cargo.fragile)return;
  const damage=Math.max(2,Math.round((speed-1.2)*7));
  state.cargo.integrity=clamp(Number(state.cargo.integrity||100)-damage,0,100);
  audio.glassRattle();
  notify(`Impact damaged fragile cargo by ${damage}%`,'danger');
  updateCargoHUD();
  saveSoon();
}

function drawAvatarRig(c,avatar,angle,walkCycle,moving,label){
  c.save();
  c.rotate(angle);
  const bob=moving?Math.sin(walkCycle*2)*1.5:0;
  const foot=Math.sin(walkCycle)*4.8;
  const arm=Math.cos(walkCycle)*3.2;

  c.fillStyle='rgba(0,0,0,.28)';
  c.beginPath();c.ellipse(0,6,14,8,0,0,Math.PI*2);c.fill();

  c.fillStyle='#172235';
  c.beginPath();c.ellipse(-7,7+foot,4.2,3.2,0,0,Math.PI*2);c.fill();
  c.beginPath();c.ellipse(7,7-foot,4.2,3.2,0,0,Math.PI*2);c.fill();

  c.save();
  c.translate(0,bob);
  if(avatar.accessory==='backpack'){
    c.fillStyle='#8b5d35';c.fillRect(-10,-15,20,9);
    c.strokeStyle='#5d3c21';c.lineWidth=1.3;c.strokeRect(-10,-15,20,9);
  }

  const top=avatar.topColour||'#64d8d4';
  c.fillStyle=top;
  if(avatar.outfit==='hoodie'){
    c.beginPath();c.roundRect(-15,-8,30,19,7);c.fill();
    c.strokeStyle='rgba(0,0,0,.18)';c.stroke();
  }else if(avatar.outfit==='jacket'){
    c.beginPath();c.moveTo(-15,-7);c.lineTo(15,-7);c.lineTo(13,11);c.lineTo(-13,11);c.closePath();c.fill();
    c.strokeStyle='rgba(0,0,0,.25)';c.beginPath();c.moveTo(0,-7);c.lineTo(0,10);c.stroke();
  }else if(avatar.outfit==='uniform'){
    c.fillRect(-14,-8,28,19);
    c.fillStyle='#fff8ee';c.fillRect(5,-4,5,4);
  }else if(avatar.outfit==='workwear'){
    c.fillRect(-14,-8,28,19);
    c.fillStyle='#172235';c.fillRect(-9,4,18,6);
  }else{
    c.beginPath();c.ellipse(0,1,14,10,0,0,Math.PI*2);c.fill();
  }

  c.fillStyle=top;
  c.beginPath();c.arc(-13,arm*.45,4.6,0,Math.PI*2);c.fill();
  c.beginPath();c.arc(13,-arm*.45,4.6,0,Math.PI*2);c.fill();
  c.fillStyle=avatar.skin||'#f5c6a5';
  c.beginPath();c.arc(-14,3+arm*.45,3.1,0,Math.PI*2);c.fill();
  c.beginPath();c.arc(14,3-arm*.45,3.1,0,Math.PI*2);c.fill();

  c.fillStyle=avatar.skin||'#f5c6a5';
  c.beginPath();c.arc(0,0,10.2,0,Math.PI*2);c.fill();
  c.strokeStyle='rgba(0,0,0,.13)';c.lineWidth=1;c.stroke();

  c.fillStyle='#fff';
  c.beginPath();c.arc(3.3,-2.6,2.8,0,Math.PI*2);c.fill();
  c.beginPath();c.arc(3.3,2.7,2.8,0,Math.PI*2);c.fill();
  c.fillStyle='#0f172a';
  c.beginPath();c.arc(4.4,-2.6,1.3,0,Math.PI*2);c.fill();
  c.beginPath();c.arc(4.4,2.7,1.3,0,Math.PI*2);c.fill();

  if(avatar.accessory==='shades'){
    c.fillStyle='#05070a';c.fillRect(1,-5.2,5.7,4.4);c.fillRect(1,.7,5.7,4.4);
    c.strokeStyle='#58667a';c.beginPath();c.moveTo(3.5,-.7);c.lineTo(3.5,.7);c.stroke();
  }else if(avatar.accessory==='badge'){
    c.fillStyle='#ffc857';c.beginPath();c.arc(8,-6,2.5,0,Math.PI*2);c.fill();
  }else if(avatar.accessory==='stethoscope'){
    c.strokeStyle='#d8edf1';c.lineWidth=1.5;c.beginPath();c.arc(0,4,7,0,Math.PI);c.stroke();
  }
  drawHair(c,avatar);
  c.restore();
  c.restore();

  if(label){
    c.save();c.fillStyle='#fff8ee';c.font='800 11px system-ui';c.textAlign='center';c.fillText(label,0,-25);c.restore();
  }
}
function drawHair(c,avatar){
  const colour=avatar.hairColour||'#2c1b18';
  const style=avatar.hair||'crop';
  if(style==='none')return;
  if(style==='crop'){
    c.fillStyle=colour;c.beginPath();c.arc(-1,0,10.4,Math.PI*.45,Math.PI*1.55);c.fill();
  }else if(style==='ponytail'){
    c.fillStyle=colour;c.beginPath();c.arc(-1,0,10.4,Math.PI*.4,Math.PI*1.6);c.fill();c.beginPath();c.arc(-11,0,5.2,0,Math.PI*2);c.fill();
  }else if(style==='afro'){
    c.fillStyle=colour;for(let a=0;a<Math.PI*2;a+=.72){c.beginPath();c.arc(Math.cos(a)*8-1,Math.sin(a)*8,5.5,0,Math.PI*2);c.fill()}
  }else if(style==='cap'){
    c.fillStyle='#ef6f61';c.beginPath();c.arc(-1,1,10.5,0,Math.PI*2);c.fill();c.fillRect(6,-4,7,8);
  }else if(style==='policeCap'){
    c.fillStyle='#1e3a8a';c.beginPath();c.arc(-1,1,10.8,0,Math.PI*2);c.fill();c.fillStyle='#0f172a';c.fillRect(6,-5,7,10);c.fillStyle='#ffc857';c.fillRect(4,-2,2,4);
  }else if(style==='hardhat'){
    c.fillStyle='#facc15';c.beginPath();c.arc(-1,1,11.2,0,Math.PI*2);c.fill();c.fillStyle='#eab308';c.fillRect(5,-6,5,12);
  }else if(style==='beanie'){
    c.fillStyle='#334155';c.beginPath();c.arc(-2,1,10.6,0,Math.PI*2);c.fill();c.fillStyle='#475569';c.beginPath();c.arc(-9,1,3.7,0,Math.PI*2);c.fill();
  }else if(style==='medicBeanie'){
    c.fillStyle='#059669';c.beginPath();c.arc(-1,1,10.6,0,Math.PI*2);c.fill();c.fillStyle='#fff';c.fillRect(2.5,-1,4,2);c.fillRect(3.5,-2,2,4);
  }
}

const WardrobeStudio={
  canvas:$('mirrorCanvas'),
  ctx:$('mirrorCanvas').getContext('2d'),
  previewAngle:0,
  skinPalette:['#ffd1b3','#f5c6a5','#d19b75','#9a6846','#6a432a','#42271b'],
  hairPalette:['#2c1b18','#e6be8a','#b55239','#8d5b4c','#e2e8f0','#3159a8'],
  topPalette:['#64d8d4','#3b82f6','#ef4444','#10b981','#f59e0b','#8b5cf6','#18181b','#fff8ee'],
  hairStyles:[['none','None'],['crop','Crop'],['ponytail','Tied'],['afro','Afro'],['cap','Cap'],['policeCap','Police cap'],['hardhat','Hardhat'],['beanie','Beanie'],['medicBeanie','Medic cap']],
  outfits:[['casual','Casual'],['hoodie','Hoodie'],['jacket','Jacket'],['uniform','Uniform'],['workwear','Workwear']],
  accessories:[['none','None'],['shades','Shades'],['backpack','Backpack'],['badge','Badge'],['stethoscope','Stethoscope']],
  init(){
    this.populateSwatches('skinSwatches',this.skinPalette,'skin');
    this.populateSwatches('hairColourSwatches',this.hairPalette,'hairColour');
    this.populateSwatches('outfitColourSwatches',this.topPalette,'topColour');
    this.populateButtons('hairSelectGrid',this.hairStyles,'hair');
    this.populateButtons('outfitSelectGrid',this.outfits,'outfit');
    this.populateButtons('accessorySelectGrid',this.accessories,'accessory');
    $('btnTurnLeft').onclick=()=>{this.previewAngle-=Math.PI/4;this.render()};
    $('btnTurnRight').onclick=()=>{this.previewAngle+=Math.PI/4;this.render()};
    $('btnRoleUniformPreset').onclick=()=>this.applyRolePreset();
    $('avatarBtn').onclick=()=>this.open();
  },
  populateSwatches(containerId,palette,property){
    const container=$(containerId);
    for(const colour of palette){
      const button=document.createElement('button');
      button.className='swatch';button.style.background=colour;button.dataset.value=colour;button.setAttribute('aria-label',`${property} ${colour}`);
      button.onclick=()=>{state.avatar[property]=colour;this.refresh();saveSoon()};
      container.appendChild(button);
    }
  },
  populateButtons(containerId,items,property){
    const container=$(containerId);
    for(const [id,label] of items){
      const button=document.createElement('button');
      button.className='btn';button.dataset.value=id;button.textContent=label;
      button.onclick=()=>{state.avatar[property]=id;this.refresh();saveSoon()};
      container.appendChild(button);
    }
  },
  open(){wakeAudio();openModal('avatarModal');this.refresh()},
  refresh(){
    for(const [containerId,property] of [['skinSwatches','skin'],['hairColourSwatches','hairColour'],['outfitColourSwatches','topColour']]){
      document.querySelectorAll(`#${containerId} .swatch`).forEach(button=>button.classList.toggle('active',button.dataset.value===state.avatar[property]));
    }
    for(const [containerId,property] of [['hairSelectGrid','hair'],['outfitSelectGrid','outfit'],['accessorySelectGrid','accessory']]){
      document.querySelectorAll(`#${containerId} button`).forEach(button=>button.classList.toggle('secondary',button.dataset.value===state.avatar[property]));
    }
    this.render();
  },
  applyRolePreset(){
    const role=ROLES[state.role]||ROLES.Resident;
    state.avatar.topColour=role.top;
    state.avatar.hair=role.hair;
    state.avatar.outfit=role.outfit;
    state.avatar.accessory=state.role==='Officer'?'badge':state.role==='Paramedic'?'stethoscope':state.role==='Courier'?'backpack':'none';
    this.refresh();saveSoon();notify(`${state.role} uniform fitted`);
  },
  render(){
    const c=this.ctx;c.clearRect(0,0,190,190);
    c.fillStyle='#172235';c.beginPath();c.arc(95,100,68,0,Math.PI*2);c.fill();
    c.strokeStyle='rgba(100,216,212,.35)';c.lineWidth=2;c.stroke();
    c.save();c.translate(95,98);c.scale(2.55,2.55);drawAvatarRig(c,state.avatar,this.previewAngle,0,false,null);c.restore();
  }
};

const SafeLockpick={
  active:false,
  canvas:$('safeCanvas'),
  ctx:$('safeCanvas').getContext('2d'),
  dialAngle:0,
  gates:[],
  directions:[1,-1,1],
  gateIndex:0,
  dragging:false,
  lastPointerAngle:0,
  lastDirection:0,
  init(){
    this.canvas.addEventListener('pointerdown',event=>{
      this.dragging=true;this.lastPointerAngle=this.pointerAngle(event);this.canvas.setPointerCapture?.(event.pointerId);wakeAudio();
    });
    this.canvas.addEventListener('pointermove',event=>{
      if(!this.dragging)return;
      const next=this.pointerAngle(event);
      let delta=next-this.lastPointerAngle;
      while(delta>Math.PI)delta-=Math.PI*2;
      while(delta<-Math.PI)delta+=Math.PI*2;
      this.rotate(delta*180/Math.PI);
      this.lastPointerAngle=next;
    });
    const stop=()=>{this.dragging=false};
    this.canvas.addEventListener('pointerup',stop);this.canvas.addEventListener('pointercancel',stop);
    $('btnDialCCW').onclick=()=>this.rotate(-6);
    $('btnDialCW').onclick=()=>this.rotate(6);
    $('btnDialSet').onclick=()=>this.confirm();
  },
  pointerAngle(event){
    const rect=this.canvas.getBoundingClientRect();
    return Math.atan2(event.clientY-(rect.top+rect.height/2),event.clientX-(rect.left+rect.width/2));
  },
  open(){
    wakeAudio();
    this.active=true;this.dialAngle=0;this.gateIndex=0;this.lastDirection=0;
    this.gates=Array.from({length:3},()=>Math.floor(Math.random()*55+3)*6%360);if(affinityRank(Number(state.affinity.arthur)||0)>=3)this.gates[0]=Math.floor(Math.random()*15+3)*6;
    openModal('safeModal');this.updateHUD();this.render();
  },
  rotate(delta){
    if(!this.active)return;
    const oldStep=Math.floor(this.dialAngle/6);
    this.lastDirection=Math.sign(delta);
    this.dialAngle=normaliseAngle(this.dialAngle+delta);
    const newStep=Math.floor(this.dialAngle/6);
    const directionCorrect=this.lastDirection===this.directions[this.gateIndex];
    const near=directionCorrect&&angleDistance(this.dialAngle,this.gates[this.gateIndex])<=7;
    if(oldStep!==newStep)audio.dialTick(near);
    this.updateHUD();this.render();
  },
  confirm(){
    if(!this.active)return;
    const directionCorrect=this.lastDirection===this.directions[this.gateIndex];
    const safeTolerance=affinityRank(Number(state.affinity.arthur)||0)>=2?10:8;
    const aligned=angleDistance(this.dialAngle,this.gates[this.gateIndex])<=safeTolerance;
    if(directionCorrect&&aligned){
      this.gateIndex++;audio.gateDrop();
      if(this.gateIndex>=this.gates.length){
        this.active=false;closeModal('safeModal');
        state.bankAlarm=true;audio.setAlarm(true);$('alert').style.display='block';
        state.stats.safeCracks=Number(state.stats.safeCracks||0)+1;const arthurMemory=citizenMemory('arthur');arthurMemory.reportedVaultBreach=Number(arthurMemory.reportedVaultBreach||0)+1;arthurMemory.lastReportDay=state.day;addHeat(3.1,'Civic Bank vault breach');recordTownEvent('bank-robbed',{reportedBy:'arthur'});
        state.mission={type:'mischief',stage:'escape',target:'garage',loot:320};
        notify('Vault released. Escape to the garage before securing the reward.','danger');
        saveSoon();updateUI(true);
      }else{
        this.lastDirection=0;notify(`Gate ${this.gateIndex} set. Reverse direction for the next tumbler.`,'lime');
        this.updateHUD();this.render();
      }
    }else{
      audio.beep(130,.14,.22,'sawtooth');
      notify(directionCorrect?'The gate slipped. Listen for the brighter click.':'Wrong turning direction for this gate.','gold');
    }
  },
  updateHUD(){
    const direction=this.directions[this.gateIndex]??1;
    $('safeDirectionLabel').textContent=direction>0?'Turn clockwise':'Turn anticlockwise';
    $('safeGateLabel').textContent=`Gate ${Math.min(this.gateIndex+1,3)} / 3`;
    $('safeAngleLabel').textContent=`${String(Math.round(this.dialAngle)).padStart(3,'0')}°`;
  },
  render(){
    const c=this.ctx,w=240,h=240;c.clearRect(0,0,w,h);
    c.fillStyle='#1e293b';c.beginPath();c.arc(120,120,106,0,Math.PI*2);c.fill();c.strokeStyle='#475569';c.lineWidth=6;c.stroke();
    c.save();c.translate(120,120);c.rotate(this.dialAngle*Math.PI/180);
    c.fillStyle='#0f172a';c.beginPath();c.arc(0,0,88,0,Math.PI*2);c.fill();
    c.strokeStyle='#94a3b8';c.fillStyle='#cbd5e1';c.font='8px sans-serif';c.textAlign='center';
    for(let angle=0;angle<360;angle+=6){
      c.save();c.rotate(angle*Math.PI/180);c.beginPath();c.moveTo(0,-88);c.lineTo(0,angle%30===0?-73:-81);c.lineWidth=angle%30===0?2:1;c.stroke();if(angle%30===0)c.fillText(String(angle),0,-62);c.restore();
    }
    c.fillStyle='#334155';c.beginPath();c.arc(0,0,36,0,Math.PI*2);c.fill();c.strokeStyle='#64748b';c.lineWidth=3;c.stroke();c.restore();
    c.fillStyle='#ff4d6d';c.beginPath();c.moveTo(120,16);c.lineTo(111,3);c.lineTo(129,3);c.closePath();c.fill();
    const near=this.active&&this.lastDirection===this.directions[this.gateIndex]&&angleDistance(this.dialAngle,this.gates[this.gateIndex])<=8;
    if(near){c.strokeStyle='#b9f27c';c.lineWidth=3;c.beginPath();c.arc(120,120,112,0,Math.PI*2);c.stroke()}
  }
};

const PulseStabiliser={
  active:false,
  canvas:$('medicalCanvas'),
  ctx:$('medicalCanvas').getContext('2d'),
  phase:0,
  speed:.013,
  zone:.67,
  zoneWidth:.13,
  round:0,
  stability:100,
  accuracyTotal:0,
  lastBeatPhase:-1,
  init(){$('btnStabilise').onclick=()=>this.attempt()},
  open(){
    wakeAudio();this.active=true;this.phase=.05;this.speed=.011+Math.random()*.004;this.zone=.58+Math.random()*.24;this.zoneWidth=affinityRank(Number(state.affinity.maya)||0)>=2?.18:.13;if(state.unlocks.medicalResponse)this.zoneWidth=.21;if(businessSynergySnapshot().cafeClinic)this.zoneWidth=Math.max(this.zoneWidth,.23);this.round=0;this.stability=100;this.accuracyTotal=0;this.lastBeatPhase=-1;
    openModal('medicalModal');this.updateHUD();this.render();
  },
  update(){
    if(!this.active)return;
    this.phase=(this.phase+this.speed)%1;
    if(this.phase<this.lastBeatPhase)audio.heartbeat();
    this.lastBeatPhase=this.phase;
  },
  attempt(){
    if(!this.active)return;
    const distance=Math.abs(this.phase-this.zone);
    const wrapped=Math.min(distance,1-distance);
    const accuracy=clamp(1-wrapped/(this.zoneWidth*.75),0,1);
    if(wrapped<=this.zoneWidth/2){
      this.round++;this.accuracyTotal+=accuracy;audio.scanPing(true);notify(`Pulse aligned • ${Math.round(accuracy*100)}% accuracy`,'lime');
      if(this.round>=3){
        const mean=this.accuracyTotal/3;
        const reward=Math.round(105+mean*55);
        this.active=false;closeModal('medicalModal');state.stats.medicalCalls=Number(state.stats.medicalCalls||0)+1;completeJob(reward,'Patient stabilised');return;
      }
      this.zone=.55+Math.random()*.30;this.speed=.011+Math.random()*.005;
    }else{
      this.stability=clamp(this.stability-18,10,100);audio.scanPing(false);notify('Outside the treatment window. Re-centre and try again.','gold');
    }
    this.updateHUD();
  },
  updateHUD(){$('medicalRoundLabel').textContent=`Cycle ${Math.min(this.round+1,3)} / 3`;$('medicalScoreLabel').textContent=`Stability ${Math.round(this.stability)}%`},
  render(){
    const c=this.ctx,w=320,h=150;c.clearRect(0,0,w,h);c.fillStyle='#0b1320';c.fillRect(0,0,w,h);
    c.fillStyle='rgba(185,242,124,.17)';const zx=(this.zone-this.zoneWidth/2)*w;c.fillRect(zx,0,this.zoneWidth*w,h);
    c.strokeStyle='#29445c';c.lineWidth=1;for(let y=25;y<h;y+=25){c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke()}
    c.strokeStyle='#64d8d4';c.lineWidth=3;c.beginPath();
    for(let x=0;x<w;x++){
      const t=x/w;const spike=Math.exp(-Math.pow((((t-this.phase+1)%1)-.5)*18,2));
      const y=h*.58-Math.sin(t*Math.PI*8)*4-spike*58;
      if(x===0)c.moveTo(x,y);else c.lineTo(x,y);
    }
    c.stroke();
    c.strokeStyle='#ffc857';c.lineWidth=3;c.beginPath();c.moveTo(this.phase*w,0);c.lineTo(this.phase*w,h);c.stroke();
  }
};

const SecurityScanner={
  active:false,
  target:0,
  round:0,
  errors:0,
  mode:'patrol',
  labels:['Lobby','Vault','Rear exit'],
  init(){document.querySelectorAll('#scanChoices button').forEach(button=>button.onclick=()=>this.choose(Number(button.dataset.sector)))},
  open(mode='patrol'){
    wakeAudio();this.active=true;this.mode=mode;this.round=0;this.errors=0;this.nextTrace();openModal('scanModal');
    $('scanTitle').textContent=mode==='alarm'?'Bank Security Sweep':'Patrol Evidence Scan';
  },
  nextTrace(){
    this.target=Math.floor(Math.random()*3);
    const clues=this.mode==='alarm'?
      ['Disturbance registered at the public entrance.','Metallic vibration detected beside the secure chamber.','Motion trace registered behind the building.']:
      ['Visitor log signal requires verification.','Equipment store seal requires verification.','Boundary exit sensor requires verification.'];
    $('scanInstruction').textContent=clues[this.target];
    document.querySelectorAll('#scanChoices button').forEach((button,index)=>button.classList.toggle('warn',index===this.target&&state.reducedMotion));
    this.updateHUD();
  },
  choose(index){
    if(!this.active)return;
    if(index===this.target){
      audio.scanPing(true);this.round++;notify('Evidence trace confirmed','lime');
      if(this.round>=3){
        this.active=false;closeModal('scanModal');state.stats.securityScans=Number(state.stats.securityScans||0)+1;
        if(this.mode==='alarm'){state.bankAlarm=false;state.heat=Math.max(0,state.heat-.9);audio.setAlarm(false);$('alert').style.display='none';recordTownEvent('bank-secured');completeJob(Math.max(90,140-this.errors*15),'Bank secured')}
        else completeJob(Math.max(60,85-this.errors*10),'Patrol scan complete');
        return;
      }
      this.nextTrace();
    }else{
      this.errors++;audio.scanPing(false);notify('That sector does not match the trace','gold');this.updateHUD();
    }
  },
  updateHUD(){$('scanRoundLabel').textContent=`Trace ${Math.min(this.round+1,3)} / 3`;$('scanAccuracyLabel').textContent=`Accuracy ${Math.max(0,100-this.errors*20)}%`}
};

function openCargoDepot(){
  const grid=$('cargoGrid');grid.innerHTML='';
  for(const cargo of CARGO_TYPES){
    const card=document.createElement('div');card.className='card';
    card.innerHTML=`<div class="eyebrow" style="color:var(--gold)">${cargo.icon}</div><h3>${cargo.name}</h3><p>${cargo.description}</p><div class="row"><span>Mass</span><strong>+${cargo.mass} kg</strong></div><div class="row"><span>Reward</span><strong style="color:var(--lime)">£${cargo.pay}</strong></div><button class="btn primary" style="width:100%;margin-top:10px">Load manifest</button>`;
    card.querySelector('button').onclick=()=>{assignCargo(cargo);closeModal('cargoModal')};grid.appendChild(card);
  }
  openModal('cargoModal');
}
function assignCargo(cargo){
  const payMultiplier=state.unlocks.highYield?1.15:1;state.cargo={...cargo,pay:Math.round(cargo.pay*payMultiplier),integrity:100};
  const targets=['cafe','market','school','clinic'];
  state.mission={type:'courier',stage:'deliver',target:targets[Math.floor(Math.random()*targets.length)]};
  audio.beep(480,.08,.18);notify(`${cargo.name} loaded. Deliver to ${locationById(state.mission.target).name}.`);updateCargoHUD();saveSoon();updateUI(true);
}
function updateCargoHUD(){
  if(!state.cargo){$('cargoPanel').style.display='none';return}
  $('cargoPanel').style.display='block';$('cargoName').textContent=state.cargo.name;$('cargoMass').textContent=`+${state.cargo.mass} kg`;
  const integrity=clamp(Number(state.cargo.integrity)||0,0,100);$('cargoHealthText').textContent=`${Math.round(integrity)}%`;$('cargoHealthFill').style.width=`${integrity}%`;$('cargoHealthFill').style.background=integrity>60?'var(--lime)':integrity>30?'var(--gold)':'var(--danger)';
}

SafeLockpick.init();
PulseStabiliser.init();
SecurityScanner.init();
WardrobeStudio.init();


class AnchorCitizen{
  constructor(def){this.def=def;this.id=def.id;const slot=scheduleSlotFor(def);this.slotId=slot.id;this.x=slot.x;this.y=slot.y;this.visible=true;this.commuteTimer=0;this.panicTimer=0;this.stumbleTimer=0;this.angle=0;this.walkCycle=Math.random()*10}
  slot(){return scheduleSlotFor(this.def)}
  activity(){return this.slot().activity}
  update(){
    const slot=this.slot();this.walkCycle+=.06;
    if(slot.id!==this.slotId){this.slotId=slot.id;this.visible=false;this.commuteTimer=100}
    if(this.commuteTimer>0){this.commuteTimer--;if(this.commuteTimer===0){this.x=slot.x;this.y=slot.y;this.visible=true}}
    if(this.panicTimer>0){this.panicTimer--;this.angle+=.08}
    if(this.stumbleTimer>0)this.stumbleTimer--;
  }
  bark(){const memory=citizenMemory(this.id),rank=affinityRank(Number(state.affinity[this.id])||0);if(memory.bumped>0)return'Keep that cruiser away from me, mate.';if(latestTownEvent('bank-robbed',30))return this.def.robbedBark;if(state.heat>=3)return'The response level is getting serious.';if(rank>=3)return this.def.highBark;return this.def.baseBark}
  draw(c){if(!this.visible)return;c.save();c.translate(this.x,this.y);if(this.stumbleTimer>0){c.rotate(Math.PI/4);c.scale(1.05,.72)}drawAvatarRig(c,this.def.avatar,this.angle,this.walkCycle,this.panicTimer>0,this.def.name);if(this.panicTimer>0){c.fillStyle='#ff4d6d';c.font='900 14px system-ui';c.textAlign='center';c.fillText('!',0,-22)}const distance=Math.hypot(player.x-this.x,player.y-this.y);if(distance<125&&!car.inCar&&!DialogueManager.active){const bark=this.bark();c.fillStyle='rgba(15,23,42,.93)';c.strokeStyle='#64d8d4';c.lineWidth=1;c.beginPath();c.roundRect(-92,-61,184,25,6);c.fill();c.stroke();c.fillStyle='#fff8ee';c.font='700 9px system-ui';c.textAlign='center';c.fillText(bark.length>42?`${bark.slice(0,39)}…`:bark,0,-44)}c.restore()}
}
const anchorCitizens=Object.fromEntries(Object.values(CITIZEN_DB).map(def=>[def.id,new AnchorCitizen(def)]));
function nearestAnchorCitizen(){let nearest=null;for(const citizen of Object.values(anchorCitizens)){if(!citizen.visible)continue;const distance=Math.hypot(player.x-citizen.x,player.y-citizen.y);if(distance<62&&(!nearest||distance<nearest.distance))nearest={citizen,distance}}return nearest?.citizen||null}
function resolveNamedCitizenContacts(){
  if(!car.inCar||!car.active)return;const speed=Math.hypot(car.vx,car.vy);if(speed<1.8)return;
  for(const citizen of Object.values(anchorCitizens)){if(!citizen.visible)continue;const dx=car.x-citizen.x,dy=car.y-citizen.y,distance=Math.hypot(dx,dy);if(distance>=31||distance<.001)continue;const nx=dx/distance,ny=dy/distance;car.x+=nx*(31-distance);car.y+=ny*(31-distance);car.vx*=.38;car.vy*=.38;citizen.panicTimer=90;citizen.stumbleTimer=55;const memory=citizenMemory(citizen.id);memory.bumped=Number(memory.bumped||0)+1;recordTownEvent('citizen-close-call',{citizen:citizen.id});addHeat(.65,`close call with ${citizen.def.name}`);Camera.addTrauma(.35);audio.collision(.8);break}
}

const ROAD_NODES=[
  {id:0,x:900,y:720,next:[1]},{id:1,x:1400,y:720,next:[2,8]},{id:2,x:1900,y:720,next:[3]},{id:3,x:1900,y:1120,next:[4,10]},{id:4,x:1900,y:1480,next:[5]},{id:5,x:1400,y:1480,next:[6,12]},{id:6,x:900,y:1480,next:[7]},{id:7,x:900,y:1120,next:[0,14]},
  {id:8,x:1400,y:820,next:[9]},{id:9,x:1760,y:1120,next:[10]},{id:10,x:1760,y:1400,next:[11]},{id:11,x:1400,y:1400,next:[12]},{id:12,x:1040,y:1400,next:[13]},{id:13,x:1040,y:1120,next:[14]},{id:14,x:1040,y:820,next:[15]},{id:15,x:1400,y:820,next:[8]}
];
const roadNodeById=id=>ROAD_NODES.find(node=>node.id===id);
function forwardObstacleDistance(entity,angle,entities,maxDistance=110,laneWidth=34){
  const fx=Math.cos(angle),fy=Math.sin(angle);let closest=Infinity;
  const nearby=dynamicEntityGrid.queryCircle(entity.x,entity.y,maxDistance+45);
  spatialFrameCandidates+=nearby.length;
  for(const other of nearby){
    if(!other||other===entity||other.active===false)continue;
    if(!['traffic','police','player-car'].includes(other.spatialKind))continue;
    const dx=other.x-entity.x,dy=other.y-entity.y;
    const forward=dx*fx+dy*fy;
    const lateral=Math.abs(-dx*fy+dy*fx);
    if(forward>0&&forward<maxDistance&&lateral<laneWidth)closest=Math.min(closest,forward);
  }
  return closest;
}
const CONTEXT_RAY_OFFSETS=[-1.28,-.88,-.48,-.18,0,.18,.48,.88,1.28,Math.PI];
function pointOnRoad(x,y){return roads.some(road=>rectContains(road,x,y))||rectContains({x:1040,y:960,w:720,h:520},x,y)}
function pointInsideStatic(x,y,r=4,grid=vehicleColliderGrid){const candidates=grid.queryCircle(x,y,r+2);spatialFrameCandidates+=candidates.length;return candidates.some(rect=>rectContains({x:rect.x-r,y:rect.y-r,w:rect.w+r*2,h:rect.h+r*2},x,y))||(roadblock.active&&roadblock.rect&&rectContains({x:roadblock.rect.x-r,y:roadblock.rect.y-r,w:roadblock.rect.w+r*2,h:roadblock.rect.h+r*2},x,y))}
function contextSteerAngle(entity,desiredAngle,kind='vehicle'){
  ContextSteeringStats.evaluations++;const isPed=kind==='pedestrian',probe=isPed?52:105,nearby=dynamicEntityGrid.queryCircle(entity.x,entity.y,probe+52);spatialFrameCandidates+=nearby.length;let best=desiredAngle,bestScore=-Infinity,blockedForward=false;
  for(const offset of CONTEXT_RAY_OFFSETS){ContextSteeringStats.rays++;const angle=desiredAngle+offset,fx=Math.cos(angle),fy=Math.sin(angle);let danger=0;for(const fraction of [.32,.62,1]){const px=entity.x+fx*probe*fraction,py=entity.y+fy*probe*fraction;if(pointInsideStatic(px,py,isPed?7:22,isPed?playerColliderGrid:vehicleColliderGrid))danger+=1.45*fraction;for(const other of nearby){if(!other||other===entity||other.active===false)continue;const allowed=isPed?['pedestrian','citizen','player']:['traffic','police','player-car'];if(!allowed.includes(other.spatialKind))continue;const d=Math.hypot(px-other.x,py-other.y),safe=isPed?26:54;if(d<safe)danger+=(safe-d)/safe*(1.3+fraction)}}const roadPreference=isPed?(pointOnRoad(entity.x+fx*probe,entity.y+fy*probe)?.12:.62):(pointOnRoad(entity.x+fx*probe,entity.y+fy*probe)?1:-1.25),interest=Math.cos(offset)*1.42;const score=interest+roadPreference-danger*1.92;if(Math.abs(offset)<.22&&danger>.75)blockedForward=true;if(score>bestScore){bestScore=score;best=angle}}
  let diff=best-desiredAngle;while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;if(blockedForward||Math.abs(diff)>.24){ContextSteeringStats.avoidances++;ContextSteeringStats.lastFrameAvoidances++;state.stats.trafficAvoidances=Number(state.stats.trafficAvoidances||0)+1}return best;
}

class TrafficCar{
  constructor(index){const starts=[0,2,4,6,8,10,12,14];const start=roadNodeById(starts[index%starts.length]);this.index=index;this.x=start.x+(Math.random()*24-12);this.y=start.y+(Math.random()*24-12);this.targetId=start.next[0];this.angle=0;this.speed=0;this.cruise=2.35+Math.random()*1.35;this.state='CRUISE';this.colour=['#e36f63','#6aa8ff','#72c988','#d8a24b','#9c83d8','#5bb4b0'][index%6];this.stuckTicks=0;this.lastX=this.x;this.lastY=this.y;this.avoidance=0}
  update(){const target=roadNodeById(this.targetId);if(!target)return;const dx=target.x-this.x,dy=target.y-this.y,distance=Math.hypot(dx,dy);let desired=Math.atan2(dy,dx);if(distance<34){const next=target.next;this.targetId=next[Math.floor(Math.random()*next.length)]}const ahead=forwardObstacleDistance(this,this.angle,traffic,120,38),sirenDistance=car.siren&&car.active?Math.hypot(this.x-car.x,this.y-car.y):Infinity;const steered=contextSteerAngle(this,desired,'vehicle');let diff=steered-this.angle;while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;this.angle+=diff*.105;this.avoidance=Math.abs(diff);if(sirenDistance<300){this.state='YIELD';this.speed*=.90}else if(ahead<48){this.state='AVOID';this.speed+=(1.25-this.speed)*.11}else if(this.avoidance>.35){this.state='AVOID';this.speed+=(Math.min(this.cruise,2.15)-this.speed)*.08}else{this.state='CRUISE';this.speed+=(this.cruise-this.speed)*.055}this.x=clamp(this.x+Math.cos(this.angle)*this.speed,30,WORLD.w-30);this.y=clamp(this.y+Math.sin(this.angle)*this.speed,30,WORLD.h-30);const hit=resolveCircleAgainst(this,27,vehicleColliders,vehicleColliderGrid);if(hit){this.angle+=hit.nx*.35-hit.ny*.35;this.speed*=.55}const moved=Math.hypot(this.x-this.lastX,this.y-this.lastY);this.stuckTicks=moved<.22?this.stuckTicks+1:Math.max(0,this.stuckTicks-3);this.lastX=this.x;this.lastY=this.y;if(this.stuckTicks>150){const node=roadNodeById(this.targetId)||ROAD_NODES[0];this.angle+=Math.PI*.65;this.x=clamp(this.x+Math.cos(this.angle)*42,30,WORLD.w-30);this.y=clamp(this.y+Math.sin(this.angle)*42,30,WORLD.h-30);this.targetId=node.next[(this.index+1)%Math.max(1,node.next.length)]??node.id;this.stuckTicks=0;ContextSteeringStats.deadlocksResolved++;state.stats.deadlocksResolved=Number(state.stats.deadlocksResolved||0)+1}}
  draw(c){c.save();c.translate(this.x,this.y);c.rotate(this.angle);c.fillStyle='rgba(0,0,0,.3)';c.fillRect(-33+3,-16+3,66,32);c.fillStyle=this.colour;c.fillRect(-33,-16,66,32);c.fillStyle='#8ad3e8';c.fillRect(-2,-12,20,24);c.fillStyle=this.state==='CRUISE'?'#7d2730':this.state==='AVOID'?'#ffc857':'#ff4d6d';c.fillRect(-33,-12,3,7);c.fillRect(-33,5,3,7);c.restore()}
}
const traffic=Array.from({length:15},(_,index)=>new TrafficCar(index));

const ROAD_ADJ=new Map(ROAD_NODES.map(node=>[node.id,new Set()]));
for(const node of ROAD_NODES)for(const next of node.next){ROAD_ADJ.get(node.id).add(next);ROAD_ADJ.get(next)?.add(node.id)}
function nearestRoadNodeId(x,y){let best=ROAD_NODES[0],distance=Infinity;for(const node of ROAD_NODES){const d=(node.x-x)**2+(node.y-y)**2;if(d<distance){distance=d;best=node}}return best.id}
function nextRoadNodeTowards(currentId,x,y){const options=[...(ROAD_ADJ.get(currentId)||[])];if(!options.length)return currentId;return options.sort((a,b)=>{const na=roadNodeById(a),nb=roadNodeById(b);return((na.x-x)**2+(na.y-y)**2)-((nb.x-x)**2+(nb.y-y)**2)})[0]}
function rayRectDistance(origin,angle,rect,maxDistance){
  const dx=Math.cos(angle),dy=Math.sin(angle);let tMin=0,tMax=maxDistance;
  for(const [o,d,min,max] of [[origin.x,dx,rect.x,rect.x+rect.w],[origin.y,dy,rect.y,rect.y+rect.h]]){
    if(Math.abs(d)<1e-8){if(o<min||o>max)return Infinity;continue}
    let t1=(min-o)/d,t2=(max-o)/d;if(t1>t2)[t1,t2]=[t2,t1];tMin=Math.max(tMin,t1);tMax=Math.min(tMax,t2);if(tMin>tMax)return Infinity;
  }
  return tMin>=0?tMin:Infinity;
}
function policeRayDistance(origin,angle,maxDistance){
  const end={x:origin.x+Math.cos(angle)*maxDistance,y:origin.y+Math.sin(angle)*maxDistance};const minX=Math.min(origin.x,end.x),minY=Math.min(origin.y,end.y),w=Math.abs(end.x-origin.x),h=Math.abs(end.y-origin.y);let closest=maxDistance;
  const candidates=vehicleColliderGrid.queryAABB(minX-2,minY-2,w+4,h+4);spatialFrameCandidates+=candidates.length;
  for(const rect of candidates){const d=rayRectDistance(origin,angle,rect,maxDistance);if(d<closest)closest=d}
  if(roadblock.active&&roadblock.rect){const d=rayRectDistance(origin,angle,roadblock.rect,maxDistance);if(d<closest)closest=d}
  return closest;
}
function policeHasLineOfSight(unit,target,distance){return policeRayDistance(unit,Math.atan2(target.y-unit.y,target.x-unit.x),distance+2)>=distance-9}
function nightTime(){return state.time>=19.5||state.time<6.5}
function ownedShelterState(){
  const home=ownedPlot();if(home&&home.house&&rectContains(houseShell(home),player.x,player.y))return'home';const garage=locationById('garage');if(state.businesses.garage.owned&&garage&&rectContains(garage,player.x,player.y))return'garage';return null;
}
function policeVisibilityRange(target){
  let range=360+state.heat*18;const bank=locationById('bank');if(latestTownEvent('bank-robbed',24)&&bank&&Math.hypot(target.x-(bank.x+bank.w/2),target.y-(bank.y+bank.h/2))<520)range+=55;if(!car.inCar)range*=.72;if(nightTime()&&car.inCar&&!car.lights)range*=.43;if(WeatherSystem.type()==='fog')range*=.62;else if(WeatherSystem.type()==='rain')range*=.84;const speed=car.inCar?Math.hypot(car.vx,car.vy):player.moving?2:0;range+=speed*7;if(ownedShelterState())range*=.12;return clamp(range,75,480);
}
class PoliceInterceptor{
  constructor(index){
    this.index=index;const target=car.active?car:player,candidates=ROAD_NODES.slice().sort((a,b)=>Math.hypot(b.x-target.x,b.y-target.y)-Math.hypot(a.x-target.x,a.y-target.y)),start=candidates[index%candidates.length];this.x=start.x;this.y=start.y;this.currentId=start.id;this.targetId=nextRoadNodeTowards(start.id,target.x,target.y);this.angle=0;this.speed=0;this.active=true;this.flash=index%2;this.state='PATROL';this.detection=0;this.searchTicks=0;this.lostTicks=0;this.lastKnown={x:target.x,y:target.y};this.fov=Math.PI/2;this.visibleContact=false;this.justSpotted=false;
  }
  assess(target){
    const dx=target.x-this.x,dy=target.y-this.y,distance=Math.hypot(dx,dy),angleTo=Math.atan2(dy,dx);let diff=angleTo-this.angle;while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;const range=policeVisibilityRange(target),inCone=Math.abs(diff)<this.fov/2,los=inCone&&distance<range&&policeHasLineOfSight(this,target,distance);return{distance,angleTo,range,inCone,los};
  }
  update(){
    if(!this.active)return;const target=car.inCar&&car.active?car:player,previous=this.state,vision=this.assess(target);this.visibleContact=vision.los;
    if(vision.los){
      const gain=vision.distance<120?.075:vision.distance<240?.045:.028;this.detection=clamp(this.detection+gain,0,1);this.lastKnown={x:target.x,y:target.y};this.searchTicks=360;this.lostTicks=0;this.state=this.detection>=.48?'PURSUIT':'INVESTIGATING';
      if(this.state==='PURSUIT'&&previous!=='PURSUIT'){this.justSpotted=true;state.stats.policeSightings=Number(state.stats.policeSightings||0)+1;recordTownEvent('police-contact',{unit:this.index});notify('Police visual contact established','danger')}
    }else{
      this.justSpotted=false;this.detection=Math.max(0,this.detection-.018);
      if(['PURSUIT','INVESTIGATING'].includes(previous))this.searchTicks=Math.max(this.searchTicks,360);
      if(this.searchTicks>0){this.searchTicks--;this.state='SEARCHING'}
      else if(previous==='SEARCHING'||this.lostTicks>0){this.lostTicks=Math.max(0,(this.lostTicks||120)-1);this.state='LOST'}
      else this.state='PATROL';
    }
    let targetX,targetY,targetSpeed;
    if(this.state==='PURSUIT'){targetX=target.x;targetY=target.y;targetSpeed=3.4+state.heat*.48}
    else if(this.state==='INVESTIGATING'){targetX=target.x;targetY=target.y;targetSpeed=2.9+state.heat*.32}
    else if(this.state==='SEARCHING'){targetX=this.lastKnown.x;targetY=this.lastKnown.y;targetSpeed=2.7+state.heat*.22}
    else if(this.state==='LOST'){const precinct=locationById('police');targetX=precinct.door.x;targetY=precinct.door.y;targetSpeed=2.3}
    else{const patrol=roadNodeById(this.targetId)||ROAD_NODES[(this.index*3)%ROAD_NODES.length];targetX=patrol.x;targetY=patrol.y;targetSpeed=2.15}
    const direct=this.state==='PURSUIT'&&this.visibleContact&&vision.distance<190;let desired;
    if(direct)desired=Math.atan2(targetY-this.y,targetX-this.x);
    else{
      const node=roadNodeById(this.targetId)||roadNodeById(this.currentId);const distanceToNode=node?Math.hypot(node.x-this.x,node.y-this.y):0;if(!node||distanceToNode<30){this.currentId=node?.id??nearestRoadNodeId(this.x,this.y);if(this.state==='PATROL'){const current=roadNodeById(this.currentId),next=current?.next||[];this.targetId=next[(this.index+Math.floor(performance.now()/1800))%Math.max(1,next.length)]??this.currentId}else this.targetId=nextRoadNodeTowards(this.currentId,targetX,targetY)}const route=roadNodeById(this.targetId)||{x:targetX,y:targetY};desired=Math.atan2(route.y-this.y,route.x-this.x);
    }
    desired=contextSteerAngle(this,desired,'vehicle');let diff=desired-this.angle;while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;this.angle+=diff*(this.state==='PURSUIT'?.13:.095);this.speed+=(targetSpeed-this.speed)*.07;this.x=clamp(this.x+Math.cos(this.angle)*this.speed,25,WORLD.w-25);this.y=clamp(this.y+Math.sin(this.angle)*this.speed,25,WORLD.h-25);const hit=resolveCircleAgainst(this,28,vehicleColliders,vehicleColliderGrid);if(hit){this.angle+=hit.nx*.28-hit.ny*.28;this.speed*=.62}
  }
  drawVision(c){
    if(state.policeCones===false)return;const baseRange=policeVisibilityRange(car.inCar?car:player),rays=RenderBudget.profile().policeRays;c.save();c.translate(this.x,this.y);const colour=this.state==='PURSUIT'?'255,77,109':this.state==='INVESTIGATING'||this.state==='SEARCHING'?'255,200,87':'106,168,255';c.fillStyle=`rgba(${colour},${this.state==='PURSUIT'?.20:.11})`;c.beginPath();c.moveTo(0,0);for(let i=0;i<=rays;i++){const local=-this.fov/2+this.fov*i/rays,world=this.angle+local,d=policeRayDistance(this,world,baseRange);c.lineTo(Math.cos(local)*d,Math.sin(local)*d)}c.closePath();c.fill();c.restore();
  }
  draw(c){
    this.drawVision(c);c.save();c.translate(this.x,this.y);c.rotate(this.angle);c.fillStyle='rgba(0,0,0,.36)';c.fillRect(-34+4,-17+4,68,34);c.fillStyle='#1e3a8a';c.fillRect(-34,-17,68,34);c.fillStyle='#9fd6ec';c.fillRect(-2,-13,20,26);const flash=(Math.floor(performance.now()/130)+this.flash)%2;c.fillStyle=flash?'#ff4d6d':'#6aa8ff';c.fillRect(-6,-16,12,32);c.fillStyle='#fff3a6';c.fillRect(31,-11,3,7);c.fillRect(31,4,3,7);c.restore();
    if(this.state==='SEARCHING'){c.save();c.strokeStyle='rgba(255,200,87,.75)';c.lineWidth=2;c.setLineDash([7,6]);c.beginPath();c.arc(this.lastKnown.x,this.lastKnown.y,24,0,Math.PI*2);c.stroke();c.setLineDash([]);c.fillStyle='#ffc857';c.font='800 9px system-ui';c.textAlign='center';c.fillText('LAST KNOWN',this.lastKnown.x,this.lastKnown.y-30);c.restore()}
  }
}
const interceptors=[];
const ROADBLOCK_SITES=[{id:'north',rect:{x:1360,y:705,w:80,h:30}},{id:'south',rect:{x:1360,y:1460,w:80,h:30}},{id:'west',rect:{x:885,y:1080,w:30,h:80}},{id:'east',rect:{x:1885,y:1080,w:30,h:80}}];
const roadblock={active:false,rect:null,id:null};
let captureTicks=0;
function updateRoadblock(){if(state.heat<4){if(roadblock.active){roadblock.active=false;roadblock.rect=null;markCollidersDirty()}return}if(roadblock.active)return;const target=car.active?car:player;const site=ROADBLOCK_SITES.slice().sort((a,b)=>Math.hypot(a.rect.x-target.x,a.rect.y-target.y)-Math.hypot(b.rect.x-target.x,b.rect.y-target.y))[1]||ROADBLOCK_SITES[0];roadblock.active=true;roadblock.id=site.id;roadblock.rect={...site.rect,tag:'police-roadblock'};recordTownEvent('roadblock',{site:site.id});markCollidersDirty();notify('Police roadblock deployed','danger')}
function issueHeatFine(){const fine=Math.min(state.cash,Math.ceil(state.heat*70));state.cash-=fine;state.heat=0;state.bankAlarm=false;audio.setAlarm(false);$('alert').style.display='none';if(state.mission?.type==='mischief')state.mission=null;if(state.dirtyBonds>0)state.dirtyBonds=Math.floor(state.dirtyBonds*.8);captureTicks=0;interceptors.length=0;roadblock.active=false;roadblock.rect=null;markCollidersDirty();recordTownEvent('heat-fine',{fine});saveSoon();notify(`Town response resolved • £${fine} fine`,'gold');updateUI(true)}
function aggregatePoliceState(){if(interceptors.some(u=>u.state==='PURSUIT'))return'PURSUIT';if(interceptors.some(u=>u.state==='INVESTIGATING'))return'INVESTIGATING';if(interceptors.some(u=>u.state==='SEARCHING'))return'SEARCHING';if(interceptors.some(u=>u.state==='LOST'))return'LOST';return interceptors.length?'PATROL':'QUIET'}
function updateStealthHUD(){
  const badge=$('stealthBadge'),status=aggregatePoliceState(),active=state.heat>.35||state.bankAlarm;if(!active){badge.className='cut';badge.style.display='none';$('policeStateLabel').textContent='Quiet';return}
  const signal=Math.round(Math.max(0,...interceptors.map(u=>u.detection||0))*100);badge.style.display='flex';badge.className='cut '+(status==='PURSUIT'?'pursuit':status==='INVESTIGATING'||status==='SEARCHING'?'investigating':status==='LOST'?'lost':'hidden');
  $('stealthText').textContent=status==='PURSUIT'?'Visual contact • pursuit':status==='INVESTIGATING'?'Suspicion rising':status==='SEARCHING'?'Searching last known position':status==='LOST'?'Contact lost • keep hidden':ownedShelterState()?'Hidden inside owned shelter':nightTime()&&car.inCar&&!car.lights?'Dark running • line of sight broken':'Line of sight broken';$('stealthSignalFill').style.width=`${signal}%`;$('policeStateLabel').textContent=status.charAt(0)+status.slice(1).toLowerCase();
}
function updatePoliceResponse(){
  const baseCount=state.heat>=4.5?3:state.heat>=3?2:state.heat>=1.25?1:0;const targetCount=clamp(baseCount+CivicManager.effect().nightPatrolBonus,0,4);
  while(interceptors.length<targetCount)interceptors.push(new PoliceInterceptor(interceptors.length));
  while(interceptors.length>targetCount)interceptors.pop();
  interceptors.forEach(unit=>unit.update());
  updateRoadblock();

  const focus=car.inCar?car:player;
  const speed=car.inCar?Math.hypot(car.vx,car.vy):0;
  const pursuitUnits=interceptors.filter(unit=>unit.state==='PURSUIT');
  const close=pursuitUnits.some(unit=>Math.hypot(unit.x-focus.x,unit.y-focus.y)<52);
  if(state.heat>.2&&close&&speed<.65)captureTicks++;else captureTicks=Math.max(0,captureTicks-2);
  if(captureTicks>150)issueHeatFine();

  if(state.mission?.type==='covert-courier'){
    const mission=state.mission;
    const contactCount=pursuitUnits.length;
    if(contactCount>0){
      mission.exposure=Number(mission.exposure||0)+contactCount*FIXED_STEP/1000;
      if(!mission.detected){mission.detected=true;recordTownEvent('covert-operation-spotted');notify('Covert manifest identified • break visual contact','danger')}
      if(state.cargo?.fragile){state.cargo.integrity=clamp(Number(state.cargo.integrity||100)-contactCount*.0025,0,100);saveDirty=true}
    }else if(car.inCar&&speed<1.15&&!ownedShelterState()){
      mission.exposure=Number(mission.exposure||0)+.003;
    }
  }
  updateStealthHUD();
}
function drawPoliceResponse(c){interceptors.forEach(unit=>{if(pointInCamera(unit.x,unit.y,520))unit.draw(c)});if(roadblock.active&&roadblock.rect&&rectInCamera(roadblock.rect,120)){const r=roadblock.rect;c.save();c.fillStyle='#dbeafe';c.fillRect(r.x,r.y,r.w,r.h);c.fillStyle='#ff4d6d';if(r.w>r.h){for(let x=r.x+5;x<r.x+r.w;x+=18)c.fillRect(x,r.y,9,r.h)}else for(let y=r.y+5;y<r.y+r.h;y+=18)c.fillRect(r.x,y,r.w,9);c.strokeStyle='#1e3a8a';c.lineWidth=3;c.strokeRect(r.x,r.y,r.w,r.h);c.restore()}}


const PED_NODES=[
  {id:0,x:750,y:610,next:[1,12]},{id:1,x:1050,y:610,next:[2,8]},{id:2,x:1400,y:610,next:[3,9]},{id:3,x:1750,y:610,next:[4,10]},{id:4,x:2050,y:610,next:[5,13]},
  {id:5,x:2050,y:980,next:[6]},{id:6,x:2050,y:1320,next:[7,14]},{id:7,x:1750,y:1320,next:[8,15]},{id:8,x:1400,y:1320,next:[9,16]},{id:9,x:1050,y:1320,next:[10,17]},{id:10,x:750,y:1320,next:[11,18]},{id:11,x:750,y:980,next:[0]},
  {id:12,x:750,y:780,next:[13],crossing:true},{id:13,x:2050,y:780,next:[5],crossing:true},{id:14,x:2050,y:1450,next:[15],crossing:true},{id:15,x:1750,y:1450,next:[16],crossing:true},{id:16,x:1400,y:1450,next:[17],crossing:true},{id:17,x:1050,y:1450,next:[18],crossing:true},{id:18,x:750,y:1450,next:[11],crossing:true}
];
const pedNodeById=id=>PED_NODES.find(node=>node.id===id);
const NPC_SKINS=['#ffd1b3','#f5c6a5','#d19b75','#9a6846','#6a432a','#42271b'];
const NPC_HAIRS=['crop','ponytail','afro','beanie','none','cap'];
const NPC_TOPS=['#ff8fa3','#64d8d4','#ffc857','#b9f27c','#c59bff','#6aa8ff'];
class Pedestrian{
  constructor(index){
    const start=pedNodeById(index%12);this.x=start.x+(Math.random()*12-6);this.y=start.y+(Math.random()*12-6);this.targetId=start.next[0];this.speed=1.05+Math.random()*.45;this.angle=0;this.walkCycle=Math.random()*10;this.state='WALK';this.panicTimer=0;this.tumbleTimer=0;
    this.avatar={skin:NPC_SKINS[index%NPC_SKINS.length],hair:NPC_HAIRS[index%NPC_HAIRS.length],hairColour:['#2c1b18','#e6be8a','#b55239','#8d5b4c','#e2e8f0'][index%5],outfit:['casual','hoodie','jacket'][index%3],topColour:NPC_TOPS[index%NPC_TOPS.length],accessory:index%5===0?'shades':'none'};
  }
  panicFrom(hazard,duration=75){if(this.state==='TUMBLE')return;this.state='PANIC';this.panicTimer=Math.max(this.panicTimer,duration);this.angle=Math.atan2(this.y-hazard.y,this.x-hazard.x)}
  update(){
    this.walkCycle+=this.state==='PANIC'?.22:.12;
    const carSpeed=car.active?Math.hypot(car.vx,car.vy):0;const distanceToCar=car.active?Math.hypot(this.x-car.x,this.y-car.y):Infinity;
    if(this.state==='TUMBLE'){this.tumbleTimer--;if(this.tumbleTimer<=0)this.state='WALK';return}
    if(car.siren&&distanceToCar<190)this.panicFrom(car,85);
    if(car.inCar&&carSpeed>3&&distanceToCar<105)this.panicFrom(car,60);
    if(car.inCar&&carSpeed>2.4&&distanceToCar<25){this.state='TUMBLE';this.tumbleTimer=70;return}
    if(this.state==='PANIC'){
      this.x=clamp(this.x+Math.cos(this.angle)*3.1,25,WORLD.w-25);this.y=clamp(this.y+Math.sin(this.angle)*3.1,25,WORLD.h-25);this.panicTimer--;if(this.panicTimer<=0)this.state='WALK';return;
    }
    const target=pedNodeById(this.targetId);if(!target)return;
    const dx=target.x-this.x,dy=target.y-this.y,distance=Math.hypot(dx,dy);
    if(target.crossing){
      const movingVehicles=dynamicEntityGrid.queryCircle(target.x,target.y,100).filter(vehicle=>['traffic','police','player-car'].includes(vehicle.spatialKind));spatialFrameCandidates+=movingVehicles.length;const unsafe=movingVehicles.some(vehicle=>{const speed=Number.isFinite(vehicle.vx)&&Number.isFinite(vehicle.vy)?Math.hypot(vehicle.vx,vehicle.vy):Number(vehicle.speed)||0;return Math.hypot(vehicle.x-target.x,vehicle.y-target.y)<95&&speed>1.1});
      if(unsafe)return;
    }
    if(distance<12){const next=target.next;this.targetId=next[Math.floor(Math.random()*next.length)]}
    else{const desired=Math.atan2(dy,dx);const steering=contextSteerAngle(this,desired,'pedestrian');let diff=steering-this.angle;while(diff>Math.PI)diff-=Math.PI*2;while(diff<-Math.PI)diff+=Math.PI*2;this.angle+=diff*.20;this.x=clamp(this.x+Math.cos(this.angle)*this.speed,22,WORLD.w-22);this.y=clamp(this.y+Math.sin(this.angle)*this.speed,22,WORLD.h-22);resolveCircleAgainst(this,11,playerColliders,playerColliderGrid)}
  }
  draw(c){
    c.save();c.translate(this.x,this.y);
    if(this.state==='TUMBLE'){c.fillStyle='rgba(0,0,0,.25)';c.beginPath();c.ellipse(0,4,14,6,0,0,Math.PI*2);c.fill();c.save();c.rotate(Math.PI/3);c.scale(1.1,.62);drawAvatarRig(c,this.avatar,0,this.walkCycle,false,null);c.restore();c.fillStyle='#ffc857';c.font='900 12px system-ui';c.textAlign='center';c.fillText('RECOVERING',0,-17)}
    else{drawAvatarRig(c,this.avatar,this.angle,this.walkCycle,true,null);if(this.state==='PANIC'){c.fillStyle='#ff4d6d';c.font='900 14px system-ui';c.textAlign='center';c.fillText('!',0,-20)}}
    c.restore();
  }
}
const pedestrians=Array.from({length:14},(_,index)=>new Pedestrian(index));

function rebuildDynamicEntityGrid(){
  dynamicEntityGrid.clear();
  const add=(entity,kind,radius)=>{if(!entity||entity.active===false)return;entity.spatialKind=kind;dynamicEntityGrid.insert(entity,{x:entity.x-radius,y:entity.y-radius,w:radius*2,h:radius*2})};
  for(const entity of traffic)add(entity,'traffic',40);
  for(const entity of interceptors)add(entity,'police',42);
  for(const entity of pedestrians)add(entity,'pedestrian',20);
  for(const entity of Object.values(anchorCitizens))if(entity.visible)add(entity,'citizen',20);
  if(car.active)add(car,'player-car',46);
  add(player,'player',20);
}

function resolveDynamicVehicleContacts(){
  if(!car.active)return;
  const carSpeed=Math.hypot(car.vx,car.vy);
  const nearby=dynamicEntityGrid.queryCircle(car.x,car.y,62);
  spatialFrameCandidates+=nearby.length;
  for(const npc of nearby){
    if(!npc||npc===car||!['traffic','police'].includes(npc.spatialKind))continue;
    const dx=car.x-npc.x,dy=car.y-npc.y,distance=Math.hypot(dx,dy);
    if(distance>=48||distance<.001)continue;
    const nx=dx/distance,ny=dy/distance,overlap=48-distance;car.x+=nx*overlap*.65;car.y+=ny*overlap*.65;npc.x-=nx*overlap*.35;npc.y-=ny*overlap*.35;
    const dot=car.vx*nx+car.vy*ny;if(dot<0){car.vx-=1.15*dot*nx;car.vy-=1.15*dot*ny;car.vx*=.55;car.vy*=.55}
    if(car.collisionCooldown<=0&&carSpeed>2){car.collisionCooldown=18;audio.collision(clamp(carSpeed/7,.5,1.4));Camera.addTrauma(clamp(carSpeed*.06,.1,.55));if(carSpeed>3.5)addHeat(.14,'traffic collision');damageCargoFromImpact(carSpeed);damageVehicleCondition(carSpeed*.75,'traffic impact')}
  }
}
function activePlot(){return plots.find(plot=>rectContains(plot,player.x,player.y))}
function ownedPlot(){return plots.find(plot=>plot.owner===state.profile)}
function plotSignPoint(plot){return{x:plot.x+plot.w/2,y:plot.y+24}}
function openPlot(plot){
  const grid=$('houseChoices');grid.innerHTML='';$('plotTitle').textContent=`Plot ${plot.id}`;
  $('plotText').textContent=!plot.owner?'This plot is vacant. Choose an original house shell with real walls, doorways and room dividers.':plot.owner===state.profile?`Owned by ${state.profile}. Change the shell or enter build mode to furnish it.`:`Owned by ${plot.owner}.`;
  const houses=[
    ['modern','Modern Courtyard','Open lounge with a private corner suite.'],
    ['cottage','Brick Cottage','Two-room plan with a central doorway.'],
    ['loft','Studio Loft','Open creative space with a compact divider.'],
    ['bungalow','Garden Bungalow','Single-level L-shaped accessible plan.']
  ];
  for(const [id,name,description] of houses){
    const card=document.createElement('div');card.className='card';
    const buttonLabel=plot.owner===state.profile?(plot.house===id?'Current shell':'Use this shell'):'Claim and build';
    card.innerHTML=`<h3>${name}</h3><p>${description}</p><button class="btn ${plot.house===id?'secondary':''}">${buttonLabel}</button>`;
    card.querySelector('button').onclick=()=>claimHouse(plot,id);grid.appendChild(card);
  }
  $('releasePlotBtn').style.display=plot.owner===state.profile?'inline-flex':'none';$('releasePlotBtn').onclick=()=>releasePlot(plot);openModal('plotModal');
}
function claimHouse(plot,type){
  if(plot.owner&&plot.owner!==state.profile)return notify('That plot belongs to another local profile.','gold');
  const current=ownedPlot();
  if(current&&current!==plot){current.owner=null;current.house=null;current.props=[]}
  plot.owner=state.profile;plot.house=type;plot.props=plot.props||[];state.claimedPlot=plot.id;markCollidersDirty();syncPlots();saveSoon();closeModal('plotModal');notify(`Plot ${plot.id} claimed • ${type}`);updateUI(true);
}
function releasePlot(plot){
  plot.owner=null;plot.house=null;plot.props=[];if(state.claimedPlot===plot.id)state.claimedPlot=null;markCollidersDirty();syncPlots();saveSoon();closeModal('plotModal');notify('Plot released');
}
function toggleBuild(force){
  const plot=activePlot();
  if(!plot||plot.owner!==state.profile||!plot.house){if(!buildMode)return notify('Stand inside your own built plot first.','gold')}
  buildMode=force!==undefined?Boolean(force):!buildMode;
  demolishMode=false;wiringMode=false;$('btnDemolish').classList.remove('danger');$('btnDemolish').textContent='Remove Tool';$('btnWire').classList.remove('warn');$('btnWire').textContent='Wire Circuits';$('buildBar').classList.remove('wiring');
  $('buildBar').style.display=buildMode?'flex':'none';notify(buildMode?'Home designer on':'Home designer off');updateUI(true);
}
function snappedBox(){
  const def=PROP[selectedProp];
  const x=Math.round(mouse.x/20)*20;
  const y=Math.round(mouse.y/20)*20;
  return propBox(def,x,y,rotation);
}
function placementValid(plot,box){
  ensureColliders();
  if(!plot||plot.owner!==state.profile||!plot.house)return false;
  const shell=houseShell(plot);const margin=16;
  if(box.x<shell.x+margin||box.y<shell.y+margin||box.x+box.w>shell.x+shell.w-margin||box.y+box.h>shell.y+shell.h-margin)return false;
  const structural=structuralRectsByPlot.get(plot.id)||[];
  if(structural.some(rect=>rectOverlap(box,rect)))return false;
  if(plot.props.some(placed=>{const def=PROP[placed.type];return def&&rectOverlap(box,propBox(def,placed.x,placed.y,placed.rot))}))return false;
  const playerBox={x:player.x-player.r-4,y:player.y-player.r-4,w:(player.r+4)*2,h:(player.r+4)*2};
  return !rectOverlap(box,playerBox);
}
function placeProp(){
  const plot=activePlot();const def=PROP[selectedProp];const box=snappedBox();
  if(!placementValid(plot,box))return notify('That position overlaps a wall, doorway, player or furniture.','gold');
  if(state.cash<def.cost)return notify(`You need £${def.cost} for ${def.name}.`,'gold');
  plot.props.push({id:`p-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,type:selectedProp,x:box.x,y:box.y,rot:rotation,on:Boolean(def.defaultOn),circuit:def.circuit||PROP_CIRCUIT_DEFAULTS[selectedProp]||'appliance',cameraAngle:rotation*Math.PI/180});
  state.cash-=def.cost;markCollidersDirty();UtilityManager.evaluate(plot,0,true);syncPlots();saveSoon();audio.beep(620,.04,.09);notify(`${def.name} placed • £${def.cost}`);updateUI(true);
}
function removeProp(){
  const plot=activePlot();if(!plot||plot.owner!==state.profile)return;
  const index=plot.props.findIndex(placed=>{const def=PROP[placed.type];return def&&rectContains(propBox(def,placed.x,placed.y,placed.rot),mouse.x,mouse.y)});
  if(index<0)return notify('Tap a placed item to remove it.','gold');
  const [removed]=plot.props.splice(index,1);const refund=Math.ceil((PROP[removed.type]?.cost||0)*.5);state.cash+=refund;markCollidersDirty();UtilityManager.evaluate(plot,0,true);syncPlots();saveSoon();audio.beep(310,.05,.11);notify(`${PROP[removed.type]?.name||'Item'} removed • £${refund} refund`);updateUI(true);
}

$('btnDemolish').onclick=event=>{demolishMode=!demolishMode;event.currentTarget.classList.toggle('danger',demolishMode);event.currentTarget.textContent=demolishMode?'Tap item to sell':'Remove Tool';notify(demolishMode?'Remove tool active':'Placement tool active')};
$('btnRotate').onclick=()=>{rotation=(rotation+90)%360;audio.beep(750,.03,.07)};
$('btnWire').onclick=()=>{wiringMode=!wiringMode;demolishMode=false;$('btnDemolish').classList.remove('danger');$('btnDemolish').textContent='Remove Tool';$('btnWire').classList.toggle('warn',wiringMode);$('btnWire').textContent=wiringMode?'Tap device to rewire':'Wire Circuits';$('buildBar').classList.toggle('wiring',wiringMode);notify(wiringMode?'Circuit wiring active: tap a powered device to cycle its branch':'Circuit wiring closed')};
function wirePropAtMouse(){const plot=activePlot();if(!plot||plot.owner!==state.profile)return;const placed=plot.props.find(p=>{const def=PROP[p.type];return def?.watts&&rectContains(propBox(def,p.x,p.y,p.rot),mouse.x,mouse.y)});if(!placed)return notify('Tap a powered device to assign its circuit.','gold');const current=circuitForPlaced(placed),index=POWER_CIRCUITS.indexOf(current);placed.circuit=POWER_CIRCUITS[(index+1)%POWER_CIRCUITS.length];state.stats.circuitRewires=Number(state.stats.circuitRewires||0)+1;UtilityManager.evaluate(plot,0,true);syncPlots();saveSoon();audio.switchClick();notify(`${PROP[placed.type].name} wired to ${CIRCUIT_LABELS[placed.circuit]}`,'lime')};

function roleVehicleColour(){return ROLES[state.role]?.vehicle||'#ff6f61'}
function toggleVehicleSpawn(){
  wakeAudio();if(car.inCar)return notify('Exit the vehicle before returning it.','gold');
  if(car.active){car.active=false;car.siren=false;audio.setSiren(false);notify('Vehicle returned to the garage')}
  else{car.active=true;car.x=player.x+48;car.y=player.y;car.vx=0;car.vy=0;car.angle=0;notify('Role vehicle spawned')}
  updateUI(true);
}
function toggleMount(){
  wakeAudio();if(!car.active)return notify('Spawn a vehicle first.','gold');
  if(car.inCar){
    car.inCar=false;player.x=car.x+Math.cos(car.angle+Math.PI/2)*48;player.y=car.y+Math.sin(car.angle+Math.PI/2)*48;resolveCircleAgainst(player,player.r,playerColliders,playerColliderGrid);audio.beep(280,.05,.08);notify('Exited vehicle');
  }else if(Math.hypot(player.x-car.x,player.y-car.y)<76){car.inCar=true;player.seatedOn=null;audio.beep(520,.05,.09);notify('Entered vehicle')}
  else notify('Move closer to the vehicle.','gold');
  updateUI(true);
}
function toggleSiren(){
  wakeAudio();if(!['Officer','Paramedic'].includes(state.role))return notify('Siren access is limited to emergency roles.','gold');if(!car.active)return notify('Spawn an emergency vehicle first.','gold');car.siren=!car.siren;audio.setSiren(car.siren);notify(car.siren?'Siren on':'Siren off');updateUI(true);
}
function toggleLights(){car.lights=!car.lights;notify(car.lights?'Headlights on':'Headlights off');updateUI(true)}

function abandonOperation(){
  if(!state.mission)return;
  const wasCovert=state.mission.type==='covert-courier';
  const abandoned=state.mission.type;
  state.mission=null;state.cargo=null;updateCargoHUD();
  if(wasCovert)addHeat(.25,'abandoned covert manifest');
  recordTownEvent('operation-abandoned',{operation:abandoned});saveSoon();notify('Operation abandoned','gold');TownLedger.render();updateUI(true);
}

function startRoleJob(){
  wakeAudio();
  if(state.mission)return notify('Finish or reset the current job first.','gold');
  if(state.role==='Courier'){
    state.mission={type:'courier',stage:'pickup',target:'depot'};notify('Courier dispatch: collect a manifest at Parcel Depot.');
  }else if(state.role==='Paramedic'){
    const targets=['cafe','market','school'];state.mission={type:'medic',stage:'respond',target:targets[Math.floor(Math.random()*targets.length)]};notify(`Medical call: respond to ${locationById(state.mission.target).name}.`);
  }else if(state.role==='Officer'){
    if(state.bankAlarm){state.mission={type:'officer',stage:'alarm',target:'bank'};notify('Security response: sweep Civic Bank.','danger')}
    else{state.mission={type:'patrol',stage:'scan',target:'school'};notify('Patrol briefing: scan Northstar Learning Hub.')}
  }else if(state.role==='Builder'){
    const plot=ownedPlot();if(!plot)return notify('Claim a plot before accepting a builder contract.','gold');state.mission={type:'builder',stage:'decorate',target:`plot-${plot.id}`,startCount:plot.props.length};notify('Builder contract: place three new items in your home.');
  }else if(state.role==='Mayor'){state.mission={type:'mayor',stage:'review',target:'townhall'};notify('Mayoral duty: conduct a prosperity review at Town Hall.');
  }else if(state.role==='Mischief'){
    if(state.bankAlarm)return notify('The bank is already under an active security alert.','gold');state.mission={type:'mischief',stage:'reach-bank',target:'bank'};notify('Mischief challenge: reach the Civic Bank vault.');
  }else{
    state.mission={type:'resident',stage:'collect',target:'cafe'};notify('Resident errand: collect a picnic order at Corner Cafe.');
  }
  saveSoon();updateUI(true);
}
function missionText(mission){
  if(!mission)return'Free roam';
  if(mission.type==='courier')return mission.stage==='pickup'?'Collect manifest':'Deliver cargo';
  if(mission.type==='covert-courier')return mission.stage==='deliver'?`Covert delivery • ${Math.round(Number(mission.exposure||0))}s exposed`:'Covert operation';
  if(mission.type==='medic')return'Paramedic response';
  if(mission.type==='officer')return'Bank security sweep';
  if(mission.type==='patrol')return'Patrol evidence scan';
  if(mission.type==='builder')return'Place 3 home items';
  if(mission.type==='mayor')return'Town prosperity review';
  if(mission.type==='mischief')return mission.stage==='escape'?'Escape to garage':'Reach bank vault';
  if(mission.type==='resident')return mission.stage==='collect'?'Collect picnic':'Visit Northstar Park';
  return'Active job';
}
function missionPoint(){
  const mission=state.mission;if(!mission)return null;
  if(String(mission.target).startsWith('plot-')){const plot=plots.find(p=>`plot-${p.id}`===mission.target);return plot?{x:plot.x+plot.w/2,y:plot.y+plot.h/2}:null}
  if(mission.target==='park')return{x:900,y:1835};
  const location=locationById(mission.target);return location?location.door:null;
}
function furnitureInteraction(){
  const plot=activePlot();if(!plot||plot.owner!==state.profile||!plot.house)return null;
  let nearest=null;
  for(const placed of plot.props){
    const def=PROP[placed.type];if(!def?.interaction)continue;
    const box=propBox(def,placed.x,placed.y,placed.rot);const centre={x:box.x+box.w/2,y:box.y+box.h/2};const distance=Math.hypot(player.x-centre.x,player.y-centre.y);
    if(distance<58&&(!nearest||distance<nearest.distance))nearest={placed,def,centre,distance};
  }
  if(!nearest)return null;
  const {placed,def,centre}=nearest;
  if(def.interaction==='sit')return{label:'Sit on sofa',run:()=>{player.seatedOn={plotId:plot.id,propId:placed.id};player.x=centre.x;player.y=centre.y;notify('Seated • press E to stand')}};
  if(def.interaction==='rest')return{label:'Rest until morning',run:()=>{state.time=7;audio.beep(330,.18,.08,'sine');notify('Rested until 07:00');saveSoon()}};
  if(['lamp','tv','fridge','workbench','cctvCam','safe'].includes(def.interaction))return{label:`${placed.on?'Switch off':'Switch on'} ${def.name.toLowerCase()}${placed.on&&!UtilityManager.propPowered(plot,placed)?' • no grid power':''}`,run:()=>UtilityManager.togglePlaced(plot,placed)};
  if(def.interaction==='cctvMonitor')return{label:UtilityManager.propPowered(plot,placed)?'Open CCTV monitor':'CCTV monitor has no power',run:()=>UtilityManager.propPowered(plot,placed)?CCTVManager.open('property'):notify('Restore the security circuit before opening this monitor.','danger')};
  if(def.interaction==='smartSwitch')return{label:utilityFor(plot).circuits.lighting===false?'Enable lighting circuit':'Disable lighting circuit',run:()=>UtilityManager.setCircuit(plot,'lighting',utilityFor(plot).circuits.lighting===false)};
  return null;
}
function specificLocationInteraction(location){
  const mission=state.mission;
  const inside=rectContains(location,player.x,player.y);
  if(location.id==='townhall'&&inside)return{label:state.role==='Mayor'?'Open mayoral decree console':'Open civic governance ledger',run:()=>TownLedger.open('governance')};
  if(location.id==='police'&&inside&&['Officer','Mayor'].includes(state.role))return{label:'Open police CCTV dispatch',run:()=>CCTVManager.open('civic')};
  if(location.id==='bank'&&inside&&state.role==='Mischief'&&CCTVManager.civicPowered('bank')&&Math.hypot(player.x-(location.x+26),player.y-(location.y+28))<68)return{label:'Cut external bank security power',run:()=>{CCTVManager.cutCivicPower('bank',2);addHeat(.45,'security power tampering')}};
  if(location.id==='bank'){
    const vault={x:location.x+location.w-50,y:location.y+65};
    if(inside&&Math.hypot(player.x-vault.x,player.y-vault.y)<76){
      if(state.role==='Mischief'&&!state.bankAlarm&&mission?.type==='mischief')return{label:'Open rotary vault tumbler',run:()=>SafeLockpick.open()};
      if(state.role==='Officer'&&state.bankAlarm)return{label:'Begin bank security sweep',run:()=>{if(!state.mission)state.mission={type:'officer',stage:'alarm',target:'bank'};SecurityScanner.open('alarm')}};
    }
  }
  if(mission&&mission.target===location.id){
    if(mission.type==='courier'&&mission.stage==='pickup'&&location.id==='depot'&&inside)return{label:'Choose courier manifest',run:openCargoDepot};
    if(mission.type==='courier'&&mission.stage==='deliver'&&inside)return{label:'Unload and deliver cargo',run:()=>{
      const integrity=clamp(Number(state.cargo?.integrity)||0,0,100);let payout=Math.round((state.cargo?.pay||90)*(integrity/100)*CivicManager.effect().nightCourierFactor);if(integrity>=95){payout+=25;state.stats.perfectDeliveries=Number(state.stats.perfectDeliveries||0)+1}completeJob(payout,`Delivery ${Math.round(integrity)}% intact`);
    }};
    if(mission.type==='covert-courier'&&mission.stage==='deliver'&&location.id==='laundry'&&inside)return{label:'Transfer covert crate into Washworks',run:()=>{
      const integrity=clamp(Number(state.cargo?.integrity)||0,0,100);
      const exposure=Number(mission.exposure||0);
      const detected=Boolean(mission.detected);
      const exposurePenalty=detected?clamp(.08+exposure*.018,.08,.38):0;
      const stealthBonus=detected?0:70;
      const bonds=Math.max(60,Math.round((state.cargo?.pay||420)*(integrity/100)*(1-exposurePenalty)+stealthBonus));
      state.dirtyBonds+=bonds;state.stats.jobsCompleted=Number(state.stats.jobsCompleted||0)+1;state.stats.smugglingRuns=Number(state.stats.smugglingRuns||0)+1;
      if(!detected&&aggregatePoliceState()!=='PURSUIT')state.stats.stealthEscapes=Number(state.stats.stealthEscapes||0)+1;
      if(detected)addHeat(.28,'covert manifest exposure');
      state.mission=null;state.cargo=null;recordTownEvent('covert-operation-complete',{bonds,integrity,detected,exposure:Number(exposure.toFixed(2))});updateCargoHUD();saveSoon();notify(`${detected?'Exposed':'Ghost'} delivery secured • £${bonds} in fictional bonds`,'gold');updateUI(true)
    }};
    if(mission.type==='medic'&&inside)return{label:'Begin pulse stabilisation',run:()=>PulseStabiliser.open()};
    if(mission.type==='officer'&&inside)return{label:'Begin bank security sweep',run:()=>SecurityScanner.open('alarm')};
    if(mission.type==='patrol'&&inside)return{label:'Begin patrol evidence scan',run:()=>SecurityScanner.open('patrol')};
    if(mission.type==='mayor'&&location.id==='townhall'&&inside)return{label:'Complete town prosperity review',run:()=>{state.governance.civicFund+=90;state.governance.prosperity=clamp(state.governance.prosperity+2,0,100);completeJob(80,'Mayoral review complete')}};
    if(mission.type==='resident'&&mission.stage==='collect'&&location.id==='cafe'&&inside)return{label:'Collect picnic order',run:()=>{mission.stage='park';mission.target='park';audio.beep(610,.06,.08);notify('Picnic collected. Take it to Northstar Park.');saveSoon();updateUI(true)}};
    if(mission.type==='mischief'&&mission.stage==='escape'&&location.id==='garage'&&inside)return{label:'Secure fictional vault bonds',run:()=>{const reward=Number(mission.loot)||320;state.dirtyBonds+=reward;state.stats.jobsCompleted=Number(state.stats.jobsCompleted||0)+1;state.stats.heatEscapes=Number(state.stats.heatEscapes||0)+1;if(aggregatePoliceState()!=='PURSUIT')state.stats.stealthEscapes=Number(state.stats.stealthEscapes||0)+1;state.mission=null;state.bankAlarm=false;audio.setAlarm(false);$('alert').style.display='none';heatHoldTicks=180;recordTownEvent('getaway',{bonds:reward});saveSoon();notify(`Getaway complete • £${reward} in unprocessed vault bonds • evade the remaining heat`,'gold');updateUI(true)}};
  }
  if(location.id==='laundry'&&inside){const bondInteraction=LaunderingManager.interaction();if(bondInteraction)return bondInteraction;return{label:'Open Washworks business ledger',run:()=>TownLedger.open('businesses')}}
  if(location.id==='bank'&&inside&&Object.values(state.businesses).some(b=>b.owned&&b.stored>=1))return{label:'Collect business dividends',run:()=>BusinessManager.collect()};
  if(location.id==='garage'&&inside){if(state.vehicleCondition<99)return{label:`Repair vehicle${state.businesses.garage.owned&&state.businesses.laundry.owned?' • synergy covered':` • £${Math.ceil((100-state.vehicleCondition)*2.4)}`}`,run:repairVehicle};return{label:affinityRank(Number(state.affinity.jax)||0)>=2?'Open garage and tuning ledger':'Use vehicle garage',run:()=>affinityRank(Number(state.affinity.jax)||0)>=2?TownLedger.open('garage'):toggleVehicleSpawn}};
  if(location.id==='cafe'&&inside)return{label:'Buy cafe snack • £8',run:()=>state.cash>=8?addMoney(-8,'Cafe snack'):notify('Not enough cash.','gold')};
  if(location.id==='market'&&inside)return{label:'Buy groceries • £12',run:()=>state.cash>=12?addMoney(-12,'Groceries'):notify('Not enough cash.','gold')};
  return null;
}
function findInteraction(){
  ensureColliders();
  const breaker=UtilityManager.breakerInteraction();if(breaker)return breaker;
  if(player.seatedOn)return{label:'Stand up',run:()=>{player.seatedOn=null;player.y+=42;resolveCircleAgainst(player,player.r,playerColliders,playerColliderGrid);notify('Standing')}};
  if(car.inCar)return{label:'Exit vehicle',run:toggleMount};
  if(car.active&&Math.hypot(player.x-car.x,player.y-car.y)<76)return{label:'Enter vehicle',run:toggleMount};
  const named=nearestAnchorCitizen();if(named)return{label:`Talk to ${named.def.name}`,run:()=>DialogueManager.open(named.id)};
  const furniture=furnitureInteraction();if(furniture)return furniture;
  if(state.mission?.type==='resident'&&state.mission.target==='park'&&Math.hypot(player.x-900,player.y-1835)<100)return{label:'Enjoy picnic at Northstar Park',run:()=>completeJob(55,'Resident errand complete')};
  for(const location of locations){
    const inside=rectContains(location,player.x,player.y);const atDoor=Math.hypot(player.x-location.door.x,player.y-location.door.y)<72;
    if(inside||atDoor){const interaction=specificLocationInteraction(location);if(interaction)return interaction}
  }
  for(const plot of plots){
    const sign=plotSignPoint(plot);if(!plot.owner&&rectContains(plot,player.x,player.y))return{label:`Claim vacant Plot ${plot.id}`,run:()=>openPlot(plot)};
    if(Math.hypot(player.x-sign.x,player.y-sign.y)<90)return{label:plot.owner===state.profile?'Manage your property':'View property',run:()=>openPlot(plot)};
  }
  return null;
}
function interact(){
  wakeAudio();if(buildMode||isAnyModalOpen())return;currentInteraction=findInteraction();if(currentInteraction)currentInteraction.run();
}
function updateMissionProgress(){
  const mission=state.mission;if(!mission)return;
  if(mission.type==='builder'&&mission.stage==='decorate'){
    const plot=ownedPlot();if(plot&&plot.props.length-(Number(mission.startCount)||0)>=3)completeJob(120,'Builder contract complete');
  }
}

function isAnyModalOpen(){return Boolean(DialogueManager.active)||[...document.querySelectorAll('.modalWrap')].some(modal=>modal.style.display==='grid')}
function focusFirstControl(container){const target=container?.querySelector('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])');target?.focus({preventScroll:true})}
function openModal(id){keys=Object.create(null);if(DialogueManager.active)DialogueManager.close();const modal=$(id);previousFocus=document.activeElement;modal.style.display='grid';modal.setAttribute('aria-hidden','false');requestAnimationFrame(()=>focusFirstControl(modal))}
function closeModal(id){
  const modal=$(id);modal.style.display='none';modal.setAttribute('aria-hidden','true');
  if(id==='safeModal')SafeLockpick.active=false;
  if(id==='medicalModal')PulseStabiliser.active=false;
  if(id==='scanModal')SecurityScanner.active=false;
  if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});previousFocus=null;
}
function closeTopModal(){if(DialogueManager.active){DialogueManager.close();return}const open=[...document.querySelectorAll('.modalWrap')].reverse().find(modal=>modal.style.display==='grid');if(open)closeModal(open.id)}
function trapModalFocus(event){if(event.key!=='Tab')return;const open=[...document.querySelectorAll('.modalWrap')].reverse().find(modal=>modal.style.display==='grid');if(!open)return;const controls=[...open.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(element=>element.offsetParent!==null);if(!controls.length)return;const first=controls[0],last=controls[controls.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus()}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus()}}

function updateCutaways(){
  const speed=state.reducedMotion?1:.14;
  for(const location of locations){
    let target=1;
    if(!car.inCar){
      if(rectContains(location,player.x,player.y))target=.02;
      else if(Math.hypot(player.x-location.door.x,player.y-location.door.y)<90)target=.56;
    }
    location.interiorAlpha=state.reducedMotion?target:lerp(location.interiorAlpha,target,speed);
  }
  for(const plot of plots){
    let target=1;
    if(plot.house&&!car.inCar){
      const shell=houseShell(plot);
      if(rectContains(shell,player.x,player.y))target=.02;
      else if(Math.hypot(player.x-shell.doorX,player.y-(shell.y+shell.h))<90)target=.56;
    }
    plot.interiorAlpha=state.reducedMotion?target:lerp(plot.interiorAlpha,target,speed);
  }
}

function vehicleGearThresholds(maxSpeed){return[0,maxSpeed*.29,maxSpeed*.52,maxSpeed*.76,maxSpeed*1.02]}
function damageVehicleCondition(amount,reason='impact'){
  const before=state.vehicleCondition;const synergy=state.businesses?.garage?.owned&&state.businesses?.laundry?.owned?0.55:1;state.vehicleCondition=clamp(before-Math.max(0,amount)*synergy,0,100);
  if(before-state.vehicleCondition>.25){saveDirty=true;if(state.vehicleCondition<35&&before>=35)notify('Vehicle condition critical • visit Northstar Garage','danger');recordTownEvent('vehicle-damage',{amount:before-state.vehicleCondition,reason})}
}
function repairVehicle(){
  const missing=100-state.vehicleCondition;if(missing<.5)return notify('Vehicle condition is already excellent.','lime');const synergy=state.businesses.garage.owned&&state.businesses.laundry.owned;const cost=synergy?0:Math.ceil(missing*2.4);if(state.cash<cost)return notify(`Repairs cost £${cost}.`,'gold');state.cash-=cost;state.vehicleCondition=100;state.stats.repairsPaid=Number(state.stats.repairsPaid||0)+cost;audio.repair();recordTownEvent('vehicle-repair',{cost,synergy});saveSoon();notify(synergy?'Garage + Washworks synergy covered the repair':'Vehicle fully repaired','lime');updateUI(true)
}
function updatePowertrainHUD(speed=0){
  const panel=$('telemetryPanel');
  const visible=state.telemetry!==false&&car.inCar&&car.active&&!isAnyModalOpen();
  panel.style.display=visible?'block':'none';
  if(!visible)return;
  const kmh=Math.round(speed*9.5);
  const rpm=Math.round(850+clamp(car.rpm,0,1.12)*6250);
  const slipDegrees=Math.round(Math.atan(clamp(car.slip,0,2))*180/Math.PI);
  const condition=Math.round(state.vehicleCondition);
  $('speedLabel').textContent=String(kmh);
  $('gearLabel').textContent=Math.abs(speed)<.12?'N':String(car.gear);
  $('rpmLabel').textContent=String(rpm);
  $('rpmFill').style.width=`${clamp(car.rpm/1.05*100,0,100)}%`;
  $('loadLabel').textContent=`${Math.round(car.frontLoad)} / ${Math.round(car.rearLoad)}`;
  $('slipLabel').textContent=`${slipDegrees}°`;
  $('slipFill').style.width=`${clamp(car.slip*115,0,100)}%`;
  $('conditionLabel').textContent=`${condition}%`;
  $('conditionFill').style.width=`${condition}%`;
  $('conditionFill').style.background=condition>60?'var(--lime)':condition>30?'var(--gold)':'var(--danger)';
  $('performanceBadge').textContent=`${spatialFrameCandidates} candidates • ${ContextSteeringStats.lastFrameAvoidances} avoids • ${RenderBudget.label()}`;
}
function updateVehicle(){
  const cargoMass=state.cargo?Number(state.cargo.mass)||0:0,totalMass=car.baseMass+cargoMass,massRatio=car.baseMass/totalMass,tune=VehicleTuning.specs(),nitroActive=car.nitroTimer>0,conditionFactor=.58+.42*(state.vehicleCondition/100);
  const cos=Math.cos(car.angle),sin=Math.sin(car.angle);let forwardVelocity=car.vx*cos+car.vy*sin,lateralVelocity=-car.vx*sin+car.vy*cos;let speed=Math.hypot(car.vx,car.vy);
  const effectiveMax=car.maxSpeed*tune.max*conditionFactor*(nitroActive?1.28:1),thresholds=vehicleGearThresholds(effectiveMax);let requestedGear=1;while(requestedGear<4&&speed>thresholds[requestedGear])requestedGear++;
  if(car.shiftCooldown>0)car.shiftCooldown--;if(requestedGear!==car.gear&&car.shiftCooldown<=0){const previous=car.gear;car.gear=requestedGear;car.shiftTimer=7;car.shiftCooldown=12;car.rpm*=.72}if(car.shiftTimer>0)car.shiftTimer--;
  const torqueCurve=[0,1.28,1.08,.90,.72][car.gear],shiftTorque=car.shiftTimer>0?.32:1;let throttle=false,brakingInput=false,longitudinalForce=0;
  const acceleration=car.baseAccel*(.35+.65*massRatio)*tune.accel*torqueCurve*shiftTorque*conditionFactor*(nitroActive?1.82:1);
  const braking=car.baseBrake*(.45+.55*massRatio)*(state.vehicleCondition<20?.72:1);
  if(keys.w||keys.arrowup){forwardVelocity+=acceleration;longitudinalForce=acceleration;throttle=true}
  if(keys.s||keys.arrowdown){const direction=forwardVelocity>=0?1:-1;forwardVelocity-=direction*Math.min(Math.abs(forwardVelocity)+.03,braking);longitudinalForce=-braking;brakingInput=true}
  const handbrake=keys[' '];if(handbrake&&!car.handbrakeLast&&speed>4)Camera.addTrauma(.16);car.handbrakeLast=handbrake;
  const targetTransfer=clamp(longitudinalForce*88,-25,25);car.weightTransfer=lerp(car.weightTransfer,targetTransfer,.14);car.frontLoad=clamp(50-car.weightTransfer,30,70);car.rearLoad=100-car.frontLoad;
  const baseGrip=handbrake?tune.driftGrip:tune.grip,frontGrip=clamp(baseGrip*(car.frontLoad/50)*(brakingInput?1.04:1),.12,.98),rearGrip=clamp((handbrake?tune.driftGrip:baseGrip)*(car.rearLoad/50)*(brakingInput?.78:1),.06,.98);
  const steerInput=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0),maxSteer=.52*(.72+.28*tune.handling),speedSteer=clamp(1-speed/Math.max(10,effectiveMax)*.42,.55,1);car.steerAngle=lerp(car.steerAngle,steerInput*maxSteer*speedSteer,.22);
  const direction=forwardVelocity>=0?1:-1,desiredYaw=(forwardVelocity/car.wheelbase)*Math.tan(car.steerAngle)*.50*tune.handling;car.yawRate=lerp(car.yawRate,desiredYaw,.26);const rawSlip=Math.abs(lateralVelocity)/(speed+.12),rearBreakaway=clamp(rawSlip-(rearGrip*.42),0,.8);car.yawRate+=Math.sign(lateralVelocity||steerInput||1)*rearBreakaway*.016*direction;car.angle+=car.yawRate;
  const lateralRetention=clamp(1-((frontGrip*.42+rearGrip*.58)),.025,.92);const dampedLateral=lateralVelocity*lateralRetention,dampedForward=forwardVelocity*(WeatherSystem.type()==='rain'?.989:.985);const newCos=Math.cos(car.angle),newSin=Math.sin(car.angle);car.vx=newCos*dampedForward-newSin*dampedLateral;car.vy=newSin*dampedForward+newCos*dampedLateral;
  speed=Math.hypot(car.vx,car.vy);if(speed>effectiveMax){const scale=effectiveMax/speed;car.vx*=scale;car.vy*=scale;speed=effectiveMax}
  const preImpactSpeed=speed,steps=Math.max(1,Math.ceil(speed/4));for(let i=0;i<steps;i++){car.x=clamp(car.x+car.vx/steps,28,WORLD.w-28);car.y=clamp(car.y+car.vy/steps,28,WORLD.h-28);resolveVehicleWorldCollision(preImpactSpeed)}
  resolveDynamicVehicleContacts();resolveNamedCitizenContacts();player.x=car.x;player.y=car.y;
  car.slip=Math.abs(lateralVelocity)/(speed+.12);const gearMin=thresholds[car.gear-1]||0,gearMax=thresholds[car.gear]||effectiveMax,gearProgress=clamp((speed-gearMin)/Math.max(.1,gearMax-gearMin),.08,1);car.rpm=lerp(car.rpm,clamp(.13+gearProgress*.82+(throttle?.11:0)+(nitroActive?.12:0),.1,1.08),.16);audio.updateEngine(car.rpm,true,throttle,car.gear,Math.abs(longitudinalForce)/Math.max(.01,car.baseAccel));audio.updateSkid(car.slip);
  if(car.collisionCooldown>0)car.collisionCooldown--;if(car.nitroTimer>0)car.nitroTimer--;if(car.nitroCooldown>0)car.nitroCooldown--;car.nitroCharge=car.nitroCooldown>0?1-car.nitroCooldown/480:1;
  if(state.cargo?.fragile&&car.slip>.43&&speed>3){const loss=(car.slip-.43)*.05*(speed-2);state.cargo.integrity=clamp(Number(state.cargo.integrity||100)-loss,0,100);saveDirty=true;if(Math.random()<.025)audio.glassRattle();updateCargoHUD()}
  const rearX=car.x-Math.cos(car.angle)*31,rearY=car.y-Math.sin(car.angle)*31,lateral=13,left={x:rearX-Math.sin(car.angle)*lateral,y:rearY+Math.cos(car.angle)*lateral},right={x:rearX+Math.sin(car.angle)*lateral,y:rearY-Math.cos(car.angle)*lateral};
  if(car.slip>.24&&speed>2){skidCtx.strokeStyle=`rgba(5,10,18,${Math.min(.34,.12+car.slip*.24)})`;skidCtx.lineWidth=3;skidCtx.lineCap='round';if(car.lastSkidLeft&&car.lastSkidRight){skidCtx.beginPath();skidCtx.moveTo(car.lastSkidLeft.x,car.lastSkidLeft.y);skidCtx.lineTo(left.x,left.y);skidCtx.moveTo(car.lastSkidRight.x,car.lastSkidRight.y);skidCtx.lineTo(right.x,right.y);skidCtx.stroke()}car.lastSkidLeft=left;car.lastSkidRight=right;if(Math.random()<clamp(car.slip*.34,0,.42))emitTyreSmoke(rearX,rearY,car.slip)}else{car.lastSkidLeft=null;car.lastSkidRight=null}
  car.lastForwardVelocity=forwardVelocity;car.lastThrottle=throttle;updatePowertrainHUD(speed);
}
function updatePlayer(){
  audio.updateEngine(0,false,false,1,0);audio.updateSkid(0);updatePowertrainHUD(0);
  if(player.seatedOn||buildMode){player.moving=false;return}
  let dx=0,dy=0;
  if(keys.w||keys.arrowup)dy--;
  if(keys.s||keys.arrowdown)dy++;
  if(keys.a||keys.arrowleft)dx--;
  if(keys.d||keys.arrowright)dx++;
  if(dx||dy){
    const length=Math.hypot(dx,dy);dx/=length;dy/=length;const movementSpeed=player.speed*(businessSynergySnapshot().cafeClinic?1.18:1);movePlayer(dx*movementSpeed,dy*movementSpeed);player.angle=Math.atan2(dy,dx);player.walkCycle+=.22;player.moving=true;
  }else player.moving=false;
}
function updateWorldStep(){
  updateCutaways();
  if(isAnyModalOpen()){
    PulseStabiliser.update();
    return;
  }
  spatialFrameCandidates=0;ContextSteeringStats.lastFrameAvoidances=0;rebuildDynamicEntityGrid();
  if(!state.freezeTime){const previous=state.time;state.time=(state.time+FIXED_STEP/60000)%24;if(state.time<previous){state.day++;recordTownEvent('new-day',{day:state.day});for(const memory of Object.values(state.citizenMemory))memory.dailyGift=false}}
  if(car.inCar&&car.active)updateVehicle();else updatePlayer();
  traffic.forEach(entity=>entity.update());
  pedestrians.forEach(entity=>entity.update());
  Object.values(anchorCitizens).forEach(entity=>entity.update());
  WeatherSystem.update();updateTyreSmoke();updateGridSparks();updatePoliceResponse();
  const focus=car.inCar?car:player;Camera.update(focus,car.inCar&&car.active,car.inCar?Math.hypot(car.vx,car.vy):0,car.inCar?car.angle:player.angle);
  if(heatHoldTicks>0)heatHoldTicks--;else if(!state.bankAlarm&&state.heat>0){const shelter=ownedShelterState(),policeState=aggregatePoliceState(),darkRunning=nightTime()&&car.inCar&&!car.lights;let multiplier=shelter==='garage'?3:shelter==='home'?2.4:darkRunning?1.65:1;if(policeState==='PURSUIT')multiplier*=.22;else if(policeState==='SEARCHING'||policeState==='INVESTIGATING')multiplier*=.65;else multiplier*=1.28;const decay=(affinityRank(Number(state.affinity.valerie)||0)>=2?.00019:.00013)*multiplier;const beforeHeat=state.heat;state.heat=Math.max(0,state.heat-decay);if(Math.abs(beforeHeat-state.heat)>.00001)saveDirty=true}
  economyTimer++;if(economyTimer>=60){economyTimer=0;UtilityManager.updateAll();BusinessManager.update();CivicManager.update();TownLedger.refresh()}
  updateMissionProgress();
  currentInteraction=findInteraction();
  const prompt=$('interactionPrompt');
  if(currentInteraction&&!buildMode){$('interactionText').textContent=currentInteraction.label;prompt.style.display='flex'}else prompt.style.display='none';
  uiTimer++;
  if(uiTimer>=6){uiTimer=0;updateUI(false)}
}

function updateUI(force=false){
  $('profileLabel').textContent=state.profile;
  $('cashLabel').textContent=`£${Math.round(state.cash)}`;
  $('roleLabel').textContent=state.role;
  $('timeLabel').textContent=fmtTime(state.time);$('dayLabel').textContent=String(state.day);
  $('vehicleLabel').textContent=car.inCar?'Driving':car.active?'Nearby':'On foot';
  $('jobsLabel').textContent=String(Number(state.stats.jobsCompleted||0));$('heatLabel').textContent=`${state.heat.toFixed(1)} / 5`;$('bondsLabel').textContent=`£${Math.floor(state.dirtyBonds)}`;$('prosperityLabel').textContent=`${Math.round(state.governance.prosperity)} / 100`;$('heatBondsLabel').textContent=`£${Math.floor(state.dirtyBonds)}`;$('heatStars').textContent=heatStars();$('heatStars').setAttribute('aria-label',`Heat ${state.heat.toFixed(1)} out of five`);$('weatherLabel').textContent=WeatherSystem.label();
  $('missionLabel').textContent=missionText(state.mission);
  $('roleSelect').value=state.role;
  $('sirenBtn').classList.toggle('active',car.siren);
  $('buildBtn').classList.toggle('active',buildMode);
  $('lightsBtn').classList.toggle('active',car.lights);$('nitroBtn').disabled=!state.vehicleTune.nitrous;$('nitroBtn').classList.toggle('active',car.nitroTimer>0);$('nitroLabel').textContent=!state.vehicleTune.nitrous?'Locked':car.nitroCooldown>0?`${Math.ceil(car.nitroCooldown/60)}s`:'Ready';$('nitroFill').style.width=`${Math.round((car.nitroCharge||0)*100)}%`;updateUnlocks();
  document.body.classList.toggle('high-contrast',state.highContrast);updateUtilityHUD();
  if(force)updateCargoHUD();
}

function updateUtilityHUD(){const panel=$('utilityPanel'),plot=ownedPlot(),inside=plot?.house&&!car.inCar&&rectContains(houseShell(plot),player.x,player.y),visible=state.utilityTelemetry!==false&&inside&&!isAnyModalOpen();panel.style.display=visible?'block':'none';if(!visible){audio.setGridHum(0,false);return}const util=UtilityManager.evaluate(plot,0,true),ratio=clamp(util.loadWatts/Math.max(1,util.availableWatts),0,1);$('utilityStatusLabel').textContent=util.breakerTripped?'TRIPPED':util.powered?'ONLINE':'OFFLINE';$('utilityLed').classList.toggle('tripped',!util.powered);$('utilitySourceLabel').textContent=SOURCE_LABELS[util.source];$('utilityLoadLabel').textContent=`${util.loadWatts} / ${util.availableWatts} W`;$('utilityLoadFill').style.width=`${ratio*100}%`;$('utilityLoadFill').style.background=util.breakerTripped?'var(--danger)':ratio>.82?'var(--gold)':'var(--lime)';$('utilityBatteryLabel').textContent=util.batteryInstalled?`${Math.round(util.batteryCharge)}%`:'Not installed';$('utilityFuelLabel').textContent=util.generatorInstalled?`${Math.round(util.generatorFuel)}%`:'Not installed';UtilityManager.updateHum()}

function skyAlpha(){
  const hour=state.time;
  if(hour>=7&&hour<=18)return 0;
  if(hour>18&&hour<21)return (hour-18)/3*.48;
  if(hour>=21||hour<5)return .56;
  return (7-hour)/2*.56;
}

let asphaltPattern=null;
const asphaltTile=document.createElement('canvas');asphaltTile.width=64;asphaltTile.height=64;const asphaltCtx=asphaltTile.getContext('2d');
const puddles=[{x:1110,y:760,rx:58,ry:13},{x:1670,y:1460,rx:72,ry:15},{x:820,y:1415,rx:52,ry:12},{x:1840,y:810,rx:64,ry:14},{x:1380,y:1040,rx:48,ry:11}];
function hashNoise(x,y,seed=1){let n=(x*374761393+y*668265263+seed*1442695041)>>>0;n=(n^(n>>13))*1274126177>>>0;return((n^(n>>16))>>>0)/4294967295}
function initialiseVisualAssets(){
  asphaltCtx.fillStyle='#273241';asphaltCtx.fillRect(0,0,64,64);
  for(let y=0;y<64;y+=2)for(let x=0;x<64;x+=2){const n=hashNoise(x,y,17);asphaltCtx.fillStyle=n>.72?`rgba(255,255,255,${.015+n*.025})`:`rgba(0,0,0,${.012+(1-n)*.024})`;asphaltCtx.fillRect(x,y,1,1)}
  asphaltCtx.strokeStyle='rgba(255,255,255,.018)';asphaltCtx.lineWidth=1;for(let i=0;i<6;i++){asphaltCtx.beginPath();asphaltCtx.moveTo(0,8+i*11);asphaltCtx.lineTo(64,5+i*11);asphaltCtx.stroke()}
  asphaltPattern=ctx.createPattern(asphaltTile,'repeat');
}
function roofBaseCanvas(cacheKey,rw,rh,paint){
  const key=`${cacheKey}|${rw}x${rh}`;let base=roofBaseCache.get(key);if(base)return base;
  base=document.createElement('canvas');base.width=rw;base.height=rh;const c=base.getContext('2d');paint(c,rw,rh);roofBaseCache.set(key,base);
  if(roofBaseCache.size>40)roofBaseCache.delete(roofBaseCache.keys().next().value);
  return base;
}
function roofDitherMask(rw,rh,alpha,seed,focusX,focusY){
  const step=clamp(Math.round(alpha*20),0,20),qx=Math.round(focusX/24),qy=Math.round(focusY/24);const key=`${rw}x${rh}|${step}|${seed}|${qx}|${qy}`;let mask=roofMaskCache.get(key);if(mask)return mask;
  mask=document.createElement('canvas');mask.width=rw;mask.height=rh;const c=mask.getContext('2d');const reveal=(1-step/20)*Math.max(rw,rh)*1.42;const cell=4;
  for(let gy=0;gy<rh;gy+=cell)for(let gx=0;gx<rw;gx+=cell){
    const threshold=ROOF_THRESHOLD_64[((gy+seed*3)&63)*64+((gx+seed*7)&63)];const distance=Math.hypot(gx-qx*24,gy-qy*24);const edge=reveal+(threshold-.5)*132;
    if(distance<edge){const fade=clamp((edge-distance)/18,.22,1);c.fillStyle=`rgba(0,0,0,${fade})`;c.fillRect(gx,gy,cell,cell)}
  }
  roofMaskCache.set(key,mask);if(roofMaskCache.size>180)roofMaskCache.delete(roofMaskCache.keys().next().value);return mask;
}
function drawRoofBuffer(main,x,y,w,h,alpha,seed,focusX,focusY,paint,cacheKey=`roof-${seed}`){
  const rw=Math.ceil(w),rh=Math.ceil(h),base=roofBaseCanvas(cacheKey,rw,rh,paint);
  if(roofCanvas.width!==rw||roofCanvas.height!==rh){roofCanvas.width=rw;roofCanvas.height=rh}
  roofCtx.setTransform(1,0,0,1,0,0);roofCtx.globalCompositeOperation='source-over';roofCtx.globalAlpha=1;roofCtx.clearRect(0,0,rw,rh);roofCtx.drawImage(base,0,0);
  if(!state.reducedMotion&&alpha<.985){roofCtx.globalCompositeOperation='destination-out';roofCtx.drawImage(roofDitherMask(rw,rh,alpha,seed,focusX,focusY),0,0);roofCtx.globalCompositeOperation='source-over'}
  main.save();main.globalAlpha=state.reducedMotion?alpha:clamp(.30+alpha*.72,.12,1);main.drawImage(roofCanvas,0,0,rw,rh,x,y,rw,rh);main.restore();
}
function drawKerbs(c){c.save();c.strokeStyle='rgba(225,232,238,.20)';c.lineWidth=7;for(const road of roads)c.strokeRect(road.x+3,road.y+3,road.w-6,road.h-6);c.strokeStyle='rgba(7,12,20,.38)';c.lineWidth=2;for(const road of roads)c.strokeRect(road.x+8,road.y+8,road.w-16,road.h-16);c.restore()}
function drawWetRoads(c){if(WeatherSystem.type()!=='rain')return;c.save();for(const p of puddles){const g=c.createRadialGradient(p.x,p.y,2,p.x,p.y,p.rx);g.addColorStop(0,'rgba(105,145,170,.22)');g.addColorStop(1,'rgba(40,62,78,.02)');c.fillStyle=g;c.beginPath();c.ellipse(p.x,p.y,p.rx,p.ry,0,0,Math.PI*2);c.fill();c.strokeStyle='rgba(170,210,225,.14)';c.stroke()}c.restore()}
function drawWetDynamicReflections(c){
  if(WeatherSystem.type()!=='rain')return;c.save();c.globalCompositeOperation='screen';c.globalAlpha=.22;
  const reflectionStride=RenderBudget.profile().reflectionStride;for(let i=0;i<locations.length;i+=reflectionStride){const location=locations[i];if(!rectInCamera(location,120))continue;const colour=location.id==='clinic'?'113,230,162':location.id==='bank'&&state.bankAlarm?'255,77,109':location.id==='cafe'?'255,200,87':'100,216,212';const g=c.createLinearGradient(location.door.x,location.door.y,location.door.x,location.door.y+95);g.addColorStop(0,`rgba(${colour},.36)`);g.addColorStop(1,`rgba(${colour},0)`);c.fillStyle=g;c.beginPath();c.ellipse(location.door.x,location.door.y+42,24,72,0,0,Math.PI*2);c.fill()}
  if(car.active){c.save();c.translate(car.x,car.y+42);c.rotate(car.angle);c.scale(1,-.42);c.fillStyle=roleVehicleColour();c.globalAlpha=.24;c.fillRect(-38,-20,76,40);c.fillStyle=car.lights?'rgba(255,243,166,.58)':'rgba(98,110,126,.18)';c.fillRect(34,-14,8,28);const glowColours={cyan:'100,216,212',coral:'255,111,97',gold:'255,200,87',purple:'197,155,255'};const glow=glowColours[state.vehicleTune.underglow];if(glow){const g=c.createRadialGradient(0,0,4,0,0,72);g.addColorStop(0,`rgba(${glow},.48)`);g.addColorStop(1,`rgba(${glow},0)`);c.fillStyle=g;c.beginPath();c.ellipse(0,0,70,34,0,0,Math.PI*2);c.fill()}c.restore()}
  c.restore();
}

function drawZebra(c,x,y,w,h,horizontal){
  c.fillStyle='rgba(255,255,255,.75)';
  const length=horizontal?w:h;
  for(let i=0;i<length;i+=18){if(horizontal)c.fillRect(x+i,y,9,h);else c.fillRect(x,y+i,w,9)}
}
function drawGround(c){
  c.fillStyle='#132033';c.fillRect(0,0,WORLD.w,WORLD.h);
  c.fillStyle='#183525';c.fillRect(0,0,WORLD.w,640);c.fillRect(0,960,760,360);c.fillRect(2040,960,760,360);c.fillRect(0,1580,WORLD.w,620);
  c.fillStyle=asphaltPattern||'#273241';for(const road of roads)c.fillRect(road.x,road.y,road.w,road.h);drawKerbs(c);drawWetRoads(c);
  c.strokeStyle='rgba(255,200,87,.68)';c.lineWidth=3;c.setLineDash([24,22]);c.beginPath();c.moveTo(0,800);c.lineTo(WORLD.w,800);c.moveTo(0,1450);c.lineTo(WORLD.w,1450);c.moveTo(900,0);c.lineTo(900,WORLD.h);c.moveTo(1900,0);c.lineTo(1900,WORLD.h);c.stroke();c.setLineDash([]);
  drawZebra(c,1360,640,80,160,false);drawZebra(c,1360,1320,80,160,false);drawZebra(c,760,1080,280,80,true);drawZebra(c,1760,1080,280,80,true);
  c.fillStyle='#314055';c.fillRect(1080,980,640,320);c.fillStyle='#223047';c.fillRect(1240,1015,320,250);
  c.fillStyle='rgba(100,216,212,.2)';c.beginPath();c.arc(1400,1140,70,0,Math.PI*2);c.fill();
}
function drawHouseInterior(c,plot){
  const shell=houseShell(plot);
  c.fillStyle='#1c293d';c.fillRect(shell.x,shell.y,shell.w,shell.h);
  c.fillStyle='rgba(255,248,238,.04)';
  for(let x=shell.x;x<shell.x+shell.w;x+=32)c.fillRect(x,shell.y,1,shell.h);
  for(let y=shell.y;y<shell.y+shell.h;y+=32)c.fillRect(shell.x,y,shell.w,1);
  c.strokeStyle='#384d6b';c.lineWidth=4;c.strokeRect(shell.x,shell.y,shell.w,shell.h);
  c.fillStyle='#ff6f61';c.fillRect(shell.doorX-30,shell.y+shell.h-10,60,10);
  c.fillStyle='#384d6b';for(const rect of housePartitionRects(plot))c.fillRect(rect.x,rect.y,rect.w,rect.h);
  const breaker=breakerPosition(plot),util=utilityFor(plot);c.fillStyle=util.breakerTripped?'#ff4d6d':util.powered?'#b9f27c':'#64748b';c.fillRect(breaker.x-10,breaker.y-7,20,14);c.strokeStyle='#fff8ee';c.lineWidth=1.5;c.strokeRect(breaker.x-10,breaker.y-7,20,14);c.fillStyle='rgba(255,248,238,.5)';c.font='800 10px system-ui';c.textAlign='left';c.fillText(`HOME INTERIOR • ${SOURCE_LABELS[util.source].toUpperCase()}`,shell.x+16,shell.y+22);
}
function drawHouseRoof(c,plot){
  if(plot.interiorAlpha<=.01)return;const shell=houseShell(plot);const palette={modern:['#dfe9ea','#64d8d4'],cottage:['#d9c5a7','#9c5b43'],loft:['#b8c0ce','#485971'],bungalow:['#d8dfbb','#6b8458']}[plot.house]||['#dfe9ea','#64d8d4'];
  const focusX=player.x-shell.x,focusY=player.y-shell.y;drawRoofBuffer(c,shell.x,shell.y,shell.w,shell.h,plot.interiorAlpha,plot.id*71,focusX,focusY,(r,w,h)=>{
    r.fillStyle=palette[0];r.fillRect(0,0,w,h);r.fillStyle='rgba(255,255,255,.25)';r.fillRect(0,0,w,4);r.fillStyle='rgba(0,0,0,.32)';r.fillRect(0,h-6,w,6);r.fillStyle=palette[1];r.fillRect(18,18,w-36,44);r.fillStyle='rgba(16,24,39,.20)';r.fillRect(18,82,w-36,h-102);r.strokeStyle='rgba(255,248,238,.22)';r.lineWidth=3;r.strokeRect(1.5,1.5,w-3,h-3);r.fillStyle='#101827';r.font='900 12px system-ui';r.textAlign='center';r.fillText(`${plot.owner||'HOME'} • ${String(plot.house).toUpperCase()}`,w/2,29);
  },`plot-${plot.id}-${plot.house}-${plot.owner||'vacant'}`);const util=utilityFor(plot);if(util.solarInstalled&&plot.interiorAlpha>.35){c.save();c.globalAlpha=plot.interiorAlpha;c.fillStyle='#1e3a5f';for(let i=0;i<3;i++){const px=shell.x+80+i*118,py=shell.y+104;c.fillRect(px,py,92,48);c.strokeStyle='#64d8d4';c.lineWidth=1;c.strokeRect(px,py,92,48);c.beginPath();c.moveTo(px+46,py);c.lineTo(px+46,py+48);c.moveTo(px,py+24);c.lineTo(px+92,py+24);c.stroke()}c.restore()}
}
function drawPlacedProps(c,plot){
  for(const placed of plot.props){
    const def=PROP[placed.type];if(!def)continue;const box=propBox(def,placed.x,placed.y,placed.rot),powered=def.watts?UtilityManager.propPowered(plot,placed):true;
    c.save();c.translate(box.x+box.w/2,box.y+box.h/2);c.rotate(placed.rot*Math.PI/180);
    if(placed.type==='rug'){
      c.fillStyle=def.colour;c.globalAlpha=.72;c.fillRect(-def.w/2,-def.h/2,def.w,def.h);c.globalAlpha=1;c.strokeStyle='rgba(255,255,255,.16)';c.strokeRect(-def.w/2+4,-def.h/2+4,def.w-8,def.h-8);
    }else if(placed.type==='lamp'){
      c.fillStyle='#7a6120';c.beginPath();c.arc(0,0,9,0,Math.PI*2);c.fill();c.fillStyle=powered?'#ffe38b':'#6f6750';c.beginPath();c.arc(0,0,4,0,Math.PI*2);c.fill();
    }else if(placed.type==='tv'){
      c.fillStyle=def.colour;c.fillRect(-def.w/2,-def.h/2,def.w,def.h);c.fillStyle=powered?'#64d8d4':'#080b10';c.fillRect(-def.w/2+5,-def.h/2+3,def.w-10,def.h-6);
    }else if(placed.type==='cctvCam'){CCTVManager.drawCamera(c,plot,placed)
    }else if(placed.type==='cctvMonitor'){CCTVManager.drawMonitor(c,plot,placed,box)
    }else if(placed.type==='fridge'){c.fillStyle=powered?'#dbeafe':'#64748b';c.fillRect(-def.w/2,-def.h/2,def.w,def.h);c.fillStyle='#1e293b';c.fillRect(def.w/2-8,-def.h/2+6,3,18)
    }else if(placed.type==='workbench'){c.fillStyle=powered?'#d97706':'#7c2d12';c.fillRect(-def.w/2,-def.h/2,def.w,def.h);c.fillStyle=powered?'#ffc857':'#475569';c.fillRect(-def.w/2+8,-4,def.w-16,8)
    }else if(placed.type==='safe'){c.fillStyle=powered?'#64748b':'#334155';c.fillRect(-def.w/2,-def.h/2,def.w,def.h);c.strokeStyle=powered?'#b9f27c':'#ffc857';c.strokeRect(-def.w/2+5,-def.h/2+5,def.w-10,def.h-10);c.beginPath();c.arc(7,0,5,0,Math.PI*2);c.stroke()
    }else if(placed.type==='smartSwitch'){c.fillStyle=powered?'#64d8d4':'#475569';c.fillRect(-8,-8,16,16);c.fillStyle='#101827';c.fillRect(-2,-5,4,10)
    }else if(placed.type==='plant'){
      c.fillStyle='#7a4f2b';c.beginPath();c.arc(0,5,8,0,Math.PI*2);c.fill();c.fillStyle=def.colour;for(let a=0;a<Math.PI*2;a+=Math.PI/3){c.beginPath();c.ellipse(Math.cos(a)*7,Math.sin(a)*7-4,6,3,a,0,Math.PI*2);c.fill()}
    }else{
      c.fillStyle=def.colour;c.fillRect(-def.w/2,-def.h/2,def.w,def.h);c.fillStyle='rgba(255,255,255,.16)';c.fillRect(-def.w/2+4,-def.h/2+4,def.w-8,Math.max(5,def.h*.28));
    }
    c.restore();
  }
}
function drawPlot(c,plot){
  if(plot.house){const shell=houseShell(plot);c.fillStyle='rgba(4,9,18,.48)';c.fillRect(shell.x+11,shell.y+14,shell.w+5,shell.h+6)}
  c.fillStyle=plot.owner===state.profile?'#233a2f':'#1d2d25';c.fillRect(plot.x,plot.y,plot.w,plot.h);
  c.strokeStyle=plot.owner?(plot.owner===state.profile?'#64d8d4':'#8b97aa'):'rgba(255,248,238,.16)';c.lineWidth=3;c.strokeRect(plot.x,plot.y,plot.w,plot.h);
  if(plot.house){drawHouseInterior(c,plot);drawPlacedProps(c,plot);drawHouseRoof(c,plot)}
  else{c.fillStyle='rgba(255,248,238,.58)';c.font='800 14px system-ui';c.textAlign='center';c.fillText(`PLOT ${plot.id} • VACANT`,plot.x+plot.w/2,plot.y+plot.h/2)}
  c.fillStyle='#ffc857';c.fillRect(plot.x+plot.w/2-24,plot.y+10,48,10);
}
function drawCivicInterior(c,location){
  const {x,y,w,h}=location;c.fillStyle='#172233';c.fillRect(x,y,w,h);c.strokeStyle='#2d3e58';c.lineWidth=4;c.strokeRect(x+4,y+4,w-8,h-8);
  c.fillStyle='rgba(255,248,238,.035)';for(let gx=x;gx<x+w;gx+=28)c.fillRect(gx,y,1,h);for(let gy=y;gy<y+h;gy+=28)c.fillRect(x,gy,w,1);
  c.fillStyle='#22344d';
  if(location.id==='bank'){
    c.fillRect(x+18,y+68,w-112,24);c.strokeStyle='#64748b';c.strokeRect(x+w-82,y+18,64,94);c.fillStyle=state.bankAlarm?'#ff4d6d':'#ffc857';c.beginPath();c.arc(x+w-50,y+65,18,0,Math.PI*2);c.fill();c.fillStyle='#101827';c.font='900 9px system-ui';c.textAlign='center';c.fillText(state.bankAlarm?'ALERT':'VAULT',x+w-50,y+68);
  }else if(location.id==='police'){
    c.fillRect(x+18,y+58,114,24);c.strokeStyle='#7f8ea3';c.lineWidth=3;c.strokeRect(x+158,y+18,68,84);c.strokeRect(x+234,y+18,68,84);for(let bx=x+168;bx<x+220;bx+=10){c.beginPath();c.moveTo(bx,y+18);c.lineTo(bx,y+102);c.stroke()}for(let bx=x+244;bx<x+296;bx+=10){c.beginPath();c.moveTo(bx,y+18);c.lineTo(bx,y+102);c.stroke()}
  }else if(location.id==='clinic'){
    c.fillRect(x+18,y+58,94,24);for(let i=0;i<3;i++){const bx=x+138+i*56;c.fillStyle='#0ea5e9';c.fillRect(bx,y+24,42,67);c.fillStyle='#fff';c.fillRect(bx+5,y+28,32,15)}
  }else if(location.id==='cafe'){
    c.fillRect(x+18,y+58,w-36,24);c.fillStyle='#8b5d35';for(const tx of [x+58,x+150,x+240]){c.beginPath();c.arc(tx,y+142,20,0,Math.PI*2);c.fill()}
  }else if(location.id==='market'){
    c.fillStyle='#2f6a3e';for(const ax of [x+28,x+128,x+228])c.fillRect(ax,y+38,72,124);
  }else if(location.id==='depot'){
    c.fillStyle='#475569';c.fillRect(x+28,y+48,w-56,34);c.fillStyle='#d97706';for(let px=x+44;px<x+w-48;px+=44)c.fillRect(px,y+55,22,20);
  }else if(location.id==='garage'){
    c.strokeStyle='#ffc857';c.lineWidth=3;c.strokeRect(x+78,y+38,144,124);c.fillStyle='#64748b';c.fillRect(x+18,y+18,44,16);
  }else if(location.id==='school'){
    c.fillStyle='#475569';c.fillRect(x+w/2-42,y+33,84,25);for(let row=0;row<2;row++)for(let col=0;col<4;col++){c.fillStyle='#8b5d35';c.fillRect(x+48+col*125,y+88+row*55,82,28)}
  }else if(location.id==='laundry'){
    c.fillStyle='#33566a';for(let i=0;i<4;i++){c.fillRect(x+24+i*57,y+34,44,62);c.fillStyle='#9fd6ec';c.beginPath();c.arc(x+46+i*57,y+65,14,0,Math.PI*2);c.fill();c.fillStyle='#33566a'}c.fillStyle='#475569';c.fillRect(x+30,y+132,w-60,24);
  }else if(location.id==='townhall'){
    c.fillStyle='#806b49';c.fillRect(x+24,y+42,w-48,28);c.fillStyle='#334155';c.fillRect(x+w/2-44,y+112,88,42);c.fillStyle='#ffc857';c.font='900 10px system-ui';c.textAlign='center';c.fillText(activeDecree()==='standard'?'CIVIC CHARTER':DECREE_DEFS[activeDecree()].name.toUpperCase(),x+w/2,y+137);
  }
  c.fillStyle='#ff6f61';c.fillRect(location.door.x-30,y+h-11,60,11);
}
function drawCivicRoof(c,location){
  if(location.interiorAlpha<=.01)return;const focusX=player.x-location.x,focusY=player.y-location.y;let seed=0;for(const ch of location.id)seed=seed*31+ch.charCodeAt(0);
  drawRoofBuffer(c,location.x,location.y,location.w,location.h,location.interiorAlpha,seed,focusX,focusY,(r,w,h)=>{
    r.fillStyle=location.colour;r.fillRect(0,0,w,h);r.fillStyle='rgba(255,255,255,.23)';r.fillRect(0,0,w,4);r.fillStyle='rgba(0,0,0,.36)';r.fillRect(0,h-6,w,6);r.strokeStyle='rgba(255,248,238,.23)';r.lineWidth=3;r.strokeRect(1.5,1.5,w-3,h-3);r.fillStyle='#d9eff0';r.fillRect(26,54,w-52,44);r.fillStyle='#101827';for(let wx=38;wx<w-38;wx+=58)r.fillRect(wx,63,34,26);r.fillStyle='#fff8ee';r.font='900 14px system-ui';r.textAlign='center';r.fillText(location.name,w/2,30);
  },`civic-${location.id}`);
}
function drawCivicBuilding(c,location){c.fillStyle='rgba(4,9,18,.52)';c.fillRect(location.x+10,location.y+14,location.w+5,location.h+7);drawCivicInterior(c,location);drawCivicRoof(c,location)}
function drawPark(c){
  c.fillStyle='#214f34';c.fillRect(760,1580,300,380);c.fillStyle='#2e6c43';for(let i=0;i<7;i++){c.beginPath();c.arc(800+(i%3)*92,1630+Math.floor(i/3)*100,24,0,Math.PI*2);c.fill()}
  c.fillStyle='#8b5d35';c.fillRect(835,1805,130,20);const tier=CivicManager.fountainTier();if(tier>0){c.fillStyle='rgba(100,216,212,.22)';c.beginPath();c.arc(910,1740,28+tier*8,0,Math.PI*2);c.fill();c.strokeStyle='#9fd6ec';c.lineWidth=2+tier;c.beginPath();c.arc(910,1740,20+tier*7,0,Math.PI*2);c.stroke();for(let i=0;i<tier*2;i++){const a=i/(tier*2)*Math.PI*2;c.beginPath();c.moveTo(910,1740);c.quadraticCurveTo(910+Math.cos(a)*28,1705-tier*5,910+Math.cos(a)*35,1740+Math.sin(a)*16);c.stroke()}}c.fillStyle='rgba(255,248,238,.7)';c.font='800 14px system-ui';c.textAlign='center';c.fillText(`NORTHSTAR PARK • PROSPERITY ${Math.round(state.governance.prosperity)}`,910,1940);
}
function drawCar(c){
  c.save();c.translate(car.x,car.y);c.rotate(car.angle);
  if(state.vehicleTune.underglow!=='off'){c.fillStyle='rgba(100,216,212,.10)';c.beginPath();c.ellipse(0,0,46,27,0,0,Math.PI*2);c.fill()}
  c.fillStyle='rgba(0,0,0,.35)';c.fillRect(-38+4,-20+4,76,40);c.fillStyle=roleVehicleColour();c.fillRect(-38,-20,76,40);c.fillStyle='#9fd6ec';c.fillRect(-6,-15,25,30);c.fillStyle=car.lights?'#fff3a6':'#626e7e';c.fillRect(34,-14,4,8);c.fillRect(34,6,4,8);
  if(state.cargo){c.fillStyle=state.cargo.fragile?'#d6eef2':'#b45309';c.fillRect(-31,-11,19,22);c.strokeStyle='#ffc857';c.strokeRect(-31,-11,19,22)}
  if(car.siren){const flash=Math.floor(performance.now()/140)%2;c.fillStyle=flash?'#ff4d6d':'#6aa8ff';c.fillRect(-4,-18,8,36)}
  c.restore();
}
function drawPlayer(c){c.save();c.translate(player.x,player.y);drawAvatarRig(c,state.avatar,player.angle,player.walkCycle,player.moving,state.profile);c.restore()}
function drawMarker(c,x,y){
  const pulse=state.reducedMotion?0:(Math.sin(performance.now()/250)+1)*4;c.strokeStyle='#ffc857';c.lineWidth=3;c.beginPath();c.arc(x,y,22+pulse,0,Math.PI*2);c.stroke();c.fillStyle='#ffc857';c.beginPath();c.moveTo(x,y-28);c.lineTo(x-9,y-44);c.lineTo(x+9,y-44);c.closePath();c.fill();
}
function drawNightBase(c,alpha){if(alpha<=0)return;c.fillStyle=`rgba(4,9,18,${alpha})`;c.fillRect(0,0,WORLD.w,WORLD.h)}
function glow(c,x,y,r,colour,alpha=1){const g=c.createRadialGradient(x,y,2,x,y,r);g.addColorStop(0,colour.replace('ALPHA',String(alpha)));g.addColorStop(1,colour.replace('ALPHA','0'));c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill()}
function drawEmissivePass(c,alpha){
  c.save();c.globalCompositeOperation='screen';const strength=clamp(alpha/.56,.18,1);
  const lights=[{x:1080,y:960},{x:1720,y:960},{x:1080,y:1320},{x:1720,y:1320},{x:900,y:650},{x:1900,y:650},{x:900,y:1580},{x:1900,y:1580}];
  for(const light of lights){if(pointInCamera(light.x,light.y,180))glow(c,light.x,light.y,145,`rgba(255,218,126,ALPHA)`,.38*strength)}
  for(const location of locations){if(!rectInCamera(location,140))continue;const colour=location.id==='clinic'?'rgba(113,230,162,ALPHA)':location.id==='cafe'?'rgba(255,200,87,ALPHA)':location.id==='bank'?(state.bankAlarm?'rgba(255,77,109,ALPHA)':'rgba(255,200,87,ALPHA)'):'rgba(100,216,212,ALPHA)';glow(c,location.door.x,location.door.y-10,66,colour,.26*strength);if(location.id==='bank')glow(c,location.x+location.w-50,location.y+65,54,state.bankAlarm?'rgba(255,77,109,ALPHA)':'rgba(255,200,87,ALPHA)',.42*strength)}
  for(const plot of plots){if(!rectInCamera(plot,180))continue;for(const placed of plot.props){if(placed.type!=='lamp'||!UtilityManager.propPowered(plot,placed))continue;const def=PROP.lamp,box=propBox(def,placed.x,placed.y,placed.rot);glow(c,box.x+box.w/2,box.y+box.h/2,def.light,'rgba(255,227,139,ALPHA)',.34*strength)}}
  if(car.active){c.save();c.translate(car.x,car.y);c.rotate(car.angle);if(car.lights){const grad=c.createRadialGradient(28,0,8,245,0,270);grad.addColorStop(0,`rgba(255,241,170,${.48*strength})`);grad.addColorStop(.62,`rgba(255,241,170,${.16*strength})`);grad.addColorStop(1,'rgba(255,241,170,0)');c.fillStyle=grad;c.beginPath();c.moveTo(31,-14);c.lineTo(250,-86);c.lineTo(250,86);c.lineTo(31,14);c.closePath();c.fill()}glow(c,-36,-11,34,'rgba(255,77,109,ALPHA)',.35*strength);glow(c,-36,11,34,'rgba(255,77,109,ALPHA)',.35*strength);const glowColours={cyan:'rgba(100,216,212,ALPHA)',coral:'rgba(255,111,97,ALPHA)',gold:'rgba(255,200,87,ALPHA)',purple:'rgba(197,155,255,ALPHA)'};if(glowColours[state.vehicleTune.underglow]){const g=c.createRadialGradient(0,0,4,0,0,65);g.addColorStop(0,glowColours[state.vehicleTune.underglow].replace('ALPHA','.44'));g.addColorStop(1,glowColours[state.vehicleTune.underglow].replace('ALPHA','0'));c.fillStyle=g;c.beginPath();c.ellipse(0,0,64,34,0,0,Math.PI*2);c.fill()}if(car.siren){const flash=Math.floor(performance.now()/140)%2;glow(c,0,0,92,flash?'rgba(255,77,109,ALPHA)':'rgba(106,168,255,ALPHA)',.40)}if(car.nitroTimer>0){const g=c.createLinearGradient(-38,0,-86,0);g.addColorStop(0,'rgba(100,216,212,.72)');g.addColorStop(1,'rgba(100,216,212,0)');c.fillStyle=g;c.beginPath();c.moveTo(-35,-7);c.lineTo(-82,0);c.lineTo(-35,7);c.closePath();c.fill()}c.restore()}
  if(WeatherSystem.type()==='rain'){const stride=RenderBudget.profile().reflectionStride;for(let i=0;i<puddles.length;i+=stride){const p=puddles[i];if(!pointInCamera(p.x,p.y,p.rx+80))continue;const g=c.createRadialGradient(p.x,p.y,0,p.x,p.y,p.rx);g.addColorStop(0,`rgba(120,190,220,${.16*strength})`);g.addColorStop(1,'rgba(120,190,220,0)');c.fillStyle=g;c.beginPath();c.ellipse(p.x,p.y,p.rx,p.ry,0,0,Math.PI*2);c.fill()}}
  c.restore();
}
function drawDebugColliders(c){
  if(!QA_MODE||!window.MBMTownLifeQA?.showColliders)return;ensureColliders();c.save();c.strokeStyle='rgba(255,77,109,.75)';c.lineWidth=2;for(const rect of playerColliders)c.strokeRect(rect.x,rect.y,rect.w,rect.h);c.strokeStyle='rgba(100,216,212,.6)';for(const rect of vehicleColliders)c.strokeRect(rect.x,rect.y,rect.w,rect.h);if(roadblock.active&&roadblock.rect)c.strokeRect(roadblock.rect.x,roadblock.rect.y,roadblock.rect.w,roadblock.rect.h);c.restore();
}
function drawWorld(c){
  drawGround(c);for(const plot of plots)if(rectInCamera(plot,140))drawPlot(c,plot);for(const location of locations)if(rectInCamera(location,140))drawCivicBuilding(c,location);if(rectInCamera({x:760,y:1580,w:300,h:380},120))drawPark(c);drawWetDynamicReflections(c);c.drawImage(skidCanvas,0,0);drawTyreSmoke(c);
  traffic.forEach(entity=>{if(pointInCamera(entity.x,entity.y,100))entity.draw(c)});pedestrians.forEach(entity=>{if(pointInCamera(entity.x,entity.y,90))entity.draw(c)});Object.values(anchorCitizens).forEach(entity=>{if(pointInCamera(entity.x,entity.y,140))entity.draw(c)});drawPoliceResponse(c);WeatherSystem.drawWorld(c);
  drawGridSparks(c);drawNightBase(c,skyAlpha());
  const marker=missionPoint();if(marker&&pointInCamera(marker.x,marker.y,160))drawMarker(c,marker.x,marker.y);if(car.active&&pointInCamera(car.x,car.y,100))drawCar(c);if(!car.inCar&&pointInCamera(player.x,player.y,100))drawPlayer(c);drawDebugColliders(c);
}
function drawBuildOverlay(c){
  if(!buildMode)return;const plot=activePlot();if(!plot)return;const shell=houseShell(plot);c.strokeStyle='rgba(100,216,212,.28)';c.lineWidth=1;
  for(let x=shell.x;x<=shell.x+shell.w;x+=20){c.beginPath();c.moveTo(x,shell.y);c.lineTo(x,shell.y+shell.h);c.stroke()}
  for(let y=shell.y;y<=shell.y+shell.h;y+=20){c.beginPath();c.moveTo(shell.x,y);c.lineTo(shell.x+shell.w,y);c.stroke()}
  if(wiringMode){const breaker=breakerPosition(plot),colours={lighting:'#ffc857',appliance:'#64d8d4',security:'#c59bff',workshop:'#ff6f61'};c.save();c.lineWidth=2;c.setLineDash([6,5]);for(const placed of plot.props){const def=PROP[placed.type];if(!def?.watts)continue;const pbox=propBox(def,placed.x,placed.y,placed.rot),centre={x:pbox.x+pbox.w/2,y:pbox.y+pbox.h/2};c.strokeStyle=colours[circuitForPlaced(placed)]||'#fff';c.beginPath();c.moveTo(breaker.x,breaker.y);c.lineTo(centre.x,centre.y);c.stroke()}c.setLineDash([]);c.restore()}
  const box=snappedBox();const valid=placementValid(plot,box);c.fillStyle=valid?'rgba(185,242,124,.34)':'rgba(255,77,109,.34)';c.strokeStyle=valid?'#b9f27c':'#ff4d6d';c.lineWidth=2;c.fillRect(box.x,box.y,box.w,box.h);c.strokeRect(box.x,box.y,box.w,box.h);
}
function renderMini(){
  const w=138,h=104;mctx.setTransform(DPR,0,0,DPR,0,0);mctx.clearRect(0,0,w,h);const sx=w/WORLD.w,sy=h/WORLD.h;mctx.fillStyle='#101827';mctx.fillRect(0,0,w,h);mctx.fillStyle='#283647';for(const road of roads)mctx.fillRect(road.x*sx,road.y*sy,road.w*sx,road.h*sy);mctx.fillStyle='#3d6a4e';for(const plot of plots)mctx.fillRect(plot.x*sx,plot.y*sy,plot.w*sx,plot.h*sy);mctx.fillStyle='#728095';for(const location of locations)mctx.fillRect(location.x*sx,location.y*sy,location.w*sx,location.h*sy);const marker=missionPoint();if(marker){mctx.fillStyle='#ffc857';mctx.beginPath();mctx.arc(marker.x*sx,marker.y*sy,4,0,Math.PI*2);mctx.fill()}for(const citizen of Object.values(anchorCitizens)){if(!citizen.visible)continue;mctx.fillStyle='#ffc857';mctx.fillRect(citizen.x*sx-1,citizen.y*sy-1,3,3)}if(state.unlocks.policeScanner||WeatherSystem.type()!=='fog'||aggregatePoliceState()==='PURSUIT')for(const unit of interceptors){mctx.fillStyle=unit.state==='PURSUIT'?'#ff4d6d':'#6aa8ff';mctx.fillRect(unit.x*sx-1.5,unit.y*sy-1.5,3,3)}const focus=car.inCar?car:player;mctx.fillStyle='#ff6f61';mctx.beginPath();mctx.arc(focus.x*sx,focus.y*sy,4.3,0,Math.PI*2);mctx.fill();
}
let lastLightingLevel='';
function renderLighting(){
  const profile=RenderBudget.profile(),desiredWidth=Math.max(1,Math.round(canvas.width*profile.lightScale)),desiredHeight=Math.max(1,Math.round(canvas.height*profile.lightScale));
  const resized=lightCanvas.width!==desiredWidth||lightCanvas.height!==desiredHeight;
  if(resized){lightCanvas.width=desiredWidth;lightCanvas.height=desiredHeight;lastLightingLevel=''}
  const updatePass=resized||lastLightingLevel!==profile.level||RenderBudget.frameIndex%profile.lightEvery===0;
  if(updatePass){lightCtx.setTransform(1,0,0,1,0,0);lightCtx.clearRect(0,0,lightCanvas.width,lightCanvas.height);lightCtx.save();Camera.apply(lightCtx,DPR*profile.lightScale);drawEmissivePass(lightCtx,Math.max(.12,skyAlpha()));lightCtx.restore();lastLightingLevel=profile.level}
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalCompositeOperation='screen';ctx.imageSmoothingEnabled=true;ctx.drawImage(lightCanvas,0,0,canvas.width,canvas.height);ctx.restore();
}
function render(){
  ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,canvas.width,canvas.height);ctx.save();Camera.apply(ctx);drawWorld(ctx);drawBuildOverlay(ctx);ctx.restore();renderLighting();WeatherSystem.drawScreen(ctx);CCTVManager.update();if(RenderBudget.frameIndex%RenderBudget.profile().miniEvery===0)renderMini();if(PulseStabiliser.active)PulseStabiliser.render();
}

function applyImportedState(data){
  if(!data||typeof data!=='object')throw new Error('The selected file is not a Town Life save object.');
  const imported=migrateState(data,'import');
  if(!imported.profile||!imported.plots)throw new Error('Required save fields are missing.');
  state=imported;saveNow();location.reload();
}
function exportState(){
  saveNow();const exportData={...state,exportedAt:new Date().toISOString(),product:'Made by Matt: Town Life — Gold Master v1.0'};const blob=new Blob([JSON.stringify(exportData,null,2)],{type:'application/json'});const anchor=document.createElement('a');anchor.href=URL.createObjectURL(blob);anchor.download=`MBM_Town_Life_GOLD_v1_0_${state.profile.replace(/[^a-z0-9_-]+/gi,'_')}.json`;anchor.click();setTimeout(()=>URL.revokeObjectURL(anchor.href),1000);
}

function initialiseCatalogue(){
  const catalog=$('catalog');catalog.innerHTML='';
  for(const [id,prop] of Object.entries(PROP)){
    const button=document.createElement('button');button.className=`prop ${id===selectedProp?'active':''}`;button.innerHTML=`<strong>${prop.name}</strong><span>£${prop.cost}${prop.watts?` • ${prop.watts}W`:''}</span>`;
    button.onclick=()=>{selectedProp=id;[...catalog.children].forEach(child=>child.classList.remove('active'));button.classList.add('active')};catalog.appendChild(button);
  }
}
function setRole(role){
  if(!ROLES[role])return;state.role=role;
  if(!['Officer','Paramedic'].includes(role)&&car.siren){car.siren=false;audio.setSiren(false)}
  saveSoon();notify(`Role: ${role}`);updateUI(true);
}

function wireInterface(){
  document.querySelectorAll('[data-close]').forEach(button=>button.addEventListener('click',()=>closeModal(button.dataset.close)));
  $('startBtn').onclick=()=>{state.profile=($('profileName').value.trim()||'Player').slice(0,18);$('welcome').style.display='none';$('welcome').setAttribute('aria-hidden','true');state.firstRun=false;saveSoon();updateUI(true);wakeAudio();notify(`Welcome to Town Life, ${state.profile}`)};
  $('openHelpFromWelcome').onclick=()=>openModal('helpModal');
  $('roleSelect').onchange=event=>setRole(event.target.value);
  $('vehicleBtn').onclick=toggleVehicleSpawn;
  $('sirenBtn').onclick=toggleSiren;
  $('buildBtn').onclick=()=>toggleBuild();
  $('lightsBtn').onclick=toggleLights;
  $('jobBtn').onclick=startRoleJob;
  $('ledgerBtn').onclick=()=>TownLedger.open('citizens');$('utilityBtn').onclick=()=>UtilityConsole.open();$('cctvBtn').onclick=()=>CCTVManager.open('auto');$('nitroBtn').onclick=()=>VehicleTuning.activateNitro();document.querySelectorAll('[data-ledger-tab]').forEach(button=>button.onclick=()=>{TownLedger.tab=button.dataset.ledgerTab;TownLedger.render()});
  $('settingsBtn').onclick=()=>{$('settingsName').value=state.profile;openModal('settingsModal')};
  $('finishBuildBtn').onclick=()=>toggleBuild(false);
  $('saveNameBtn').onclick=()=>{
    const name=$('settingsName').value.trim();if(!name)return;const old=state.profile;state.profile=name.slice(0,18);for(const plot of plots)if(plot.owner===old)plot.owner=state.profile;syncPlots();saveSoon();notify('Profile name updated');updateUI(true);
  };
  $('audioToggle').onchange=event=>{audio.setEnabled(event.target.checked);saveSoon()};$('cctvToggle').onchange=event=>{state.cctvPip=event.target.checked;if(!state.cctvPip)CCTVManager.close();saveSoon()};$('utilityToggle').onchange=event=>{state.utilityTelemetry=event.target.checked;updateUtilityHUD();saveSoon()};
  $('motionToggle').onchange=event=>{state.reducedMotion=event.target.checked;saveSoon()};
  $('contrastToggle').onchange=event=>{state.highContrast=event.target.checked;updateUI(true);saveSoon()};
  $('timeToggle').onchange=event=>{state.freezeTime=event.target.checked;saveSoon()};$('cameraToggle').onchange=event=>{state.cameraEffects=event.target.checked;if(!state.cameraEffects)Camera.snapTo(car.inCar?car:player);saveSoon()};$('telemetryToggle').onchange=event=>{state.telemetry=event.target.checked;updatePowertrainHUD(car.inCar?Math.hypot(car.vx,car.vy):0);saveSoon()};$('visionToggle').onchange=event=>{state.policeCones=event.target.checked;saveSoon()};$('weatherToggle').onchange=event=>{state.weatherEffects=event.target.checked;WeatherSystem.reset();saveSoon();updateUI(true)};$('weatherSelect').onchange=event=>{state.weatherMode=event.target.value;WeatherSystem.reset();saveSoon();updateUI(true)};
  $('exportBtn').onclick=exportState;
  $('importBtn').onclick=()=>$('importFile').click();
  $('importFile').onchange=async event=>{const file=event.target.files?.[0];if(!file)return;try{applyImportedState(JSON.parse(await file.text()))}catch(error){notify(`Import failed: ${error.message}`,'danger')}};
  $('resetBtn').onclick=()=>{if(!confirm('Reset Town Life v1.0 progress in this browser?'))return;storage.remove(SAVE_KEY);location.reload()};$('cctvPrevBtn').onclick=()=>CCTVManager.cycle(-1);$('cctvNextBtn').onclick=()=>CCTVManager.cycle(1);$('cctvCloseBtn').onclick=()=>CCTVManager.close();$('utilityOpenCCTVBtn').onclick=()=>CCTVManager.open('property');
}

function calculateWorldPointer(event){const world=Camera.screenToWorld(event.clientX,event.clientY);mouse.x=world.x;mouse.y=world.y}
function handleKeyboardDown(event){
  if(event.target&&['INPUT','SELECT','TEXTAREA'].includes(event.target.tagName))return;
  const key=event.key.toLowerCase();
  if(event.key===' ')event.preventDefault();
  wakeAudio();

  if(DialogueManager.active){if(key==='escape'||key==='0'){DialogueManager.close();return}if(/^[1-9]$/.test(key)&&!event.repeat){DialogueManager.choose(Number(key)-1);return}return}

  if(SafeLockpick.active){
    if(key==='a'||key==='arrowleft'){SafeLockpick.rotate(-6);return}
    if(key==='d'||key==='arrowright'){SafeLockpick.rotate(6);return}
    if(key==='e'||key==='enter'){if(!event.repeat)SafeLockpick.confirm();return}
    if(key==='escape'){closeModal('safeModal');return}
    return;
  }
  if(PulseStabiliser.active){
    if((key==='e'||key==='enter'||key===' ')&&!event.repeat)PulseStabiliser.attempt();
    else if(key==='escape')closeModal('medicalModal');
    return;
  }
  if(SecurityScanner.active){
    if(['1','2','3'].includes(key)&&!event.repeat)SecurityScanner.choose(Number(key)-1);
    else if(key==='escape')closeModal('scanModal');
    return;
  }
  if(isAnyModalOpen()){
    if(key==='escape'&&!event.repeat)closeTopModal();
    return;
  }

  keys[key]=true;
  if(event.repeat)return;
  if(key==='e')interact();
  else if(key==='f')toggleMount();
  else if(key==='v')toggleVehicleSpawn();
  else if(key==='h')toggleSiren();
  else if(key==='l')toggleLights();
  else if(key==='x'){audio.horn();Camera.addTrauma(.08);pedestrians.forEach(ped=>{if(car.active&&Math.hypot(ped.x-car.x,ped.y-car.y)<175)ped.panicFrom(car,75)})}
  else if(key==='n')VehicleTuning.activateNitro();
  else if(key==='b')toggleBuild();
  else if(key==='r'&&buildMode){rotation=(rotation+90)%360;audio.beep(750,.03,.07)}
  else if(key==='g'&&buildMode){$('btnWire').click()}
  else if(key==='escape'&&buildMode)toggleBuild(false);
}
function handleKeyboardUp(event){keys[event.key.toLowerCase()]=false}

function wireInput(){
  addEventListener('keydown',trapModalFocus,true);
  addEventListener('keydown',handleKeyboardDown);
  addEventListener('keyup',handleKeyboardUp);
  addEventListener('blur',()=>{keys=Object.create(null)});
  document.addEventListener('visibilitychange',()=>{keys=Object.create(null);if(document.hidden&&audio.ctx?.state==='running')audio.ctx.suspend().catch(()=>{});else if(!document.hidden&&state.audio)audio.resume()});
  canvas.addEventListener('pointermove',calculateWorldPointer);
  canvas.addEventListener('pointerdown',event=>{wakeAudio();calculateWorldPointer(event);if(buildMode){if(wiringMode)wirePropAtMouse();else if(event.button===2||demolishMode)removeProp();else placeProp()}});
  canvas.addEventListener('contextmenu',event=>{if(buildMode)event.preventDefault()});
  document.querySelectorAll('[data-key]').forEach(button=>{
    const key=button.dataset.key;
    button.addEventListener('pointerdown',event=>{event.preventDefault();if(isAnyModalOpen())return;keys[key]=true;wakeAudio();button.setPointerCapture?.(event.pointerId)});
    const release=event=>{event.preventDefault();keys[key]=false};
    button.addEventListener('pointerup',release);button.addEventListener('pointercancel',release);button.addEventListener('pointerleave',release);
  });
  document.querySelectorAll('[data-tap]').forEach(button=>button.addEventListener('pointerdown',event=>{
    event.preventDefault();wakeAudio();if(isAnyModalOpen())return;const action=button.dataset.tap;if(action==='interact')interact();else if(action==='vehicle')toggleMount();else if(action==='horn'){audio.horn();pedestrians.forEach(ped=>{if(car.active&&Math.hypot(ped.x-car.x,ped.y-car.y)<175)ped.panicFrom(car,75)})}else if(action==='nitro')VehicleTuning.activateNitro()
  }));
}

let lastFrame=performance.now();
let accumulator=0;
function frame(now){
  const elapsed=Math.min(120,now-lastFrame);lastFrame=now;accumulator+=elapsed;RenderBudget.observe(elapsed);
  while(accumulator>=FIXED_STEP){updateWorldStep();accumulator-=FIXED_STEP}
  render();requestAnimationFrame(frame);
}

function installQAInterface(){
  if(!QA_MODE)return;
  window.MBMTownLifeQA={
    showColliders:false,
    getState:()=>deepClone(state),
    migrate:raw=>migrateState(raw,'mbm_town_life_v01'),
    getEntities:()=>({player:deepClone(player),car:deepClone(car)}),
    teleport:(x,y)=>{player.x=clamp(Number(x),20,WORLD.w-20);player.y=clamp(Number(y),20,WORLD.h-20);car.inCar=false;player.seatedOn=null;updateCutaways()},
    setCar:data=>{Object.assign(car,data||{});if(car.inCar){player.x=car.x;player.y=car.y}},
    setRole:role=>setRole(role),
    openWardrobe:()=>WardrobeStudio.open(),
    openSafe:()=>{state.role='Mischief';state.cargo=null;state.mission={type:'mischief',stage:'reach-bank',target:'bank'};updateCargoHUD();updateUI(true);SafeLockpick.open()},
    safeSnapshot:()=>({angle:SafeLockpick.dialAngle,gates:[...SafeLockpick.gates],directions:[...SafeLockpick.directions],gateIndex:SafeLockpick.gateIndex}),
    solveSafe:()=>{while(SafeLockpick.active&&SafeLockpick.gateIndex<SafeLockpick.gates.length){SafeLockpick.dialAngle=SafeLockpick.gates[SafeLockpick.gateIndex];SafeLockpick.lastDirection=SafeLockpick.directions[SafeLockpick.gateIndex];SafeLockpick.confirm()}},
    openCargo:()=>{state.role='Courier';state.mission=null;updateUI(true);openCargoDepot()},
    assignCargo:id=>{state.role='Courier';const cargo=CARGO_TYPES.find(item=>item.id===id)||CARGO_TYPES[0];assignCargo(cargo);updateUI(true)},
    openMedical:()=>{state.role='Paramedic';state.cargo=null;state.mission={type:'medic',stage:'respond',target:'cafe'};updateCargoHUD();updateUI(true);PulseStabiliser.open()},
    solveMedical:()=>{for(let i=0;i<3&&PulseStabiliser.active;i++){PulseStabiliser.phase=PulseStabiliser.zone;PulseStabiliser.attempt()}},
    pulseSnapshot:()=>deepClone({active:PulseStabiliser.active,phase:PulseStabiliser.phase,zone:PulseStabiliser.zone,zoneWidth:PulseStabiliser.zoneWidth,round:PulseStabiliser.round,stability:PulseStabiliser.stability}),
    openScan:mode=>{state.role='Officer';state.cargo=null;if((mode||'alarm')==='alarm'){state.bankAlarm=true;$('alert').style.display='block'}updateCargoHUD();updateUI(true);SecurityScanner.open(mode||'alarm')},
    solveScan:()=>{for(let i=0;i<3&&SecurityScanner.active;i++)SecurityScanner.choose(SecurityScanner.target)},
    claimPlot:(id,type='modern')=>{const plot=plots.find(p=>p.id===Number(id));if(plot)claimHouse(plot,type)},
    getPlots:()=>deepClone(plots),
    placePropAt:(type,x,y,rot=0)=>{selectedProp=PROP[type]?type:'sofa';mouse.x=Number(x);mouse.y=Number(y);rotation=[0,90,180,270].includes(Number(rot))?Number(rot):0;placeProp()},
    setTime:value=>{state.time=Number(value)||12},
    clearWelcome:()=>{$('welcome').style.display='none';$('welcome').setAttribute('aria-hidden','true');state.firstRun=false},
    rebuildColliders:()=>{markCollidersDirty();ensureColliders();return{player:playerColliders.length,vehicle:vehicleColliders.length}},
    getProgress:()=>deepClone({profile:state.profile,cash:state.cash,heat:state.heat,dirtyBonds:state.dirtyBonds,laundering:state.laundering,affinity:state.affinity,businesses:state.businesses,fleet:state.fleet,vehicleTune:state.vehicleTune,vehicleCondition:state.vehicleCondition,unlocks:state.unlocks,mission:state.mission,cargo:state.cargo,stats:state.stats,events:state.events,day:state.day,time:state.time,plotUtilities:state.plotUtilities,civicPower:state.civicPower,cctv:state.cctv,governance:state.governance}),
    getCitizens:()=>Object.fromEntries(Object.entries(anchorCitizens).map(([id,c])=>[id,{x:c.x,y:c.y,visible:c.visible,activity:c.activity(),bark:c.bark()}])),
    setAffinity:(id,score)=>{if(id in state.affinity){state.affinity[id]=Math.max(0,Number(score)||0);updateUnlocks();saveDirty=true;updateUI(true)}},
    openDialogue:id=>DialogueManager.open(id||'arthur'),
    chooseDialogue:index=>DialogueManager.choose(Number(index)||0),
    closeDialogue:()=>DialogueManager.close(),
    interact:()=>interact(),
    openLedger:tab=>TownLedger.open(tab||'citizens'),
    setHeat:value=>{state.heat=clamp(Number(value)||0,0,5);heatHoldTicks=0;updateUI(true)},
    addHeat:(value,reason='QA')=>addHeat(Number(value)||0,reason),
    setWeather:type=>{state.weatherMode=['auto','clear','rain','fog'].includes(type)?type:'clear';state.weatherEffects=true;WeatherSystem.reset();updateUI(true)},
    buyBusiness:id=>{state.cash=Math.max(state.cash,5000);state.unlocks.businessDeeds=true;BusinessManager.buy(id)},
    upgradeBusiness:id=>{state.cash=Math.max(state.cash,5000);BusinessManager.upgrade(id)},
    collectBusiness:id=>BusinessManager.collect(id||null),
    setTune:(type,value)=>{state.cash=Math.max(state.cash,5000);state.affinity.jax=14;VehicleTuning.set(type,value)},
    unlockNitro:()=>{state.cash=Math.max(state.cash,5000);state.affinity.jax=14;VehicleTuning.unlockNitro()},
    activateNitro:()=>{car.active=true;car.inCar=true;VehicleTuning.activateNitro()},
    addBonds:value=>{state.dirtyBonds+=Math.max(0,Number(value)||0);updateUI(true)},
    startLaundering:()=>{state.heat=0;LaunderingManager.start()},
    collectLaundering:()=>{if(state.laundering)state.laundering.readyAt=absoluteHour();LaunderingManager.collect()},
    advanceHours:value=>{const amount=Number(value)||0;const total=absoluteHour()+amount;state.day=Math.floor(total/24)+1;state.time=((total%24)+24)%24;BusinessManager.update();updateUI(true)},
    cameraSnapshot:()=>deepClone({x:Camera.x,y:Camera.y,zoom:Camera.zoom,trauma:Camera.trauma,angle:Camera.angle,shakeX:Camera.shakeX,shakeY:Camera.shakeY}),
    roadblock:()=>deepClone(roadblock),
    policeSnapshot:()=>deepClone({aggregate:aggregatePoliceState(),visibilityRange:policeVisibilityRange(car.inCar?car:player),shelter:ownedShelterState(),roadblock,units:interceptors.map(unit=>({x:unit.x,y:unit.y,angle:unit.angle,state:unit.state,detection:unit.detection,lastKnown:unit.lastKnown,searchTicks:unit.searchTicks,visibleContact:unit.visibleContact}))}),
    policeVision:()=>{const unit=interceptors[0],target=car.inCar&&car.active?car:player;return unit?deepClone(unit.assess(target)):null},
    setPoliceUnit:(index,data)=>{const unit=interceptors[Number(index)||0];if(unit)Object.assign(unit,data||{});return unit?deepClone({x:unit.x,y:unit.y,angle:unit.angle,state:unit.state,detection:unit.detection}):null},
    setLights:value=>{car.lights=Boolean(value);updateUI(true)},
    setVehicleCondition:value=>{state.vehicleCondition=clamp(Number(value)||0,0,100);updatePowertrainHUD(Math.hypot(car.vx,car.vy));updateUI(true)},
    repairVehicle:()=>repairVehicle(),
    powertrainSnapshot:()=>deepClone({gear:car.gear,rpm:car.rpm,frontLoad:car.frontLoad,rearLoad:car.rearLoad,weightTransfer:car.weightTransfer,slip:car.slip,speed:Math.hypot(car.vx,car.vy),condition:state.vehicleCondition,shiftTimer:car.shiftTimer}),
    setDriving:data=>{const input=data||{};car.active=true;car.inCar=true;car.x=Number(input.x??player.x);car.y=Number(input.y??player.y);car.angle=Number(input.angle??0);car.vx=Number(input.vx??0);car.vy=Number(input.vy??0);car.steerAngle=0;car.yawRate=0;car.weightTransfer=0;car.frontLoad=50;car.rearLoad=50;car.shiftCooldown=0;car.shiftTimer=0;car.gear=1;car.rpm=.1;car.collisionCooldown=0;car.lastSkidLeft=null;car.lastSkidRight=null;player.x=car.x;player.y=car.y;state.telemetry=true;Camera.snapTo(car);updatePowertrainHUD(Math.hypot(car.vx,car.vy));updateUI(true);return deepClone(car)},
    stepVehicle:(count=1,input={})=>{const previous=keys;keys=Object.assign(Object.create(null),input||{});for(let i=0;i<Math.max(1,Math.min(600,Number(count)||1));i++){rebuildDynamicEntityGrid();updateVehicle()}keys=previous;return window.MBMTownLifeQA.powertrainSnapshot()},
    startCovert:()=>{state.affinity.sylvia=Math.max(5,Number(state.affinity.sylvia)||0);updateUnlocks();state.mission=null;state.heat=0;startCovertCourierOperation();return deepClone({mission:state.mission,cargo:state.cargo,heat:state.heat})},
    completeCovert:()=>{const location=locationById('laundry');car.inCar=false;player.x=location.x+location.w/2;player.y=location.y+location.h/2;const action=specificLocationInteraction(location);if(action)action.run();return deepClone({mission:state.mission,cargo:state.cargo,dirtyBonds:state.dirtyBonds,stats:state.stats})},
    bribeArthur:()=>{state.affinity.arthur=Math.max(5,Number(state.affinity.arthur)||0);state.cash=Math.max(state.cash,1000);bribeArthurSecurity()},
    hireFleet:()=>{state.cash=Math.max(state.cash,9000);FleetManager.hire()},
    getUtilities:()=>deepClone(state.plotUtilities),
    utilitySnapshot:plotId=>{const plot=plots.find(p=>p.id===Number(plotId));if(!plot)return null;const util=UtilityManager.evaluate(plot,0,true);return deepClone({utility:util,demand:UtilityManager.demand(plot),devices:plot.props.filter(p=>PROP[p.type]?.watts).map(p=>({id:p.id,type:p.type,on:p.on,circuit:circuitForPlaced(p),watts:PROP[p.type].watts,powered:UtilityManager.propPowered(plot,p)}))})},
    utilityInstallCost:type=>UtilityManager.installCosts(type),
    setMainSwitch:(plotId,value)=>{const plot=plots.find(p=>p.id===Number(plotId));if(plot)UtilityManager.setMainSwitch(plot,value);return plot?deepClone(utilityFor(plot)):null},
    setCircuit:(plotId,circuit,value)=>{const plot=plots.find(p=>p.id===Number(plotId));if(plot&&POWER_CIRCUITS.includes(circuit))UtilityManager.setCircuit(plot,circuit,value);return plot?deepClone(utilityFor(plot)):null},
    setCash:value=>{state.cash=clamp(Number(value)||0,0,999999);updateUI(true);return state.cash},
    installUtility:(plotId,type)=>{const plot=plots.find(p=>p.id===Number(plotId));if(plot){if(!plot.owner)claimHouse(plot,'modern');state.cash=Math.max(state.cash,9000);UtilityManager.install(plot,type)}return plot?deepClone(utilityFor(plot)):null},
    setUtility:(plotId,data)=>{const plot=plots.find(p=>p.id===Number(plotId));if(!plot)return null;Object.assign(utilityFor(plot),data||{});UtilityManager.evaluate(plot,0,true);return deepClone(utilityFor(plot))},
    tripBreaker:plotId=>{const plot=plots.find(p=>p.id===Number(plotId));if(plot)UtilityManager.trip(plot,'QA overload');return plot?deepClone(utilityFor(plot)):null},
    resetBreaker:plotId=>{const plot=plots.find(p=>p.id===Number(plotId));return plot?UtilityManager.reset(plot):false},
    togglePlaced:(plotId,propId)=>{const plot=plots.find(p=>p.id===Number(plotId)),placed=plot?.props.find(p=>p.id===propId);if(plot&&placed)UtilityManager.togglePlaced(plot,placed);return placed?deepClone(placed):null},
    openUtility:plotId=>{const plot=plots.find(p=>p.id===Number(plotId))||ownedPlot();if(plot)UtilityConsole.open(plot)},
    openCCTV:context=>CCTVManager.open(context||'auto'),
    cycleCCTV:direction=>CCTVManager.cycle(Number(direction)||1),
    cctvSnapshot:()=>{const feed=CCTVManager.current();return deepClone({open:state.cctv.pipOpen,feed:feed?{id:feed.id,name:feed.name,powered:CCTVManager.feedPowered(feed)}:null,available:CCTVManager.feeds().map(f=>({id:f.id,name:f.name,powered:CCTVManager.feedPowered(f)}))})},
    renderCCTVFrames:count=>{const start=performance.now();for(let i=0;i<Math.max(1,Math.min(120,Number(count)||1));i++)CCTVManager.render(true);return{count:Number(count)||1,ms:performance.now()-start}},
    renderCCTVSetFrames:count=>{const frames=Math.max(1,Math.min(120,Number(count)||1)),start=performance.now();let feeds=0;for(let i=0;i<frames;i++)feeds=CCTVManager.renderAccessibleBuffers(true);return{count:frames,feeds,ms:performance.now()-start,cache:cctvFeedCache.size}},
    cutCivicPower:(id,hours)=>CCTVManager.cutCivicPower(id,Number(hours)||2),
    setCivicFund:value=>{state.governance.civicFund=Math.max(0,Number(value)||0);return state.governance.civicFund},
    enactDecree:id=>{state.role='Mayor';state.governance.civicFund=Math.max(state.governance.civicFund,2000);CivicManager.enact(id);return deepClone(state.governance)},
    voteDecree:id=>{state.role='Resident';state.governance.lastVoteDay=0;CivicManager.vote(id);return deepClone(state.governance)},
    voteDecreeRaw:id=>{state.role='Resident';CivicManager.vote(id);return deepClone(state.governance)},
    businessQuote:(id,tier=0)=>{const def=BUSINESS_DEFS[id];return def?{deed:BusinessManager.deedCost(def),upgrade:BusinessManager.upgradeCost(def,Number(tier)||0),yield:BusinessManager.yieldPerHour(id)}:null},
    updateCivic:()=>{CivicManager.update();return deepClone({governance:state.governance,effect:CivicManager.effect(),tier:CivicManager.fountainTier()})},
    setProsperity:value=>{state.governance.prosperity=clamp(Number(value)||0,0,100);state.governance.peak=Math.max(state.governance.peak,state.governance.prosperity);updateUI(true);return CivicManager.fountainTier()},
    governanceSnapshot:()=>deepClone({governance:state.governance,effect:CivicManager.effect(),tier:CivicManager.fountainTier(),calculated:CivicManager.calculateProsperity()}),
    contextSnapshot:()=>deepClone(ContextSteeringStats),
    stressTraffic:(steps=600)=>{for(let i=0;i<Math.max(1,Math.min(1800,Number(steps)||600));i++){rebuildDynamicEntityGrid();traffic.forEach(entity=>entity.update())}return deepClone({count:traffic.length,stuck:traffic.filter(t=>t.stuckTicks>120).length,stats:ContextSteeringStats,positions:traffic.map(t=>({x:t.x,y:t.y,state:t.state,stuck:t.stuckTicks}))})},
    getSynergies:()=>deepClone(businessSynergySnapshot()),
    getPerformance:()=>deepClone({staticPlayer:playerColliderGrid.stats(),staticVehicle:vehicleColliderGrid.stats(),dynamic:dynamicEntityGrid.stats(),frameCandidates:spatialFrameCandidates,roofBaseCache:roofBaseCache.size,roofMaskCache:roofMaskCache.size,tyreSmoke:tyreSmoke.length,gridSparks:gridSparks.length,traffic:traffic.length,context:ContextSteeringStats,cctvFeeds:CCTVManager.feeds().length,cctvCache:cctvFeedCache.size,renderBudget:RenderBudget.snapshot()}),
    setRenderQuality:level=>RenderBudget.force(level),
    step:count=>{for(let i=0;i<Math.max(1,Math.min(600,Number(count)||1));i++)updateWorldStep();return true},
    ready:()=>window.__MBM_TOWN_LIFE_READY__
  };
}

function initialise(){
  window.__MBM_TOWN_LIFE_STATUS__={ready:false,stage:'initialising',version:VERSION};
  document.querySelectorAll('.modalWrap').forEach(modal=>{modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-hidden','true')});
  initialiseVisualAssets();initialiseCatalogue();wireInterface();wireInput();installQAInterface();ensureColliders();
  $('profileName').value=state.profile;$('settingsName').value=state.profile;$('audioToggle').checked=state.audio;$('motionToggle').checked=state.reducedMotion;$('contrastToggle').checked=state.highContrast;$('timeToggle').checked=state.freezeTime;$('cameraToggle').checked=state.cameraEffects;$('telemetryToggle').checked=state.telemetry;$('cctvToggle').checked=state.cctvPip;$('utilityToggle').checked=state.utilityTelemetry;$('visionToggle').checked=state.policeCones;$('weatherToggle').checked=state.weatherEffects;$('weatherSelect').value=state.weatherMode;
  if(QA_MODE){state.firstRun=false;$('welcome').style.display='none'}else $('welcome').style.display=state.firstRun?'grid':'none';$('welcome').setAttribute('aria-hidden',$('welcome').style.display==='grid'?'false':'true');
  if(state.bankAlarm){$('alert').style.display='block'}state.cctv.pipOpen=false;$('cctvPip').style.display='none';
  Camera.snapTo(car.inCar?car:player);UtilityManager.updateAll();BusinessManager.update();CivicManager.update();updateUnlocks();updateCargoHUD();updateUI(true);WardrobeStudio.refresh();TownLedger.render();
  updateSaveBadge(storage.mode==='local'?'LOCAL SAVE READY':storage.mode==='session'?'SESSION-ONLY SAVE':'VOLATILE SAVE');
  if(state.flags.migratedFrom)notify(`Recovered compatible progress from ${state.flags.migratedFrom}.`,'lime');
  window.__MBM_TOWN_LIFE_READY__=true;window.__MBM_TOWN_LIFE_STATUS__={ready:true,stage:'running',version:VERSION,storage:storage.mode};
  requestAnimationFrame(frame);
  setInterval(()=>{if(saveDirty)saveNow()},5000);
  addEventListener('beforeunload',()=>{if(saveDirty)saveNow()});
}

window.addEventListener('error',event=>{
  window.__MBM_TOWN_LIFE_READY__=false;window.__MBM_TOWN_LIFE_STATUS__={ready:false,stage:'failed',version:VERSION,message:event.message};$('fatalMessage').textContent=event.message||'Unknown runtime error';$('fatalOverlay').style.display='grid';
});

try{initialise()}catch(error){
  console.error(error);window.__MBM_TOWN_LIFE_READY__=false;window.__MBM_TOWN_LIFE_STATUS__={ready:false,stage:'failed',version:VERSION,message:error.message};$('fatalMessage').textContent=error.stack||error.message;$('fatalOverlay').style.display='grid';
}
})();
