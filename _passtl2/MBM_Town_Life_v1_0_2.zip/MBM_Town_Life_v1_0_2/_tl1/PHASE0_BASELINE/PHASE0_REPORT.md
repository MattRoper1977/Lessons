# TL-1 Phase 0 — Corrected BASE

**Result: PASS, with one brief expectation recorded as WRONG. No source file changed.**

Every byte count below comes from `wc -c`; every character count comes from `LC_ALL=C.UTF-8 wc -m`.

| Gate | Corrected expectation | Measured | Result |
|---|---|---|---|
| Packaged checksums | all pass | 24/24 | PASS |
| HTML | 304,742 UTF-8 bytes / 304,462 characters | 304,742 UTF-8 bytes / 304,462 characters | PASS |
| HTML SHA-256 | artefact-controlled | `06beeed09d469ca621dd7d1ef7ecba24fd05a98f9a6a692b16fdb3dace21d15f` | PASS |
| Ending | ends `</html>` | `</html>\n` | PASS |
| Script blocks | exactly 1 | 1 | PASS |
| Inline script | 265,585 UTF-8 bytes / 265,340 characters | 265,585 UTF-8 bytes / 265,340 characters | PASS |
| Inline script SHA-256 | `5d8389e5e1669c17aa8186ce4378bb587ee1f19a733c4ae01784334a91693200` | exact match | PASS |
| Script syntax | `node --check` exit 0 | exit 0 | PASS |
| Non-ASCII script text | 151 occurrences / 245 extra UTF-8 bytes | exact; 12 code points | PASS |
| Network URL tokens | zero `http://`, zero `https://` | 0 / 0 | PASS |
| IDs | 164, all unique | 164 total / 164 unique / 0 duplicates | PASS |
| Viewport | exact amended value | `width=device-width, initial-scale=1, viewport-fit=cover` | PASS |
| Restrictive zoom directives | absent | 0 / 0 | PASS |
| Runtime / schema | `1.0.0` / `10` | `1.0.0` / `10` | PASS |
| Written or removed storage keys | exactly `mbm_town_life_v10`, `__mbm_probe` | exact set | PASS |
| Read storage keys | current key plus `v09…v01`, no other key | exact set; no extra key | PASS TO ARTEFACT |

## Storage contract ruling

Instrumented `getItem`, `setItem` and `removeItem` calls covered boot, explicit save, fresh load and legacy migration. All four phases produced zero page or console errors. The artefact calls `setItem` and `removeItem` for `__mbm_probe`, but never `getItem`; therefore the literal phrase that both authorised keys are read is wrong by one expectation. No unexpected key is read, written or removed.

This instrumentation ran at serialized origin `null` under `about:blank?qa` plus injected content. It proves key names and call directions only, not real-origin storage behaviour.
