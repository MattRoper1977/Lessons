function migrateState(raw,sourceKey){
  const base = defaultState();
  if(!raw || typeof raw !== 'object') return base;
  const merged = {
    ...base,
    profile:typeof raw.profile === 'string' ? raw.profile.slice(0,18) : base.profile,
    cash:Number.isFinite(Number(raw.cash)) ? clamp(Number(raw.cash),0,999999) : base.cash,
    role:['Resident','Officer','Paramedic','Courier','Builder','Mayor','Mischief'].includes(raw.role) ? raw.role : base.role,
    day:Number.isFinite(Number(raw.day)) ? clamp(Math.floor(Number(raw.day)),1,9999) : base.day,
    time:Number.isFinite(Number(raw.time)) ? ((Number(raw.time)%24)+24)%24 : base.time,
    freezeTime:Boolean(raw.freezeTime),
    audio:raw.audio !== false,
    reducedMotion:Boolean(raw.reducedMotion),
    highContrast:Boolean(raw.highContrast),
    cameraEffects:raw.cameraEffects !== false,
    telemetry:raw.telemetry !== false,
    cctvPip:raw.cctvPip !== false,
    utilityTelemetry:raw.utilityTelemetry !== false,
    policeCones:raw.policeCones !== false,
    weatherEffects:raw.weatherEffects !== false,
    weatherMode:['auto','clear','rain','fog'].includes(raw.weatherMode) ? raw.weatherMode : base.weatherMode,
    claimedPlot:Number.isFinite(Number(raw.claimedPlot)) ? Number(raw.claimedPlot) : null,
    mission:raw.mission && typeof raw.mission === 'object' ? deepClone(raw.mission) : null,
    cargo:raw.cargo && typeof raw.cargo === 'object' ? deepClone(raw.cargo) : null,
    bankAlarm:Boolean(raw.bankAlarm),
    firstRun:Boolean(raw.firstRun),
    avatar:sanitiseAvatar(raw.avatar),
    heat:clamp(Number(raw.heat)||0,0,5),
    dirtyBonds:clamp(Number(raw.dirtyBonds)||0,0,999999),
    laundering:raw.laundering && typeof raw.laundering === 'object' ? {amount:clamp(Number(raw.laundering.amount)||0,0,999999),readyAt:Number(raw.laundering.readyAt)||0,rate:clamp(Number(raw.laundering.rate)||.75,.5,.95)} : null,
    affinity:{...base.affinity,...(raw.affinity && typeof raw.affinity === 'object' ? raw.affinity : {})},
    citizenMemory:{...base.citizenMemory,...(raw.citizenMemory && typeof raw.citizenMemory === 'object' ? raw.citizenMemory : {})},
    businesses:{...base.businesses,...(raw.businesses && typeof raw.businesses === 'object' ? raw.businesses : {})},
    fleet:{...base.fleet,...(raw.fleet && typeof raw.fleet === 'object' ? raw.fleet : {}),drivers:Math.max(0,Math.floor(Number(raw.fleet?.drivers ?? (raw.fleet?.hired?1:0))||0))},
    vehicleTune:{...base.vehicleTune,...(raw.vehicleTune && typeof raw.vehicleTune === 'object' ? raw.vehicleTune : {}),nitrous:Boolean(raw.vehicleTune?.nitrous ?? raw.tuningBoost),ownedMods:Array.isArray(raw.vehicleTune?.ownedMods)?raw.vehicleTune.ownedMods.slice(0,40):base.vehicleTune.ownedMods},
    vehicleCondition:clamp(Number(raw.vehicleCondition ?? 100)||100,0,100),
    unlocks:{...base.unlocks,...(raw.unlocks && typeof raw.unlocks === 'object' ? raw.unlocks : {})},
    events:Array.isArray(raw.events) ? raw.events.slice(-30) : [],
    stats:{...base.stats,...(raw.stats && typeof raw.stats === 'object' ? raw.stats : {})},
    position:{
      x:Number.isFinite(Number(raw.position?.x)) ? clamp(Number(raw.position.x),20,WORLD.w-20) : base.position.x,
      y:Number.isFinite(Number(raw.position?.y)) ? clamp(Number(raw.position.y),20,WORLD.h-20) : base.position.y
    },
    flags:{...base.flags,migratedFrom:sourceKey && sourceKey !== SAVE_KEY ? sourceKey : (raw.flags?.migratedFrom ?? null)},
    civicPower:{...base.civicPower,...(raw.civicPower&&typeof raw.civicPower==='object'?raw.civicPower:{})},
    cctv:{...base.cctv,...(raw.cctv&&typeof raw.cctv==='object'?raw.cctv:{})},
    governance:{...base.governance,...(raw.governance&&typeof raw.governance==='object'?raw.governance:{})},
    plotUtilities:{},
    plots:{},
    schema:SCHEMA_VERSION,
    version:VERSION
  };
  const rawPlots = raw.plots && typeof raw.plots === 'object' ? raw.plots : {};
  const rawUtilities=raw.plotUtilities&&typeof raw.plotUtilities==='object'?raw.plotUtilities:{};
  for(const id of [1,2,3,4]){
    const p = rawPlots[id] ?? rawPlots[String(id)] ?? {};
    merged.plots[id] = {
      owner:typeof p.owner === 'string' ? p.owner.slice(0,18) : null,
      house:['modern','cottage','loft','bungalow'].includes(p.house) ? p.house : null,
      props:sanitiseProps(p.props)
    };
    merged.plotUtilities[id]=sanitiseUtility(rawUtilities[id]??rawUtilities[String(id)],id);
  }
  for(const id of ['bank','police','garage','townhall']){const value=merged.civicPower[id]||{};merged.civicPower[id]={online:value.online!==false,restoreAt:Number(value.restoreAt)||0}}
  merged.cctv.pipOpen=Boolean(merged.cctv.pipOpen);merged.cctv.selectedIndex=Math.max(0,Math.floor(Number(merged.cctv.selectedIndex)||0));merged.cctv.views=Math.max(0,Math.floor(Number(merged.cctv.views)||0));
  merged.governance.decree=['standard','curfew','subsidy','green'].includes(merged.governance.decree)?merged.governance.decree:'standard';merged.governance.decreeEndsAt=Math.max(0,Number(merged.governance.decreeEndsAt)||0);merged.governance.prosperity=clamp(Number(merged.governance.prosperity)||35,0,100);merged.governance.peak=clamp(Number(merged.governance.peak)||merged.governance.prosperity,0,100);merged.governance.civicFund=Math.max(0,Number(merged.governance.civicFund)||0);merged.governance.enacted=Math.max(0,Math.floor(Number(merged.governance.enacted)||0));merged.governance.residentVotes=Math.max(0,Math.floor(Number(merged.governance.residentVotes)||0));merged.governance.lastVoteDay=Math.max(0,Math.floor(Number(merged.governance.lastVoteDay)||0));
  return merged;
}
