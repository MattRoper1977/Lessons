# TL-1 D5 — Legacy Save Provenance

## Finding

All nine legacy keys are **reachable**, but every key feeds the same generic field-compatible normaliser. None has a key-specific source schema, mapping branch or genuine historical save fixture. The honest verdict for each key is therefore **PARTIAL**: the bridge is substantive, but complete historical fidelity is unproven.

| Legacy key | Reachable | Verdict | Basis |
|---|---:|---|---|
| `mbm_town_life_v09` | yes | **PARTIAL** | Generic normaliser; no v09-specific contract or genuine fixture |
| `mbm_town_life_v08` | yes | **PARTIAL** | Generic normaliser; no v08-specific contract or genuine fixture |
| `mbm_town_life_v07` | yes | **PARTIAL** | Generic normaliser; no v07-specific contract or genuine fixture |
| `mbm_town_life_v06` | yes | **PARTIAL** | Generic normaliser; no v06-specific contract or genuine fixture |
| `mbm_town_life_v05` | yes | **PARTIAL** | Generic normaliser; no v05-specific contract or genuine fixture |
| `mbm_town_life_v04` | yes | **PARTIAL** | Generic normaliser; no v04-specific contract or genuine fixture |
| `mbm_town_life_v03` | yes | **PARTIAL** | Generic normaliser; no v03-specific contract or genuine fixture |
| `mbm_town_life_v02` | yes | **PARTIAL** | Generic normaliser; no v02-specific contract or genuine fixture |
| `mbm_town_life_v01` | yes | **PARTIAL** | Generic normaliser; no v01-specific contract or genuine fixture |

## Measured basis

`loadState()` constructs `[SAVE_KEY, ...LEGACY_KEYS]`, visits every key in order and writes a migrated schema-10 copy to `mbm_town_life_v10` without deleting the legacy key. `migrateState()` normalises the substantial current data model, including avatar, plots, utility graphs, businesses, fleet, tuning, governance, civic power and CCTV. It also recognises four compatibility aliases: US-to-UK avatar colour fields, `tuningBoost` to nitrous and `fleet.hired` to one driver.

However, `migrateState()` has **zero references to `raw.schema`** and **zero references to `raw.version`**. The incoming `sourceKey` is used only to populate `flags.migratedFrom`; it does not select a version-specific mapping. The package contains **zero genuine v0.1–v0.9 runtime or save artefacts**.

The existing assertion **“Legacy save migrates to schema 10”** uses a synthetic in-memory object, evidenced by the marker values `profile = "Legacy"` and `cash = 777`. It proves the generic normalisation path, not the completeness of nine historical formats.

## Change ruling

**Runtime change: NO. Documentation correction: YES.** The D1 documentation sweep must describe this as a field-compatible bridge with synthetic-only historical evidence. It must not claim complete installed-base migration provenance.
