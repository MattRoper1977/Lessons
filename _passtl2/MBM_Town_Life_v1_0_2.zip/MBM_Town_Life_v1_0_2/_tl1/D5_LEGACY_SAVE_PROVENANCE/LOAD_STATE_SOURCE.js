function loadState(){
  const keys = [SAVE_KEY,...LEGACY_KEYS];
  for(const key of keys){
    const rawText = storage.get(key);
    if(!rawText) continue;
    try{
      const migrated = migrateState(JSON.parse(rawText),key);
      if(key !== SAVE_KEY) storage.set(SAVE_KEY,JSON.stringify(migrated));
      return migrated;
    }catch(error){
      console.warn(`Ignoring malformed Town Life save: ${key}`,error);
    }
  }
  return defaultState();
}
