# TL-1 D1 — Harness and Documentation Repair

**Reproduced: YES. Fixed: YES.**

## Before

- 100 result records and 100 passed records.
- 91 distinct assertion names.
- `No runtime or console errors` appeared 10 times.
- 13 assertions had empty or missing `detail` evidence.
- The separate 11/11 hardening count was advertised additively, producing the obsolete 111/111 claim.

## After

- **99/99 distinct assertions passed/attempted.**
- 99 unique names; zero duplicate names.
- One suite-level unexpected-runtime/console-error assertion.
- Zero empty details; every attempted assertion emits the observed value.
- 10/10 hardening/storage assertions remain available as a **non-additive filtered view** of the same 99 results.
- Two real-origin groups are recorded as **UNEXECUTED** and excluded from the attempted denominator.

The repaired roof-cache assertion drives the Civic Bank cutaway and proves actual cache population and repeated reads. The seven named documents contain zero obsolete 111-assertion-total claims. Literal `111` sequences that occur incidentally in immutable evidence, coordinates, hashes or other non-claim data are not rewritten to manufacture a textual zero.
