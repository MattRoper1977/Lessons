# TL-1 Phase 2 — Throttled Proxy Evidence

Generated: **2026-08-18T10:42:18.196905Z**

**Classification: THROTTLED PROXY — NOT A DEVICE MEASUREMENT.**

Each scenario used a fresh managed Chromium context, the same maximum-scene Auto-profile setup, 240 warm-up animation frames and 240 measured animation frames. CPU slowdown was applied through CDP `Emulation.setCPUThrottlingRate`. The game was injected at `about:blank?qa`, whose serialized origin is `null`; these timings do not close the open real-origin gate.

| Viewport | Coarse pointer observed | CPU throttle | Warm-up throughput | Measured elapsed | Measured throughput | Final Auto budget | Runtime errors |
|---|---:|---:|---:|---:|---:|---|---:|
| 1440 × 900 | No | 4× | 11.15 fps | 20145.9 ms | **11.91 fps** | Performance | 0 |
| 1440 × 900 | No | 6× | 6.75 fps | 33763.4 ms | **7.11 fps** | Performance | 0 |
| 390 × 844 | Yes | 4× | 25.88 fps | 8665.3 ms | **27.70 fps** | Performance | 0 |
| 390 × 844 | Yes | 6× | 14.74 fps | 14669.1 ms | **16.36 fps** | Performance | 0 |

The 390 × 844 runs observed a coarse pointer and displayed the mobile controls. All four scenarios settled to the Performance adaptive budget and recorded zero page or console errors.

These figures do **not** measure Chromebook, Android, iOS or any other physical device. Thermal behaviour, hardware GPU composition, browser chrome, battery state and physical input latency remain unexecuted.
