# TL-1 Phase −1 — Capability Probe

**Declared mode: LIMITED**

Python 3.13.5, the required standard-library modules, Node 22.16.0, npm 10.9.2, SHA-256 and GNU `wc` are available. Playwright 1.57.0 launched Chromium 144.0.7559.96; injected JavaScript executed, Canvas 2D was available, and CDP accepted CPU-throttling rates 4×, 6× and 1×.

Both real document-navigation routes were blocked before commit by managed Chromium policy:

- `file:///.../probe.html` → `net::ERR_BLOCKED_BY_ADMINISTRATOR`;
- `http://127.0.0.1:<ephemeral-port>/probe.html` → `net::ERR_BLOCKED_BY_ADMINISTRATOR`.

The loopback file was independently retrieved by `curl` with byte-identical content, proving that the HTTP server worked and that Chromium policy caused the navigation failure. Dynamic injected tests and throttled proxies are executable. Real-origin browser gates must remain unproven rather than simulated.
