# D3 Harness Attempt 1 — Rejected

The first D3 harness reached both policy-blocked navigation paths, but its exception handler then tried to evaluate `location.origin` after Chromium had destroyed the navigation execution context. That is a harness error, not a game error and not counted evidence. The independently fetched loopback body and server log are retained here for provenance. A corrected harness records blocked-before-commit results without evaluating a destroyed context.
