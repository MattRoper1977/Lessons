# D2 — Auto render-budget reproduction

**Reproduced: NO, outside run variance. Fixed: NO; no fix authorised.**

The shipped default is **Auto/adaptive**, with `forced: null`, adaptive level `high` and effective level `high` at startup. Each of the 20 counted trials used a fresh Chromium context, the same authored maximum scene, 240 animation frames, a 1440×900 viewport and serialized origin `null` under `about:blank?qa` because real URL navigation is blocked by policy.

| Profile | Five-run fps values | Median fps | Full fps spread | Median elapsed |
|---|---|---:|---:|---:|
| Auto | 54.418, 56.838, 56.238, 52.775, 55.077 | **55.077** | 52.775–56.838 | 4,357.5 ms |
| High | 55.831, 54.746, 57.165, 57.840, 57.155 | **57.155** | 54.746–57.840 | 4,199.1 ms |
| Balanced | 58.288, 58.913, 58.413, 55.434, 57.013 | **58.288** | 55.434–58.913 | 4,117.5 ms |
| Performance | 57.598, 58.323, 56.825, 57.125, 55.214 | **57.125** | 55.214–58.323 | 4,201.3 ms |

Auto’s median was 3.58% below the slowest fixed median, but its complete spread overlaps High, Balanced and Performance. The original strict ordering therefore does not reproduce beyond run-to-run noise. Four Auto runs remained High throughout; one made a single bounded downgrade to Balanced. No controller oscillation or persistent worst-path mechanism was evidenced, so Amendment 1’s ruling applies: close D2 without changing the game.
