# Town Life Gold Master v1.0 technical architecture

## Runtime shape

Town Life remains one HTML document:

```text
HTML HUD, modals and touch controls
        │
        ├── responsive CSS and comfort modes
        │
        └── one strict-mode vanilla JavaScript closure
              ├── schema-10 migration and storage bridge
              ├── fixed-step simulation
              ├── spatial-hash broadphase
              ├── solid collision and roof-cutaway caches
              ├── vehicle powertrain and procedural audio
              ├── citizen, traffic and police agents
              ├── plot electrical utility graphs
              ├── CCTV framebuffer cache
              ├── context-steering evaluator
              ├── governance and prosperity economy
              ├── operations, businesses and fleet
              └── hidden QA interface when ?qa is present
```

No imported modules, external assets or network APIs are used.

## Main loop

The game uses an accumulator-based fixed simulation step while presentation remains tied to `requestAnimationFrame`:

```text
requestAnimationFrame(now)
       │
       ├── cap elapsed time to avoid spiral-of-death recovery
       ├── run updateWorldStep() for each pending fixed step
       │     ├── refresh dynamic spatial buckets
       │     ├── update player or vehicle physics
       │     ├── update utility, economy and governance timers
       │     ├── evaluate traffic/pedestrian/police steering
       │     ├── update police visibility and operations
       │     └── update interactions and UI state
       ├── render world through cinematic camera
       ├── render adaptive lighting/weather pass
       ├── refresh CCTV buffers on profile cadence
       └── render minimap and HUD
```

Simulation decisions do not slow down when the visual quality profile changes.

## State and migration

The state root contains:

- profile, role, cash, time and comfort settings;
- plot ownership, house shells and placed props;
- `plotUtilities` for plots 1–4;
- civic-power records;
- CCTV selected feed and counters;
- governance, decree, prosperity and civic fund;
- missions, cargo, heat, fictional bonds and laundering;
- affinity, citizen memory and dialogue progression;
- businesses, fleet, tuning and vehicle condition;
- statistics, unlocks, events and migration flags.

`migrateState()` normalises every nested record and supplies missing schema-10 fields. Existing utility objects preserve identity during evaluation so asynchronous/UI references cannot be silently replaced.

## Storage bridge

```text
localStorage
   └── success → local mode
   └── SecurityError / quota denial
          ↓
sessionStorage
   └── success → session mode
   └── denial
          ↓
in-memory Map → volatile mode
```

The storage bridge verifies write/remove capability before selecting a backend. Malformed JSON is ignored with a warning and a fresh schema-10 state. Readiness remains false until state migration and interface initialisation finish.

## Electrical utility model

Each plot owns a utility object:

```javascript
{
  source: 'mains' | 'generator' | 'solar',
  mainSwitch: true,
  breakerTripped: false,
  generatorInstalled: false,
  generatorFuel: 100,
  solarInstalled: false,
  batteryInstalled: false,
  batteryCharge: 55,
  circuits: {
    lighting: true,
    appliance: true,
    security: true,
    workshop: true
  },
  loadWatts: 0,
  availableWatts: 2400,
  solarOutputWatts: 0,
  powered: true
}
```

Demand is:

```text
P_load = Σ(device watts)
         for device.on = true
         and circuit.enabled = true
```

Source capacity is:

```text
Mains       2400 W
Generator   3500 W while installed and fuel > 0
Solar       2200 × solarElevation × decreeFactor
Battery     bounded support up to approximately 1200 W
```

When demand exceeds available capacity, `trip()` preserves demand telemetry, marks the breaker tripped, generates audiovisual feedback and powers down every downstream branch. `reset()` evaluates the unchanged demand and rejects a reset if the overload remains.

Time-based source behaviour is evaluated in bounded elapsed-hour slices:

- generator fuel reduces according to running load;
- solar surplus charges an installed battery;
- solar shortfall discharges the battery;
- mains usage accumulates a bounded utility bill.

## CCTV architecture

Each accessible feed has:

```text
id, name, world x/y, angle, range, access rule, power rule
```

Property cameras reference their placed-prop record. Civic cameras reference an authorised location and a civic-power record.

Each feed receives a cached offscreen target:

```text
cctvFeedCache
   feed ID → 128×96 canvas + 2D context + last frame index
```

The render path:

```text
world entity proxy positions
→ camera-space rotation/translation
→ low-resolution clipped field
→ phosphor colour pass
→ scanlines / crosshair / timestamp
→ in-world monitor and/or 160×120 HUD PiP
```

Power validity is evaluated independently for every feed. Property cameras require the source, main switch, breaker, security branch and camera to be active. An in-world monitor also needs its own powered monitor node.

Refresh cadence follows the adaptive profile:

- High: frequent PiP and monitor updates;
- Balanced: reduced camera cadence;
- Performance: further reduced camera cadence;
- simulation and detection remain unchanged.

## Context steering

Traffic and pedestrians still use high-level destinations, but their local heading is selected by an interest/danger evaluator.

For each candidate direction:

```text
score = route interest
      + road preference
      - static obstacle danger
      - dynamic separation danger
```

The evaluator samples multiple fractions along each ray. Candidate lists come from the dynamic and static spatial hashes rather than the whole entity set. The selected direction is blended into the current heading.

Vehicle agents also include:

- emergency yielding;
- obstacle-speed reduction;
- circle-vs-world narrow phase;
- bounded stuck counter;
- turn-away repositioning if a retained deadlock threshold is exceeded.

## Spatial partition

Separate 128-pixel grids are maintained for:

- player-scale static collision geometry;
- vehicle-scale static collision geometry;
- dynamic traffic, citizens, pedestrians, player vehicle and police.

Grid queries return deduplicated nearby candidates. The same broadphase supports collision, interaction, police LOS and context steering.

## Vehicle model

The v0.9 four-speed arcade bicycle model remains:

- forward and lateral velocity decomposition;
- speed/gear torque curve;
- shift interruption and RPM drop;
- front steering and wheelbase yaw;
- handbrake rear-grip loss;
- longitudinal weight transfer;
- cargo-mass modifiers;
- vehicle-condition modifiers;
- continuous skid and bounded smoke.

The model is a readable game system, not a certified vehicle simulator.

## Police visibility

Each interceptor evaluates:

- field-of-view angle;
- effective range;
- headlights and light level;
- speed and weather modifiers;
- collision-geometry line of sight;
- last-known-position memory;
- civic heat and decree modifiers.

The state machine remains:

```text
PATROL → INVESTIGATING → PURSUIT → SEARCHING → LOST
```

Context steering now provides local obstacle avoidance during those tactical states.

## Governance and economy

`CivicManager.effect()` exposes decree multipliers consumed by:

- deed quotations;
- business upgrade quotations;
- passive yield;
- night courier payout;
- interceptor count;
- solar installation cost and output;
- Exchange conversion duration.

Prosperity is recalculated from jobs, businesses, tiers, fleet runs, solar installations, heat and vehicle condition. The renderer maps prosperity to the fountain tier.

Business state supports Tier 0–4. Fleet drivers are bounded at three and their maximum depends on owned businesses and total tier investment.

## Rendering and caches

The world renderer retains:

- pre-rendered roof base canvases;
- a shared 64 × 64 threshold field;
- cached roof masks and `destination-out` reveal;
- a lighting buffer;
- bounded weather and tyre particles;
- CCTV feed buffers;
- inverse cinematic-camera pointer transform.

The Canvas `roundRect()` compatibility bridge supplies a path fallback when the browser implementation is missing.

## Audio graph

Audio remains procedural:

- engine harmonics, sub oscillator and intake filter;
- gear shift and throttle-lift transients;
- tyre-noise filtering;
- siren and horn synthesis;
- room reflection taps;
- rain and cabin filtering;
- 50 Hz grid hum;
- switch, breaker, spark and restore transients.

The engine uses `AudioContext || webkitAudioContext`. If neither exists, initialisation returns without blocking play.

## Accessibility architecture

- semantic buttons, form controls and labelled regions;
- modal `role="dialog"` and `aria-modal` management;
- focus entry, trapping and restoration;
- Escape closure;
- reduced-motion behaviour in camera, markers and transitions;
- high-contrast mode;
- 44-pixel coarse-pointer controls;
- no restrictive viewport zoom directive;
- keyboard alternatives for movement, interaction, building and wiring.

## QA interface

When loaded with `?qa`, `window.MBMTownLifeQA` exposes deterministic probes for:

- migration and state snapshots;
- placement, circuits, breaker and source controls;
- CCTV rendering and civic power;
- vehicle stepping and police visibility;
- context-steering stress;
- governance, quotes and prosperity;
- businesses, fleet, operations and time advance;
- adaptive render budget and performance counters.

The QA interface is not shown in ordinary play.
