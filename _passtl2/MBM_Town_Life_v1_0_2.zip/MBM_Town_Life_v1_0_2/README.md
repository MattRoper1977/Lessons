# Made by Matt: Town Life — v1.0.1 recertification candidate

**Town Life** is an original, local-first top-down roleplay and emergent-simulation game delivered as one self-contained HTML file. It uses procedural Canvas graphics, procedural Web Audio and browser storage. It requires no installation, account, server, framework, imported artwork, audio files, fonts, analytics or internet connection.

Version **1.0.1** is a held TL-1 defect-fix and recertification candidate for the Gold Master. The underlying v1.0 systems remain intact: the full simulation loop built across the v0.x development iterations. Homes now have working power infrastructure; CCTV depends on that infrastructure; traffic, pedestrians and police use contextual obstacle avoidance; the Mayor and Resident roles shape town policy; prosperity, business tiers, fleets and dividends form a connected legacy economy.

Town Life is a **Made by Matt original**. It is not affiliated with, endorsed by or derived from the assets, characters, code, branding, map or fiction of Brookhaven, Roblox or another commercial roleplay game.

## Start the game

Open:

```text
MBM_Town_Life_GOLD_v1_0.html
```

The runtime is **304,742 bytes** and makes no network calls. Browsers may delay procedural audio until the first click, tap or key press. If Web Audio is unavailable, the simulation remains playable without sound.

## Core controls

| Action | Keyboard | Touch / interface |
|---|---:|---:|
| Walk or steer | WASD or arrow keys | Direction pad |
| Interact or talk | E | E button |
| Enter or exit vehicle | F | F button |
| Spawn or return vehicle | V | Vehicle button |
| Handbrake drift | Space | DRIFT |
| Siren | H | Siren button |
| Headlights | L | Lights button |
| Horn | X | HORN |
| Nitro, after installation | N | Nitro button |
| Home designer | B | Build button |
| Rotate furniture | R | Rotate button |
| Wire electrical circuits | G or Wire Circuits | Wire Circuits |
| Remove furniture | Right-click or Remove Tool | Remove Tool |
| Close a panel | Escape | Close / Cancel |

Touch controls appear automatically on coarse-pointer devices.

# Gold Master systems

## 1. Plot electrical grids

Every claimed home contains a persistent electrical topology with:

- a master isolator and resettable breaker;
- separate **Lighting**, **Appliances**, **Security** and **Workshop** branches;
- live wattage demand and source capacity;
- overload trips, blackouts, sparks and transformer hum;
- mains utility bills;
- generator installation, fuel and consumption;
- rooftop solar output linked to time of day;
- optional battery storage and night discharge;
- power-dependent lamps, televisions, fridges, workshop benches, safes, cameras and monitors.

The standard mains supply provides **2,400 W**. A generator can supply **3,500 W** while fuel remains. Solar peaks at approximately **2,200 W** before decree modifiers, with a battery adding bounded backup capacity.

The Home Designer includes **Wire Circuits**. Tap a powered device to cycle its branch assignment. Wiring is visible as colour-coded lines from the plot breaker to each connected load.

### Calibrated device loads

| Device | Draw | Default branch |
|---|---:|---|
| Lamp | 60 W | Lighting |
| Television | 180 W | Appliances |
| Fridge | 450 W | Appliances |
| CCTV camera | 35 W | Security |
| CCTV monitor | 120 W | Security |
| Electronic safe | 25 W | Security |
| Workshop bench | 1,200 W | Workshop |
| Smart wall switch | 2 W | Lighting |

Overloaded demand remains visible after a trip. A reset is refused until the player reduces load or restores a valid source, preventing a misleading instant recovery.

## 2. Powered CCTV and picture-in-picture

Player homes can contain multiple cameras and monitors. Each camera produces its own cached **128 × 96** offscreen feed; the HUD viewer presents a **160 × 120** picture-in-picture view.

Feeds include:

- phosphor-green low-resolution world proxies;
- scanlines, crosshair, timestamp and recording telemetry;
- player, traffic, citizens and police markers;
- independent per-camera transforms;
- in-world monitor playback;
- explicit **NO SIGNAL / POWER LOSS** output.

A property feed requires:

```text
main isolator closed
+ breaker online
+ security circuit enabled
+ camera switched on
+ valid power source
```

Officer and Mayor roles can also access authorised civic feeds at Civic Bank, the Police Dispatch Yard, Northstar Garage and Town Hall. The Mischief role can cut the external bank security feed from inside the building; civic power restores after a bounded town-time interval.

## 3. Context-steering AI

Town traffic has expanded to **15 autonomous vehicles**. Civilian vehicles, police and pedestrians use directional context rays rather than blindly following a rigid ribbon.

The evaluator combines:

- route interest;
- road preference;
- static building and roadblock danger;
- nearby vehicle and pedestrian separation;
- emergency-vehicle yielding;
- bounded deadlock recovery.

Traffic can steer around roadblocks, stalled vehicles and congestion. Pedestrians move through open squares, parks and shop approaches while avoiding solid walls and nearby agents. The existing **128 × 128-pixel spatial hash** supplies the nearby candidates used by the ray evaluator.

## 4. Civic governance and prosperity

The **Mayor** role can enact temporary decrees at Town Hall. Residents can vote once per town day and contribute to the civic fund.

| Decree | Connected effects |
|---|---|
| **Night Curfew Ordinance** | Extra night interceptor pressure and doubled lawful night courier rewards |
| **Infrastructure Subsidy** | Reduced deed and upgrade prices, faster Exchange conversion and improved yield |
| **Civic Green Initiative** | Lower solar and battery installation costs, stronger solar output and prosperity support |
| **Standard Civic Charter** | Normal patrol, cost, solar and yield rules |

The **Town Prosperity Index** responds to completed contracts, business ownership, business tiers, fleet activity, solar installations, heat and vehicle condition. Prosperity changes the town-square fountain from inactive to three increasingly developed visual tiers.

## 5. Commercial legacy economy

The four commercial deeds now support **four upgrade tiers**:

- Corner Cafe Franchise;
- Community Clinic Partnership;
- Northstar Garage Partnership;
- Northstar Exchange.

Connected ownership creates supply-chain synergies:

- **Garage + Exchange:** free standard repairs and faster fictional bond conversion;
- **Cafe + Clinic:** movement and medical timing benefits;
- **Town Network:** enhanced passive yield across a larger estate;
- **Commercial Fleet:** up to three hired NPC courier drivers completing automated supply runs.

The complete long-form loop is:

```text
contracts and operations
→ capital and reputation
→ commercial deed
→ Tier 2–4 upgrades
→ supply-chain synergies
→ fleet expansion
→ resident votes and mayoral decree
→ prosperity and dividends
→ further civic and business investment
```

## 6. Existing professional systems retained

Version 1.0 preserves and integrates the verified v0.9 systems:

- four-speed procedural powertrain;
- pseudo-Ackermann steering and longitudinal weight transfer;
- cargo mass, integrity and fragile-load handling;
- 90-degree police vision cones with collision-geometry occlusion;
- last-known-position investigation and search states;
- bank escape, garage recovery and Exchange conversion;
- Sylvia’s covert courier operation;
- named citizens, schedules, affinity and memory;
- avatar wardrobe and role uniforms;
- home plots, cutaway interiors and persistent furniture;
- cached roof dithering;
- dynamic rain, fog, wet-road reflection and lighting;
- adaptive High, Balanced and Performance visual budgets;
- touch controls, reduced motion and high contrast;
- local JSON export and import.

# Saves and migration

The Gold Master save key is:

```text
mbm_town_life_v10
```

The state schema is:

```text
10
```

The migration bridge probes save keys from **v0.9 through v0.1** and normalises field-compatible records into schema 10 without overwriting the older key. No genuine earlier save artefact or version-specific contract was available, so completeness for those labels remains unproven.

Storage degrades safely:

```text
localStorage
    ↓ if denied
sessionStorage
    ↓ if denied
volatile in-memory state
```

The active mode is visible as **LOCAL SAVE READY**, **SESSION SAVE** or **VOLATILE SAVE**. Export JSON before closing a volatile session.

# Verification status

The repaired TL-1 browser harness passes **99/99 distinct assertions passed/attempted** in its executed Chromium contexts. All assertion names are unique and every attempted check records a non-empty evidence detail. `PRODUCTION_HARDENING_RESULTS.json` is a **10/10 non-additive filtered view** of checks already counted in the 99; it must not be added to the suite total. Managed Chromium blocked both `file:///` and `http://127.0.0.1` navigation before document commit, so hardening, startup and accessibility remain **UNPROVEN-ON-REAL-ORIGIN** rather than passed on the shipped path.

Important verified gates include:

- schema-10 migration;
- overload and safe-reset behaviour;
- solar, battery, generator and bill flows;
- dual-camera independent buffering;
- CCTV blackout propagation and restoration;
- 15-vehicle context-steering stress with no retained deadlock;
- governance cost modifiers and decree expiry;
- Tier-4 businesses, three-driver fleet and dividend collection;
- full bank and covert-operation loops;
- 390 × 844 touch layout with no horizontal overflow;
- 44-pixel coarse-pointer control floor;
- modal focus trapping and Escape closure;
- no captured page or console errors.

See `VERIFICATION_REPORT.md` and `BROWSER_COMPATIBILITY_REPORT.md` for measured scope and limitations.

# Performance evidence

## D2 five-run reproduction

The shipped default is **Auto adaptive**, initially at the High budget with no forced profile. Five isolated maximum-scene runs were completed per profile in fresh managed Chromium processes.

| Profile | Pack single run | TL-1 median | Full five-run spread |
|---|---:|---:|---:|
| Auto | 39.98 fps | **55.08 fps** | 52.78–56.84 fps |
| High | 48.04 fps | **57.16 fps** | 54.75–57.84 fps |
| Balanced | 53.30 fps | **58.29 fps** | 55.43–58.91 fps |
| Performance | 54.20 fps | **57.13 fps** | 55.21–58.32 fps |

Auto’s median was **2.05 fps lower** than the slowest fixed median, Performance, but Auto’s complete spread overlapped every fixed-profile spread. The pack’s one-run strict ordering therefore did not reproduce outside run variance. D2 closed as **NOT-A-DEFECT**, and no adaptive-controller code or after-fix dataset was authorised.

## Throttled proxies

The maximum scene was also measured once per condition with CDP CPU throttling. These are **THROTTLED PROXIES, not device measurements**.

| Viewport | Pointer | 4× proxy | 6× proxy |
|---|---|---:|---:|
| 1440 × 900 | fine | 11.91 fps | 7.11 fps |
| 390 × 844 | coarse, mobile controls visible | 27.70 fps | 16.36 fps |

Chromebook, Android and iOS hardware were not executed. The proxy results must not be described as hardware or device FPS.

# Known platform gate

Injected automated execution was available in managed Chromium 144. The shipped `file://` path and authorised loopback HTTP route were both blocked before document commit by managed policy. Firefox, Safari/WebKit and physical Chromebook, Android and iOS devices were not executed in this pass.

The build includes static compatibility measures—`webkitAudioContext`, no-audio operation, a Canvas `roundRect()` fallback, Pointer Events, no imported modules and storage fallbacks—but those do not replace direct Firefox and Safari execution. See `BROWSER_COMPATIBILITY_REPORT.md`.

# Files in this package

- `MBM_Town_Life_GOLD_v1_0.html` — playable Gold Master;
- `QUICK_START.txt` — concise player guide;
- `TECHNICAL_ARCHITECTURE.md` — implementation architecture;
- `VERIFICATION_REPORT.md` — test evidence and limitations;
- `BROWSER_COMPATIBILITY_REPORT.md` — platform matrix;
- `CHANGELOG.md` — v1.0 changes;
- `ORIGINALITY_AND_SAFETY_NOTES.md` — originality, privacy and classroom boundaries;
- `RELEASE_MANIFEST.json` — machine-readable package inventory;
- `CHECKSUMS.sha256` — file integrity record;
- `qa/` — machine results, repaired harnesses, performance profiles and visual captures;
- `_tl1/` — preserved baseline, defect reproduction, provenance, proxy and recertification evidence.

Main HTML SHA-256 at documentation time:

```text
7d31850989bd36849be29b2e53e72e1906ff4597ab62e81e9225fa95cae9afd2
```
