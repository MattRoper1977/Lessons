# Town Life v1.0.1 candidate browser compatibility report

Verification date: **18 August 2026**

## Execution matrix

| Engine, route or device | Executed | Result |
|---|---:|---|
| Managed Chromium 144, injected content at `about:blank?qa` | Yes | 99/99 distinct assertions passed/attempted; zero unexpected page/console errors |
| Chromium `file:///…/MBM_Town_Life_GOLD_v1_0.html?qa` | Navigation attempted | Blocked before document commit: `net::ERR_BLOCKED_BY_ADMINISTRATOR`; resolved origin: none |
| Chromium loopback `http://127.0.0.1/…` | Navigation attempted | Local server returned HTTP 200 and 304,742 UTF-8 bytes, but Chromium blocked document commit; resolved origin: none |
| Firefox | No | UNEXECUTED |
| Safari / WebKit | No | UNEXECUTED |
| Chromebook hardware | No | UNEXECUTED |
| Android hardware | No | UNEXECUTED |
| iOS hardware | No | UNEXECUTED |

No unexecuted browser, route or device is represented as passed.

## Chromium evidence that did execute

The repaired harness used `page.set_content` at `about:blank?qa`. That context has `location.origin === "null"` and is not the shipped file origin. It executed:

- 99/99 distinct functional, static, accessibility, hardening and runtime assertions;
- a 10/10 non-additive hardening-focused view of checks already counted in the 99;
- local/session/volatile storage denial shims and malformed-save recovery;
- runtime storage-key instrumentation for boot, save, load and synthetic legacy migration;
- a v1.0-to-v1.0.1 save-compatibility round trip;
- 1440 × 900 and 390 × 844 layout checks;
- maximum-scene render-profile reproduction and throttled proxies;
- roof-mask cache population and repeated-hit instrumentation.

These results are useful runtime evidence but do not close D3.

## Real-origin gate

The authorised ladder was followed in order:

1. `file://` navigation: blocked by managed Chromium `URLBlocklist: ["*"]` before document commit.
2. Local HTTP on `127.0.0.1`: server reachable outside Chromium, HTTP 200, correct 304,742-UTF-8-byte body; browser navigation still blocked before document commit.

Therefore the exact origin string for every intended real-origin storage test is **none**, because no test document committed. Storage fallback, startup and accessibility are **UNPROVEN-ON-REAL-ORIGIN**. Injected content was not substituted as a pass.

## Throttled proxies — not devices

Each result is one fresh Auto-profile maximum-scene run after 240 warm-up frames, measuring 240 animation frames under CDP `Emulation.setCPUThrottlingRate`.

| Viewport | Coarse pointer observed | 4× CPU proxy | 6× CPU proxy |
|---|---:|---:|---:|
| 1440 × 900 | No | 11.91 fps | 7.11 fps |
| 390 × 844 | Yes; mobile controls displayed | 27.70 fps | 16.36 fps |

**These are THROTTLED PROXIES, not Chromebook, Android, iOS or other physical-device measurements.** All four settled to the Performance adaptive budget. Hardware thermal behaviour, GPU composition, browser chrome and device input latency were not measured.

## Static cross-engine measures

- Canvas 2D only; no WebGL, imported shader, image, audio or font dependency.
- `roundRect()` compatibility bridge using path primitives.
- `AudioContext || webkitAudioContext`; play continues when Web Audio is unavailable.
- Pointer Events, touch-action controls and keyboard alternatives.
- Browser zoom remains available; no `maximum-scale` or `user-scalable=no` token.
- localStorage → sessionStorage → volatile-memory fallback.
- Blob-based JSON export/import and no network URL tokens in the runtime.
- modern evergreen JavaScript without a transpiler or legacy-browser layer.

## Remaining direct validation

Firefox and WebKit need boot, storage, import/export, Canvas composition, audio unlock, Pointer Events, modal focus and sustained-scene execution. Chromebook, Android and iOS require physical-device input, thermal, memory and accessibility checks. Human screen-reader and motor-access evaluation also remain unexecuted.

## Support statement

The candidate has substantial managed-Chromium evidence and static cross-engine safeguards. It is **not certified on the shipped real-origin path or on Firefox, WebKit, Chromebook, Android or iOS** in this pass.
