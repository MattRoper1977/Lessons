from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from hashlib import sha256
import json,re

ROOT=Path(__file__).resolve().parent.parent
HTML=ROOT/'MBM_Town_Life_GOLD_v1_0.html'
SOURCE_ZIP=Path('/mnt/data/MBM_Town_Life_GOLD_v1_0_2026-08-17(2).zip')

def h(path): return sha256(path.read_bytes()).hexdigest()

def main():
 html_b=HTML.read_bytes(); html=html_b.decode('utf-8')
 script=re.findall(r'<script\b[^>]*>(.*?)</script>',html,re.I|re.S)[0]
 script_evidence=ROOT/'_tl1'/'D1_HARNESS_REPAIR'/'FINAL_INLINE_SCRIPT.js'
 script_evidence.parent.mkdir(parents=True,exist_ok=True)
 script_evidence.write_text(script,encoding='utf-8')
 qa=json.loads((ROOT/'qa/QA_SYSTEM_RESULTS.json').read_text())
 hard=json.loads((ROOT/'qa/PRODUCTION_HARDENING_RESULTS.json').read_text())
 gate=json.loads((ROOT/'qa/TL1_GATE_RESULTS.json').read_text())
 perf=json.loads((ROOT/'qa/PERFORMANCE_PROFILE_GOLD.json').read_text())['tl1Recertification']
 storage=json.loads((ROOT/'qa/TL1_STORAGE_KEY_TRACE.json').read_text())
 save=json.loads((ROOT/'qa/TL1_SAVE_COMPATIBILITY.json').read_text())
 files=[]
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(ROOT).as_posix()
  if rel in {'RELEASE_MANIFEST.json','CHECKSUMS.sha256'}: continue
  files.append({'path':rel,'bytes':p.stat().st_size,'sha256':h(p)})
 manifest={
  'product':'Made by Matt: Town Life',
  'release':'Gold v1.0.1 TL-1 recertification candidate',
  'status':'HELD',
  'published':False,
  'repositoryPlacement':False,
  'pullRequest':False,
  'merge':False,
  'catalogueOrShelfWork':False,
  'generatedAt':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
  'sourceArtifact':{
   'filename':SOURCE_ZIP.name,
   'sha256':h(SOURCE_ZIP),
   'unchanged':True,
  },
  'runtime':{
   'path':HTML.name,
   'version':'1.0.1',
   'saveSchema':10,
   'saveKey':'mbm_town_life_v10',
   'utf8Bytes':HTML.stat().st_size,'byteMeasurement':'stat',
   'unicodeCharacters':len(html),
   'sha256':h(HTML),
   'scriptBlocks':len(re.findall(r'<script\b[^>]*>.*?</script>',html,re.I|re.S)),
   'inlineScriptUtf8Bytes':script_evidence.stat().st_size,'inlineScriptByteMeasurement':'stat',
   'inlineScriptUnicodeCharacters':len(script),
   'inlineScriptSha256':sha256(script.encode('utf-8')).hexdigest(),
   'httpUrlTokens':html.count('http://'),
   'httpsUrlTokens':html.count('https://'),
   'idAttributes':len(re.findall(r'\bid\s*=\s*["\']([^"\']+)["\']',html,re.I)),
   'selfContained':True,
   'externalDependencies':0,
  },
  'verification':{
   'distinctAssertions':{'passed':qa['passed'],'attempted':qa['attempted'],'failed':qa['failed'],'duplicateNames':0,'emptyDetails':0},
   'hardeningView':{'passed':hard['passed'],'attempted':hard['attempted'],'additiveToSuiteTotal':False},
   'gates':{'passed':gate['passed'],'attempted':gate['attempted'],'failed':gate['failed']},
   'd2':perf['d2Reproduction']['decision'],
   'd3':'UNPROVEN-ON-REAL-ORIGIN',
   'd4':perf['d4RoofMaskCache']['classification'],
   'd5':{'v09ThroughV01':'PARTIAL','fixture':'synthetic'},
   'saveCompatibilityPassed':save['passed'],
   'storageKeys':{
    'writtenOrRemoved':storage['candidate']['sets']['writtenOrRemoved'],
    'read':storage['candidate']['sets']['read'],
    'sameAsBase':storage['candidate']['sets']==storage['base']['sets'],
   },
   'phase2Classification':'THROTTLED PROXY — not a device measurement',
  },
  'openOrUnexecuted':[
   'file:// real-origin startup, hardening, accessibility and storage',
   'loopback HTTP real-origin startup, hardening, accessibility and storage',
   'Firefox', 'WebKit', 'Chromebook hardware', 'Android hardware', 'iOS hardware',
   'human assistive-technology evaluation', 'genuine v0.9–v0.1 historical save artefacts'
  ],
  'mischiefChangeMade':False,
  'inventoryExcludes':['RELEASE_MANIFEST.json','CHECKSUMS.sha256'],
  'fileCount':len(files),
  'totalPackageFilesIncludingManifestAndChecksums':len(files)+2,
  'integrity':{'checksumFile':'CHECKSUMS.sha256','checksumScope':'every package file except CHECKSUMS.sha256 itself'},
  'files':files,
 }
 (ROOT/'RELEASE_MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'filesListed':len(files),'manifestBytes':(ROOT/'RELEASE_MANIFEST.json').stat().st_size,'gates':manifest['verification']['gates']},indent=2))
if __name__=='__main__': main()
