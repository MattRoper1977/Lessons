from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
from typing import Any

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
BASE_HTML_PATH = Path('/mnt/data/TL1_RESUME_2026-08-18/source/MBM_Town_Life_GOLD_v1_0_2026-08-17/MBM_Town_Life_GOLD_v1_0.html')
CANDIDATE_HTML_PATH = ROOT / 'MBM_Town_Life_GOLD_v1_0.html'
OUTPUT_PATH = ROOT / 'qa' / 'TL1_SAVE_COMPATIBILITY.json'
SAVE_KEY = 'mbm_town_life_v10'


def prelude(seed: dict[str, str] | None = None) -> str:
    return f"""
(() => {{
  const data={json.dumps(seed or {})};
  window.__storageTrace=[];
  const store={{
    get length(){{return Object.keys(data).length}},
    key(index){{return Object.keys(data)[index]??null}},
    getItem(key){{key=String(key);window.__storageTrace.push({{method:'getItem',key}});return Object.prototype.hasOwnProperty.call(data,key)?String(data[key]):null}},
    setItem(key,value){{key=String(key);value=String(value);window.__storageTrace.push({{method:'setItem',key,stringCodeUnits:value.length}});data[key]=value}},
    removeItem(key){{key=String(key);window.__storageTrace.push({{method:'removeItem',key}});delete data[key]}},
    clear(){{window.__storageTrace.push({{method:'clear',key:null}});for(const key of Object.keys(data))delete data[key]}}
  }};
  Object.defineProperty(window,'localStorage',{{configurable:true,value:store}});
  Object.defineProperty(window,'sessionStorage',{{configurable:true,value:store}});
  window.__saveCompatStore=data;
}})();
"""


def open_injected(browser, html: str, *, seed: dict[str, str] | None = None):
    context = browser.new_context(viewport={'width': 1440, 'height': 900})
    page = context.new_page()
    errors: list[dict[str, str]] = []
    page.on('pageerror', lambda error: errors.append({'type': 'pageerror', 'text': str(error)}))
    page.on('console', lambda message: errors.append({'type': 'console', 'text': message.text}) if message.type == 'error' else None)
    page.goto('about:blank?qa', wait_until='commit')
    page.evaluate(prelude(seed))
    page.set_content(html, wait_until='load')
    page.wait_for_function('window.__MBM_TOWN_LIFE_READY__===true')
    page.evaluate('async()=>{for(let i=0;i<4;i++)await new Promise(requestAnimationFrame)}')
    return context, page, errors


def projection(state: dict[str, Any]) -> dict[str, Any]:
    plots = state.get('plots', {})
    plot1 = plots.get('1') if isinstance(plots, dict) else None
    if plot1 is None and isinstance(plots, dict):
        plot1 = plots.get(1)
    utilities = state.get('plotUtilities', {})
    util1 = utilities.get('1') if isinstance(utilities, dict) else None
    if util1 is None and isinstance(utilities, dict):
        util1 = utilities.get(1)
    return {
        'schema': state.get('schema'),
        'version': state.get('version'),
        'profile': state.get('profile'),
        'role': state.get('role'),
        'freezeTime': state.get('freezeTime'),
        'claimedPlot': state.get('claimedPlot'),
        'plot': {
            'owner': (plot1 or {}).get('owner'),
            'house': (plot1 or {}).get('house'),
            'props': [
                {
                    'type': prop.get('type'),
                    'x': prop.get('x'),
                    'y': prop.get('y'),
                    'rot': prop.get('rot'),
                    'on': prop.get('on'),
                    'circuit': prop.get('circuit'),
                }
                for prop in (plot1 or {}).get('props', [])
            ],
        },
        'businesses': state.get('businesses'),
        'fleet': state.get('fleet'),
        'utilityGraph': {
            key: (util1 or {}).get(key)
            for key in (
                'plotId', 'source', 'mainSwitch', 'breakerTripped',
                'generatorInstalled', 'generatorFuel', 'solarInstalled',
                'batteryInstalled', 'batteryCharge', 'circuits', 'trips',
                'utilityBill', 'lastUpdateAt'
            )
        },
    }


def equivalence(base: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    fields = {
        'profile': base['profile'] == candidate['profile'],
        'role': base['role'] == candidate['role'],
        'freezeTime': base['freezeTime'] is True and candidate['freezeTime'] is True,
        'claimedPlot': base['claimedPlot'] == candidate['claimedPlot'],
        'plotOwner': base['plot']['owner'] == candidate['plot']['owner'],
        'plotHouse': base['plot']['house'] == candidate['plot']['house'],
        'plotProps': base['plot']['props'] == candidate['plot']['props'],
        'businesses': base['businesses'] == candidate['businesses'],
        'fleet': base['fleet'] == candidate['fleet'],
        'utilityGraph': base['utilityGraph'] == candidate['utilityGraph'],
        'schemaPreservedAt10': base['schema'] == 10 and candidate['schema'] == 10,
        'sourceSaveVersionIs1.0.0': base['version'] == '1.0.0',
        'candidateRuntimeVersionIs1.0.1': candidate['version'] == '1.0.1',
    }
    return {'fields': fields, 'passed': all(fields.values())}


def main() -> int:
    base_html = BASE_HTML_PATH.read_text(encoding='utf-8')
    candidate_html = CANDIDATE_HTML_PATH.read_text(encoding='utf-8')
    result: dict[str, Any] = {
        'generatedAt': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        'test': 'G6 save compatibility: v1.0 save written by runtime and loaded by v1.0.1 candidate',
        'loadingMethod': 'Playwright page.set_content at about:blank?qa with instrumented in-memory Storage API',
        'realOriginCaveat': 'D3 remains UNPROVEN-ON-REAL-ORIGIN because managed Chromium blocked both file:// and loopback HTTP before document commit.',
        'base': {
            'path': str(BASE_HTML_PATH),
            'sha256': hashlib.sha256(BASE_HTML_PATH.read_bytes()).hexdigest(),
        },
        'candidate': {
            'path': str(CANDIDATE_HTML_PATH),
            'sha256': hashlib.sha256(CANDIDATE_HTML_PATH.read_bytes()).hexdigest(),
        },
    }
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox', '--disable-gpu'])

        base_context, base_page, base_errors = open_injected(browser, base_html)
        base_page.evaluate("""async()=>{
          const q=MBMTownLifeQA;
          q.clearWelcome();
          document.getElementById('settingsName').value='TL1 Compatibility';
          document.getElementById('saveNameBtn').click();
          q.setCash(999999);
          q.setRole('Mayor');
          q.claimPlot(1,'modern');
          q.teleport(400,400);
          for(const p of [
            ['lamp',260,500,0],
            ['fridge',420,460,0],
            ['cctvCam',580,500,180],
            ['cctvMonitor',520,400,0],
            ['workbench',620,300,90]
          ])q.placePropAt(...p);
          for(const id of ['cafe','clinic','garage','laundry']){
            q.buyBusiness(id);
            q.upgradeBusiness(id);q.upgradeBusiness(id);q.upgradeBusiness(id);
          }
          q.hireFleet();q.hireFleet();q.hireFleet();
          q.advanceHours(9);
          const timeToggle=document.getElementById('timeToggle');timeToggle.checked=true;timeToggle.dispatchEvent(new Event('change',{bubbles:true}));
          q.installUtility(1,'generator');
          q.installUtility(1,'solar');
          q.installUtility(1,'battery');
          const frozen=q.getState();const frozenHour=(frozen.day-1)*24+frozen.time;
          q.setUtility(1,{source:'generator',mainSwitch:true,breakerTripped:false,generatorFuel:63,solarInstalled:true,batteryInstalled:true,batteryCharge:72,circuits:{lighting:true,appliance:false,security:true,workshop:false},trips:2,utilityBill:18.75,lastUpdateAt:frozenHour});
          q.setRole('Mayor');
          await new Promise(resolve=>setTimeout(resolve,900));
        }""")
        raw_save = base_page.evaluate("window.__saveCompatStore['mbm_town_life_v10'] || null")
        base_trace = base_page.evaluate('window.__storageTrace')
        base_state = json.loads(raw_save) if raw_save else None
        save_evidence = ROOT / '_tl1' / 'G6_SAVE_COMPATIBILITY' / 'V1_0_SAVE_PAYLOAD.json'
        save_evidence.parent.mkdir(parents=True, exist_ok=True)
        if raw_save is not None:
            save_evidence.write_bytes(raw_save.encode('utf-8'))
        result['base'].update({
            'runtimeLocation': base_page.evaluate('({href:location.href,origin:location.origin,protocol:location.protocol})'),
            'runtimeErrors': base_errors,
            'storageTrace': base_trace,
            'savePresent': raw_save is not None,
            'saveUtf8Bytes': save_evidence.stat().st_size if raw_save is not None else 0,
            'saveByteMeasurement': 'stat on _tl1/G6_SAVE_COMPATIBILITY/V1_0_SAVE_PAYLOAD.json',
            'saveUnicodeCharacters': len(raw_save) if raw_save else 0,
            'saveSha256': hashlib.sha256(save_evidence.read_bytes()).hexdigest() if raw_save is not None else None,
            'saveProjection': projection(base_state) if base_state else None,
        })
        base_context.close()

        if not raw_save:
            result['passed'] = False
            result['failure'] = 'v1.0 runtime did not write the current save key.'
        else:
            candidate_context, candidate_page, candidate_errors = open_injected(browser, candidate_html, seed={SAVE_KEY: raw_save})
            candidate_state = candidate_page.evaluate('MBMTownLifeQA.getState()')
            candidate_trace = candidate_page.evaluate('window.__storageTrace')
            base_projection = projection(base_state)
            candidate_projection = projection(candidate_state)
            comparison = equivalence(base_projection, candidate_projection)
            result['candidate'].update({
                'runtimeLocation': candidate_page.evaluate('({href:location.href,origin:location.origin,protocol:location.protocol})'),
                'runtimeErrors': candidate_errors,
                'storageTrace': candidate_trace,
                'saveProjection': candidate_projection,
            })
            result['comparison'] = comparison
            result['passed'] = bool(comparison['passed'] and not base_errors and not candidate_errors)
            candidate_context.close()

        browser.close()

    OUTPUT_PATH.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({'output': str(OUTPUT_PATH), 'passed': result.get('passed'), 'comparison': result.get('comparison')}, indent=2))
    return 0 if result.get('passed') else 1


if __name__ == '__main__':
    raise SystemExit(main())
