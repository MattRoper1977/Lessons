from __future__ import annotations

from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import re
import subprocess
import sys
import traceback
from typing import Any

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
HTML_PATH = ROOT / "MBM_Town_Life_GOLD_v1_0.html"
BASE_HTML_PATH = Path("/mnt/data/TL1_RESUME_2026-08-18/source/MBM_Town_Life_GOLD_v1_0_2026-08-17/MBM_Town_Life_GOLD_v1_0.html")
HTML_BYTES = HTML_PATH.read_bytes()
HTML = HTML_BYTES.decode("utf-8")
BASE_HTML = BASE_HTML_PATH.read_text(encoding="utf-8")
RESULTS: list[dict[str, Any]] = []
UNEXECUTED: list[dict[str, Any]] = []
ALL_RUNTIME_ERRORS: list[dict[str, Any]] = []
PAGE_METADATA: list[dict[str, Any]] = []


def now_z() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def detail_ok(detail: Any) -> bool:
    if detail is None:
        return False
    if isinstance(detail, dict):
        return len(detail) > 0
    if isinstance(detail, (list, tuple, str, bytes)):
        return len(detail) > 0
    return True


def add(group: str, name: str, passed: bool, detail: Any, *, source: str = "executed") -> None:
    if not detail_ok(detail):
        raise ValueError(f"Empty detail rejected for {group} / {name}")
    RESULTS.append({"group": group, "name": name, "status": "PASS" if passed else "FAIL", "pass": bool(passed), "detail": detail, "source": source})


def unexecuted(group: str, name: str, detail: Any) -> None:
    if not detail_ok(detail):
        raise ValueError(f"Empty detail rejected for unexecuted {group} / {name}")
    UNEXECUTED.append({"group": group, "name": name, "status": "UNEXECUTED", "pass": None, "detail": detail})


def safe_eval(page, expression: str, arg: Any = None) -> Any:
    return page.evaluate(expression, arg) if arg is not None else page.evaluate(expression)


def make_prelude(local_mode: str = "native", session_mode: str = "native", local_seed: dict[str, str] | None = None, session_seed: dict[str, str] | None = None) -> str:
    cfg = {
        "localMode": local_mode,
        "sessionMode": session_mode,
        "localSeed": local_seed or {},
        "sessionSeed": session_seed or {},
    }
    return f"""
(() => {{
  const cfg={json.dumps(cfg)};
  window.__storageTrace=[];
  window.__fakeStores={{local:{{...cfg.localSeed}},session:{{...cfg.sessionSeed}}}};
  function make(area,mode){{
    const data=window.__fakeStores[area];
    const denied=()=>{{const e=new DOMException(area+' storage denied','SecurityError');throw e}};
    return {{
      get length(){{if(mode==='deny')denied();return Object.keys(data).length}},
      key(index){{if(mode==='deny')denied();return Object.keys(data)[index]??null}},
      getItem(key){{key=String(key);window.__storageTrace.push({{area,method:'getItem',key}});if(mode==='deny')denied();return Object.prototype.hasOwnProperty.call(data,key)?String(data[key]):null}},
      setItem(key,value){{key=String(key);window.__storageTrace.push({{area,method:'setItem',key,stringCodeUnits:String(value).length}});if(mode==='deny')denied();data[key]=String(value)}},
      removeItem(key){{key=String(key);window.__storageTrace.push({{area,method:'removeItem',key}});if(mode==='deny')denied();delete data[key]}},
      clear(){{window.__storageTrace.push({{area,method:'clear',key:null}});if(mode==='deny')denied();for(const key of Object.keys(data))delete data[key]}}
    }};
  }}
  if(cfg.localMode!=='native')Object.defineProperty(window,'localStorage',{{configurable:true,value:make('local',cfg.localMode)}});
  if(cfg.sessionMode!=='native')Object.defineProperty(window,'sessionStorage',{{configurable:true,value:make('session',cfg.sessionMode)}});
}})();
"""


def open_page(browser, label: str, *, html: str = HTML, viewport: dict[str, int] | None = None, mobile: bool = False, touch: bool = False, prelude: str | None = None, ignore_expected_errors: tuple[str, ...] = ()):
    context = browser.new_context(
        viewport=viewport or {"width": 1440, "height": 900},
        device_scale_factor=1,
        is_mobile=mobile,
        has_touch=touch,
    )
    page = context.new_page()
    errors: list[dict[str, Any]] = []

    def on_page_error(error):
        text = str(error)
        expected = any(token in text for token in ignore_expected_errors)
        entry = {"page": label, "type": "pageerror", "text": text, "expected": expected}
        errors.append(entry)
        if not expected:
            ALL_RUNTIME_ERRORS.append(entry)

    def on_console(message):
        if message.type != "error":
            return
        text = message.text
        expected = any(token in text for token in ignore_expected_errors)
        entry = {"page": label, "type": "console", "text": text, "expected": expected}
        errors.append(entry)
        if not expected:
            ALL_RUNTIME_ERRORS.append(entry)

    page.on("pageerror", on_page_error)
    page.on("console", on_console)
    page.goto("about:blank?qa", wait_until="commit", timeout=15000)
    if prelude:
        page.evaluate(prelude)
    page.set_content(html, wait_until="load", timeout=30000)
    page.wait_for_function("window.__MBM_TOWN_LIFE_READY__===true", timeout=30000)
    page.evaluate("async()=>{for(let i=0;i<3;i++)await new Promise(requestAnimationFrame)}")
    location = page.evaluate("({href:location.href,origin:location.origin,protocol:location.protocol})")
    PAGE_METADATA.append({"label": label, "location": location, "viewport": viewport or {"width": 1440, "height": 900}, "mobile": mobile, "touch": touch})
    return context, page, errors


def close_context(context) -> None:
    try:
        context.close()
    except Exception as exc:
        ALL_RUNTIME_ERRORS.append({"page": "harness", "type": "context-close", "text": repr(exc), "expected": False})


def static_checks() -> None:
    ids = re.findall(r"\bid\s*=\s*['\"]([^'\"]+)['\"]", HTML, flags=re.I)
    dupes = sorted([name for name, count in Counter(ids).items() if count > 1])
    add("static", "HTML IDs are unique", len(ids) == 164 and not dupes, {"count": len(ids), "unique": len(set(ids)), "duplicates": dupes, "expectedCount": 164})

    version_match = re.search(r"const\s+VERSION\s*=\s*'([^']+)'", HTML)
    add("static", "Runtime version declaration is 1.0.1", bool(version_match and version_match.group(1) == "1.0.1"), {"observed": version_match.group(1) if version_match else None, "expected": "1.0.1", "matches": len(re.findall(r"const\s+VERSION\s*=", HTML))})

    schema_match = re.search(r"const\s+SCHEMA_VERSION\s*=\s*(\d+)", HTML)
    add("static", "Save schema declaration remains 10", bool(schema_match and schema_match.group(1) == "10"), {"observed": int(schema_match.group(1)) if schema_match else None, "expected": 10})

    external_scripts = re.findall(r"<script\b[^>]*\bsrc\s*=\s*['\"]([^'\"]+)", HTML, flags=re.I)
    add("static", "No external script dependency", not external_scripts, {"externalScriptCount": len(external_scripts), "sources": external_scripts})

    stylesheets = re.findall(r"<link\b[^>]*\brel\s*=\s*['\"][^'\"]*stylesheet[^'\"]*['\"][^>]*>", HTML, flags=re.I)
    add("static", "No external stylesheet dependency", not stylesheets, {"externalStylesheetCount": len(stylesheets), "elements": stylesheets})

    viewport_match = re.search(r"<meta\s+name=['\"]viewport['\"]\s+content=['\"]([^'\"]+)['\"]", HTML, flags=re.I)
    viewport = viewport_match.group(1) if viewport_match else None
    restricted = {"maximum-scale": HTML.lower().count("maximum-scale"), "user-scalable=no": HTML.lower().count("user-scalable=no")}
    add("static", "Viewport preserves browser zoom", viewport == "width=device-width, initial-scale=1, viewport-fit=cover" and sum(restricted.values()) == 0, {"observed": viewport, "expected": "width=device-width, initial-scale=1, viewport-fit=cover", "restrictiveTokenCounts": restricted})

    scripts = re.findall(r"<script\b[^>]*>(.*?)</script>", HTML, flags=re.I | re.S)
    script = scripts[0] if len(scripts) == 1 else ""
    script_evidence = ROOT / "_tl1" / "D1_HARNESS_REPAIR" / "FINAL_INLINE_SCRIPT.js"
    script_evidence.parent.mkdir(parents=True, exist_ok=True)
    script_evidence.write_text(script, encoding="utf-8")
    script_bytes = script_evidence.stat().st_size
    script_chars = len(script)
    script_hash = hashlib.sha256(script_evidence.read_bytes()).hexdigest() if script else None
    add("static", "One self-contained executable script parses", len(scripts) == 1, {"scriptBlocks": len(scripts), "inlineScriptBytes": script_bytes, "inlineScriptCharacters": script_chars, "inlineScriptSha256": script_hash})

    hash_cells = [int(v) for v in re.findall(r"new\s+SpatialHashGrid\((\d+)\)", HTML)]
    add("static", "All spatial hash grids use 128px cells", hash_cells == [128, 128, 128], {"configuredCellSizes": hash_cells, "gridCount": len(hash_cells)})

    direct_refs = re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", HTML)
    missing_refs = sorted(set(direct_refs) - set(ids))
    add("static", "All direct DOM ID references resolve", not missing_refs, {"references": len(direct_refs), "uniqueReferences": len(set(direct_refs)), "missing": missing_refs})

    url_counts = {"http://": HTML.count("http://"), "https://": HTML.count("https://")}
    add("static", "Runtime contains zero network URL tokens", sum(url_counts.values()) == 0, {"counts": url_counts, "total": sum(url_counts.values())})

    add("static", "Candidate remains a compact single HTML file", HTML_PATH.stat().st_size == 304742 and HTML.rstrip().endswith("</html>"), {"utf8Bytes": HTML_PATH.stat().st_size, "byteMeasurement": "stat", "unicodeCharacters": len(HTML), "endsHtml": HTML.rstrip().endswith("</html>"), "trailingLf": HTML.endswith("\n")})

    brand_match = re.search(r"<div class=\"brand\">.*?</div>", HTML, flags=re.S)
    base_brand_match = re.search(r"<div class=\"brand\">.*?</div>", BASE_HTML, flags=re.S)
    add("static", "Made by Matt brand block is byte-identical to BASE", bool(brand_match and base_brand_match and brand_match.group(0) == base_brand_match.group(0) and "Made by Matt" in HTML), {"madeByMattOccurrences": HTML.count("Made by Matt"), "brandBlockSha256": hashlib.sha256((brand_match.group(0) if brand_match else "").encode()).hexdigest(), "baseBrandBlockSha256": hashlib.sha256((base_brand_match.group(0) if base_brand_match else "").encode()).hexdigest()})


def startup_checks(browser) -> None:
    context, page, errors = open_page(browser, "startup")
    q = "window.MBMTownLifeQA"
    status = page.evaluate("window.__MBM_TOWN_LIFE_STATUS__")
    state = page.evaluate(f"{q}.getState()")
    perf = page.evaluate(f"{q}.getPerformance()")
    add("startup", "Boot readiness flag is true", status.get("ready") is True and status.get("stage") == "running", {"status": status, "loadingContext": PAGE_METADATA[-1]["location"]})
    add("startup", "Runtime reports version 1.0.1", state.get("version") == "1.0.1" and status.get("version") == "1.0.1", {"stateVersion": state.get("version"), "statusVersion": status.get("version")})
    add("startup", "Runtime save schema is 10", state.get("schema") == 10, {"observed": state.get("schema"), "expected": 10})
    utilities = state.get("plotUtilities", {})
    add("startup", "Four utility grids initialise", sorted(str(k) for k in utilities.keys()) == ["1", "2", "3", "4"], {"keys": sorted(str(k) for k in utilities.keys()), "records": utilities})
    governance = state.get("governance", {})
    add("startup", "Governance state initialises", all(key in governance for key in ("decree", "prosperity", "civicFund", "residentVotes")), {"governance": governance})
    add("startup", "Fifteen autonomous traffic vehicles initialise", perf.get("traffic") == 15, {"observedTraffic": perf.get("traffic"), "expectedTraffic": 15, "dynamicGrid": perf.get("dynamic")})

    migrated = page.evaluate(f"{q}.migrate({{profile:'Legacy',cash:777,avatar:{{hairColor:'#111111',topColor:'#222222'}},businesses:{{cafe:{{owned:true,tier:2,stored:33}}}},fleet:{{hired:true}}}})")
    add("startup", "Synthetic legacy fixture migrates to schema 10", migrated.get("schema") == 10 and migrated.get("cash") == 777 and migrated.get("profile") == "Legacy", {"fixtureType": "synthetic in-memory object", "observed": {"schema": migrated.get("schema"), "cash": migrated.get("cash"), "profile": migrated.get("profile"), "migratedFrom": migrated.get("flags", {}).get("migratedFrom")}})
    util1 = migrated.get("plotUtilities", {}).get("1") or migrated.get("plotUtilities", {}).get(1)
    add("startup", "Migration creates a complete utility graph", isinstance(util1, dict) and util1.get("source") == "mains" and set(util1.get("circuits", {}).keys()) == {"lighting", "appliance", "security", "workshop"}, {"plot1Utility": util1})
    avatar = migrated.get("avatar", {})
    add("startup", "Migration normalises legacy avatar colour aliases", avatar.get("hairColour") == "#111111" and avatar.get("topColour") == "#222222", {"avatar": avatar, "aliasesTested": ["hairColor", "topColor"]})
    business = migrated.get("businesses", {}).get("cafe", {})
    fleet = migrated.get("fleet", {})
    add("startup", "Migration retains business and fleet progress", business.get("owned") is True and business.get("tier") == 2 and business.get("stored") == 33 and fleet.get("drivers") == 1, {"business": business, "fleet": fleet})

    controls = page.evaluate("""() => [...document.querySelectorAll('input:not([type="hidden"]):not([hidden]),select:not([hidden]),textarea:not([hidden])')].map(el=>({id:el.id,type:el.type||el.tagName.toLowerCase(),aria:el.getAttribute('aria-label'),label:el.id?document.querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent.trim()||null:null,wrapped:!!el.closest('label')})).filter(x=>!(x.aria||x.label||x.wrapped))""")
    add("accessibility", "Form controls expose IDs or accessible names", len(controls) == 0, {"unlabelledControls": controls, "controlCount": page.evaluate("document.querySelectorAll('input:not([type=hidden]):not([hidden]),select:not([hidden]),textarea:not([hidden])').length")})
    close_context(context)


def powertrain_checks(browser) -> None:
    context, page, errors = open_page(browser, "powertrain")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;
      q.clearWelcome();
      q.setDriving({x:1400,y:1000,angle:0,vx:0,vy:0});
      const acceleration=q.stepVehicle(90,{w:true});
      q.setDriving({x:1400,y:1000,angle:0,vx:10.5,vy:0});
      const fourth=q.stepVehicle(8,{});
      q.setDriving({x:1400,y:1000,angle:0,vx:8,vy:0});
      const braking=q.stepVehicle(5,{s:true});
      q.setDriving({x:1400,y:1000,angle:0,vx:5,vy:3});
      const slip=q.stepVehicle(5,{' ':true,d:true});
      const conditionAfterControlled=q.powertrainSnapshot().condition;
      q.setCash(500);q.setVehicleCondition(50);const before=q.getState().cash;const repaired=q.repairVehicle();
      return {acceleration,fourth,braking,slip,conditionAfterControlled,beforeRepairCash:before,afterRepair:q.powertrainSnapshot(),afterRepairCash:q.getState().cash,repairReturn:repaired};
    }""")
    acc = data["acceleration"]
    add("powertrain", "Acceleration transfers load rearward", acc["rearLoad"] > acc["frontLoad"] and acc["speed"] > 0, {"snapshot": acc})
    fourth = data["fourth"]
    add("powertrain", "Four-speed gearbox reaches fourth gear", fourth["gear"] == 4, {"snapshot": fourth, "startingSpeed": 10.5})
    braking = data["braking"]
    add("powertrain", "Braking transfers load to front axle", braking["frontLoad"] > braking["rearLoad"], {"snapshot": braking})
    slip = data["slip"]
    add("powertrain", "Handbrake and lateral motion produce measurable slip", slip["slip"] > 0.05, {"snapshot": slip, "threshold": 0.05})
    add("powertrain", "Controlled dynamics do not damage the vehicle", data["conditionAfterControlled"] == 100, {"condition": data["conditionAfterControlled"], "expected": 100})
    add("powertrain", "Vehicle repair restores condition", data["afterRepair"]["condition"] == 100 and data["afterRepairCash"] < data["beforeRepairCash"], {"beforeCash": data["beforeRepairCash"], "afterCash": data["afterRepairCash"], "snapshot": data["afterRepair"], "returnValue": data["repairReturn"]})
    close_context(context)


def police_checks(browser) -> None:
    context, page, errors = open_page(browser, "police-stealth")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;q.clearWelcome();q.setTime(23);q.setWeather('clear');q.setHeat(5);q.step(1);
      q.setDriving({x:1250,y:1000,angle:0,vx:0,vy:0});q.setLights(true);q.setPoliceUnit(0,{x:1000,y:1000,angle:0,state:'PATROL',detection:0,lastKnown:null,searchTicks:0});
      const open=q.policeVision();
      q.setDriving({x:1425,y:1180,angle:0,vx:0,vy:0});q.setPoliceUnit(0,{x:1425,y:830,angle:Math.PI/2,state:'PATROL',detection:0,lastKnown:null,searchTicks:0});
      const wall=q.policeVision();
      q.setDriving({x:1300,y:1000,angle:0,vx:0,vy:0});q.setPoliceUnit(0,{x:1000,y:1000,angle:0,state:'PATROL',detection:0,lastKnown:null,searchTicks:0});q.setLights(false);const lightsOff=q.policeVision();q.setLights(true);const lightsOn=q.policeVision();
      q.setDriving({x:1250,y:1000,angle:0,vx:0,vy:0});q.setLights(true);q.setPoliceUnit(0,{x:1000,y:1000,angle:0,state:'PATROL',detection:.99,lastKnown:null,searchTicks:0});q.step(1);const pursuit=q.policeSnapshot();
      q.teleport(1425,1175);q.setCar({active:false,inCar:false});q.step(28);const memory=q.policeSnapshot();
      q.setDriving({x:1250,y:1000,angle:0,vx:0,vy:0});q.setPoliceUnit(0,{x:1000,y:1000,angle:0,state:'PATROL',detection:0,lastKnown:null,searchTicks:0});q.setLights(true);q.setWeather('fog');const fog=q.policeVision();q.setWeather('clear');const clear=q.policeVision();
      return {open,wall,lightsOff,lightsOn,pursuit,memory,fog,clear};
    }""")
    add("police-stealth", "Open-road target enters a police cone with line of sight", bool(data["open"] and data["open"]["inCone"] and data["open"]["los"]), {"assessment": data["open"]})
    add("police-stealth", "Civic Bank structure occludes police line of sight", bool(data["wall"] and data["wall"]["inCone"] and not data["wall"]["los"]), {"assessment": data["wall"], "target": {"x": 1425, "y": 1180}, "unit": {"x": 1425, "y": 830}})
    lights_pass = bool(data["lightsOff"] and data["lightsOn"] and data["lightsOn"]["range"] > data["lightsOff"]["range"] and data["lightsOff"]["range"] < 300 <= data["lightsOn"]["range"])
    add("police-stealth", "Headlights change the night detection threshold", lights_pass, {"distance": 300, "lightsOff": data["lightsOff"], "lightsOn": data["lightsOn"]})
    add("police-stealth", "Confirmed visual contact escalates tactical police state", data["pursuit"]["aggregate"] in ("PURSUIT", "SEARCHING"), {"snapshot": data["pursuit"]})
    units = data["memory"].get("units", [])
    memory_pass = any(unit.get("lastKnown") and unit.get("state") in ("SEARCHING", "PURSUIT", "INVESTIGATING") for unit in units)
    add("police-stealth", "Police retain last-known-position search memory", memory_pass, {"aggregate": data["memory"].get("aggregate"), "units": units})
    add("police-stealth", "Fog reduces police visibility range", data["fog"]["range"] < data["clear"]["range"], {"fog": data["fog"], "clear": data["clear"]})
    close_context(context)


def utility_checks(browser) -> None:
    context, page, errors = open_page(browser, "utilities")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;q.clearWelcome();q.setCash(999999);q.claimPlot(1,'modern');q.teleport(400,400);
      const items=[['workbench',250,220,0],['workbench',560,220,0],['lamp',260,500,0],['fridge',420,460,0],['cctvCam',580,500,0],['cctvCam',640,500,180],['cctvMonitor',520,400,0]];
      for(const p of items)q.placePropAt(...p);
      const baseline=q.utilitySnapshot(1);
      let props=q.getPlots()[0].props;const benches=props.filter(p=>p.type==='workbench');
      q.togglePlaced(1,benches[0].id);q.togglePlaced(1,benches[1].id);const overload=q.utilitySnapshot(1);
      const unsafeResult=q.resetBreaker(1);const unsafeSnapshot=q.utilitySnapshot(1);
      q.togglePlaced(1,benches[0].id);const safeResetResult=q.resetBreaker(1);const safeReset=q.utilitySnapshot(1);
      const off=q.setMainSwitch(1,false);const on=q.setMainSwitch(1,true);
      q.setCircuit(1,'security',false);const securityOff=q.utilitySnapshot(1);q.setCircuit(1,'security',true);
      const solarStandard=q.utilityInstallCost('solar');q.setCivicFund(2000);q.enactDecree('green');const solarGreen=q.utilityInstallCost('solar');
      q.installUtility(1,'solar');q.installUtility(1,'battery');q.setTime(12);q.setUtility(1,{source:'solar',batteryCharge:100,breakerTripped:false,mainSwitch:true});const solarDay=q.utilitySnapshot(1);
      q.togglePlaced(1,benches[1].id);q.setTime(23);q.setUtility(1,{source:'solar',batteryCharge:100,breakerTripped:false});const batteryNight=q.utilitySnapshot(1);
      q.installUtility(1,'generator');q.setUtility(1,{source:'generator',generatorFuel:100,lastUpdateAt:23});q.step(600);const generator=q.utilitySnapshot(1);
      q.setTime(8);q.setUtility(1,{source:'mains',utilityBill:0,lastUpdateAt:8});q.advanceHours(4);q.step(60);const mainsBill=q.utilitySnapshot(1);
      return {baseline,overload,unsafeResult,unsafeSnapshot,safeResetResult,safeReset,off,on,securityOff,solarStandard,solarGreen,solarDay,batteryNight,generator,mainsBill,benches};
    }""")
    add("utilities", "Powered appliance placement contributes a 700W baseline", data["baseline"]["demand"] == 700 and data["baseline"]["utility"]["powered"], {"snapshot": data["baseline"]})
    add("utilities", "A 3.1kW load trips the 2.4kW mains breaker", data["overload"]["demand"] == 3100 and data["overload"]["utility"]["breakerTripped"], {"snapshot": data["overload"], "mainsCapacityWatts": 2400})
    add("utilities", "Unsafe breaker reset is rejected with evidence", data["unsafeResult"] is False and data["unsafeSnapshot"]["utility"]["breakerTripped"], {"resetReturn": data["unsafeResult"], "demandWatts": data["unsafeSnapshot"]["demand"], "capacityWatts": data["unsafeSnapshot"]["utility"]["availableWatts"], "breakerTripped": data["unsafeSnapshot"]["utility"]["breakerTripped"]})
    add("utilities", "Reducing demand permits a safe breaker reset", data["safeResetResult"] is True and not data["safeReset"]["utility"]["breakerTripped"] and data["safeReset"]["demand"] <= 2400, {"resetReturn": data["safeResetResult"], "snapshot": data["safeReset"]})
    add("utilities", "Main isolator disconnects and restores the property", not data["off"]["powered"] and data["on"]["powered"], {"off": data["off"], "on": data["on"]})
    sec_devices = [d for d in data["securityOff"]["devices"] if d["circuit"] == "security"]
    add("utilities", "Security branch isolates cameras and monitor", bool(sec_devices) and all(not d["powered"] for d in sec_devices), {"securityDevices": sec_devices, "allDevices": data["securityOff"]["devices"]})
    add("utilities", "Green Initiative lowers rooftop solar installation cost", data["solarGreen"] < data["solarStandard"], {"standardCost": data["solarStandard"], "greenCost": data["solarGreen"]})
    add("utilities", "Solar plus battery powers the daytime property", data["solarDay"]["utility"]["source"] == "solar" and data["solarDay"]["utility"]["solarOutputWatts"] > 0 and data["solarDay"]["utility"]["powered"], {"snapshot": data["solarDay"]})
    add("utilities", "Backup battery sustains a modest night load", data["batteryNight"]["utility"]["solarOutputWatts"] == 0 and data["batteryNight"]["utility"]["powered"] and data["batteryNight"]["demand"] == 700, {"snapshot": data["batteryNight"]})
    add("utilities", "Generator consumes fuel while supplying load", data["generator"]["utility"]["generatorFuel"] < 100 and data["generator"]["utility"]["powered"], {"snapshot": data["generator"], "startingFuel": 100})
    add("utilities", "Mains usage accrues a bounded utility bill", 0 < data["mainsBill"]["utility"]["utilityBill"] < 1000, {"utilityBill": data["mainsBill"]["utility"]["utilityBill"], "snapshot": data["mainsBill"]})
    close_context(context)


def cctv_checks(browser) -> None:
    context, page, errors = open_page(browser, "cctv")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;q.clearWelcome();q.setCash(999999);q.claimPlot(1,'modern');q.teleport(400,400);
      for(const p of [['cctvCam',260,220,0],['cctvCam',580,220,180],['cctvMonitor',300,500,0]])q.placePropAt(...p);
      q.openCCTV('property');const initial=q.cctvSnapshot();const firstId=initial.feed?.id;const buffers=q.renderCCTVSetFrames(4);q.cycleCCTV(1);const cycled=q.cctvSnapshot();
      q.setCircuit(1,'security',false);const branchOff=q.cctvSnapshot();q.setCircuit(1,'security',true);const branchOn=q.cctvSnapshot();
      q.tripBreaker(1);const breakerOff=q.cctvSnapshot();const reset=q.resetBreaker(1);const breakerOn=q.cctvSnapshot();
      q.setRole('Officer');q.openCCTV('auto');const civic=q.cctvSnapshot();q.cutCivicPower('bank',2);const bankOff=q.cctvSnapshot().available.find(f=>f.id==='bank-vault');q.advanceHours(3);const bankOn=q.cctvSnapshot().available.find(f=>f.id==='bank-vault');
      return {initial,firstId,buffers,cycled,branchOff,branchOn,breakerOff,reset,breakerOn,civic,bankOff,bankOn,performance:q.getPerformance()};
    }""")
    add("cctv", "Owned property exposes two independent camera feeds", len(data["initial"]["available"]) == 2, {"snapshot": data["initial"]})
    add("cctv", "CCTV offscreen buffers populate per feed", data["buffers"]["feeds"] == 2 and data["buffers"]["cache"] == 2, {"renderResult": data["buffers"], "performance": data["performance"]})
    add("cctv", "CCTV channel cycling selects a different feed", data["cycled"]["feed"]["id"] != data["firstId"], {"beforeFeed": data["firstId"], "after": data["cycled"]})
    add("cctv", "Security branch outage disables property feeds", all(not f["powered"] for f in data["branchOff"]["available"]), {"snapshot": data["branchOff"]})
    add("cctv", "Security branch restoration recovers property feeds", all(f["powered"] for f in data["branchOn"]["available"]), {"snapshot": data["branchOn"]})
    add("cctv", "Breaker outage and reset propagate to CCTV feeds", all(not f["powered"] for f in data["breakerOff"]["available"]) and data["reset"] is True and all(f["powered"] for f in data["breakerOn"]["available"]), {"breakerOff": data["breakerOff"], "resetReturn": data["reset"], "breakerOn": data["breakerOn"]})
    add("cctv", "Officer role exposes the four-feed civic network", {f["id"] for f in data["civic"]["available"] if f["id"] in {"bank-vault", "police-yard", "garage-entry", "townhall-square"}} == {"bank-vault", "police-yard", "garage-entry", "townhall-square"}, {"snapshot": data["civic"]})
    add("cctv", "Timed Civic Bank power cut disables and restores the vault feed", data["bankOff"] and not data["bankOff"]["powered"] and data["bankOn"] and data["bankOn"]["powered"], {"afterCut": data["bankOff"], "afterThreeHours": data["bankOn"]})
    close_context(context)


def context_and_roof_checks(browser) -> None:
    context, page, errors = open_page(browser, "context-steering")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;q.clearWelcome();const stress=q.stressTraffic(1200);const perf=q.getPerformance();
      const budgets=[];for(const level of ['high','balanced','performance']){q.setRenderQuality(level);budgets.push(q.getPerformance().renderBudget)}q.setRenderQuality(null);budgets.push(q.getPerformance().renderBudget);
      return {stress,perf,budgets};
    }""")
    stress = data["stress"]
    add("context-steering", "Stress scene retains all 15 traffic vehicles", stress["count"] == 15, {"count": stress["count"], "positions": stress["positions"]})
    add("context-steering", "No traffic vehicle remains deadlocked after 1200 updates", stress["stuck"] == 0, {"stuck": stress["stuck"], "stats": stress["stats"], "positions": stress["positions"]})
    add("context-steering", "Ray context evaluator performs obstacle avoidance", stress["stats"]["evaluations"] > 0 and stress["stats"]["rays"] >= stress["stats"]["evaluations"] * 8 and stress["stats"]["avoidances"] > 0, {"stats": stress["stats"]})
    perf = data["perf"]
    add("context-steering", "Static collision broadphase uses 128px cells", perf["staticPlayer"]["cellSize"] == 128 and perf["staticVehicle"]["cellSize"] == 128, {"player": perf["staticPlayer"], "vehicle": perf["staticVehicle"]})
    add("context-steering", "Dynamic spatial partition is populated", perf["dynamic"]["cellSize"] == 128 and perf["dynamic"]["buckets"] > 0 and perf["dynamic"]["insertions"] > 0, {"dynamic": perf["dynamic"]})
    levels = [item["level"] for item in data["budgets"]]
    forced = [item["forced"] for item in data["budgets"]]
    add("context-steering", "Render budget supports High, Balanced, Performance and Auto", levels[:3] == ["high", "balanced", "performance"] and forced[-1] is None, {"snapshots": data["budgets"]})
    close_context(context)

    context, page, errors = open_page(browser, "roof-mask")
    page.evaluate("""() => {
      const get=Map.prototype.get,set=Map.prototype.set,pattern=/^\\d+x\\d+\\|\\d+\\|-?\\d+\\|-?\\d+\\|-?\\d+$/;
      window.__roofTrace={gets:0,hits:0,misses:0,sets:0};
      Map.prototype.get=function(k){const v=get.call(this,k);if(pattern.test(String(k))){__roofTrace.gets++;if(v)__roofTrace.hits++;else __roofTrace.misses++;}return v};
      Map.prototype.set=function(k,v){if(pattern.test(String(k)))__roofTrace.sets++;return set.call(this,k,v)};
    }""")
    before = page.evaluate("({cache:MBMTownLifeQA.getPerformance().roofMaskCache,trace:{...__roofTrace}})")
    page.evaluate("MBMTownLifeQA.teleport(1425,1175)")
    page.evaluate("async()=>{for(let i=0;i<150;i++)await new Promise(requestAnimationFrame)}")
    after = page.evaluate("({cache:MBMTownLifeQA.getPerformance().roofMaskCache,trace:{...__roofTrace}})")
    add("rendering", "Roof mask cache populates and serves repeated hits in a cutaway scene", before["cache"] == 0 and after["cache"] > 0 and after["trace"]["hits"] > 0 and after["trace"]["hits"] > after["trace"]["misses"], {"before": before, "after": after, "scene": "player inside Civic Bank at (1425,1175)"})
    close_context(context)


def governance_checks(browser) -> None:
    context, page, errors = open_page(browser, "governance-economy")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;q.clearWelcome();
      const vote1=q.voteDecreeRaw('green');const vote2=q.voteDecreeRaw('green');
      const standard=q.businessQuote('cafe',1);q.setCivicFund(3000);const subsidyState=q.enactDecree('subsidy');const subsidy=q.businessQuote('cafe',1);
      q.setCash(999999);for(const id of ['cafe','clinic','garage','laundry']){q.buyBusiness(id);for(let i=0;i<3;i++)q.upgradeBusiness(id)}
      const tier4=q.getProgress().businesses;
      for(let i=0;i<3;i++)q.hireFleet();const fleet3=q.getProgress().fleet;
      q.advanceHours(12);const accrued=q.getProgress();const beforeCash=q.getState().cash;q.collectBusiness(null);const afterCash=q.getState().cash;
      q.setProsperity(90);const prosperity=q.governanceSnapshot();
      q.setCivicFund(3000);q.enactDecree('curfew');q.setTime(23);q.setHeat(1.25);q.step(1);const curfew=q.governanceSnapshot();const police=q.policeSnapshot();
      q.advanceHours(40);const expired=q.updateCivic();
      return {vote1,vote2,standard,subsidyState,subsidy,tier4,fleet3,accrued,beforeCash,afterCash,prosperity,curfew,police,expired};
    }""")
    add("governance-economy", "Resident vote contributes only once per town day", data["vote1"]["residentVotes"] == 1 and data["vote2"]["residentVotes"] == 1 and data["vote2"]["civicFund"] == data["vote1"]["civicFund"], {"first": data["vote1"], "second": data["vote2"]})
    add("governance-economy", "Infrastructure Subsidy lowers deed and upgrade costs", data["subsidy"]["deed"] < data["standard"]["deed"] and data["subsidy"]["upgrade"] < data["standard"]["upgrade"], {"standard": data["standard"], "subsidy": data["subsidy"], "governance": data["subsidyState"]})
    add("governance-economy", "All four commercial deeds reach Tier 4", all(v["owned"] and v["tier"] == 4 for v in data["tier4"].values()), {"businesses": data["tier4"]})
    add("governance-economy", "Commercial fleet expands to the bounded three-driver maximum", data["fleet3"]["drivers"] == 3 and data["fleet3"]["hired"], {"fleet": data["fleet3"]})
    add("governance-economy", "Businesses accrue passive dividends", all(v["stored"] > 0 for v in data["accrued"]["businesses"].values()), {"businesses": data["accrued"]["businesses"]})
    add("governance-economy", "NPC fleet completes automated supply runs", data["accrued"]["fleet"]["runs"] > 0 and data["accrued"]["fleet"]["stored"] > 0, {"fleet": data["accrued"]["fleet"]})
    add("governance-economy", "Dividend collection closes the cash loop", data["afterCash"] > data["beforeCash"], {"beforeCash": data["beforeCash"], "afterCash": data["afterCash"], "increase": data["afterCash"] - data["beforeCash"]})
    add("governance-economy", "High prosperity unlocks the Tier 3 fountain", data["prosperity"]["tier"] == 3, {"snapshot": data["prosperity"]})
    effect = data["curfew"]["effect"]
    add("governance-economy", "Curfew doubles lawful night rewards and adds patrol pressure", effect["nightCourierFactor"] == 2 and effect["nightPatrolBonus"] == 1, {"effect": effect, "governance": data["curfew"]["governance"]})
    add("governance-economy", "Curfew can deploy an additional interceptor", len(data["police"]["units"]) >= 2, {"unitCount": len(data["police"]["units"]), "snapshot": data["police"]})
    add("governance-economy", "Expired decree returns to Standard Charter", data["expired"]["effect"]["decree"] == "standard" and data["expired"]["governance"]["decree"] == "standard", {"snapshot": data["expired"]})
    close_context(context)


def operations_checks(browser) -> None:
    context, page, errors = open_page(browser, "operations")
    data = page.evaluate("""() => {
      const q=MBMTownLifeQA;q.clearWelcome();const cashBefore=q.getState().cash;q.openSafe();q.solveSafe();const afterSafe=q.getState();
      q.teleport(1600,1630);q.interact();const afterEscape=q.getProgress();
      q.startLaundering();const laundering=q.getProgress().laundering;q.collectLaundering();const afterConversion=q.getState();
      const covertStart=q.startCovert();const covertEnd=q.completeCovert();
      return {cashBefore,afterSafe,afterEscape,laundering,afterConversion,covertStart,covertEnd};
    }""")
    mission = data["afterSafe"].get("mission")
    add("operations", "Safe operation triggers alarm and escape stage", bool(mission and mission.get("stage") == "escape" and data["afterSafe"].get("bankAlarm")), {"mission": mission, "bankAlarm": data["afterSafe"].get("bankAlarm"), "heat": data["afterSafe"].get("heat")})
    add("operations", "Safe operation does not grant instant clean cash", data["afterSafe"]["cash"] == data["cashBefore"], {"beforeCash": data["cashBefore"], "afterCash": data["afterSafe"]["cash"], "dirtyBonds": data["afterSafe"].get("dirtyBonds")})
    add("operations", "Garage escape converts loot to fictional vault bonds", data["afterEscape"]["dirtyBonds"] > 0 and data["afterEscape"]["mission"] is None, {"progress": data["afterEscape"]})
    add("operations", "Washworks starts delayed bond conversion", bool(data["laundering"] and data["laundering"]["amount"] > 0 and data["laundering"]["readyAt"] > 0), {"laundering": data["laundering"]})
    add("operations", "Completed conversion pays cash and clears the batch", data["afterConversion"]["laundering"] is None and data["afterConversion"]["cash"] > data["cashBefore"], {"cash": data["afterConversion"]["cash"], "laundering": data["afterConversion"]["laundering"], "dirtyBonds": data["afterConversion"]["dirtyBonds"]})
    add("operations", "Sylvia affinity unlocks the multi-stage covert courier operation", data["covertStart"]["mission"] and data["covertStart"]["mission"]["type"] == "covert-courier" and data["covertStart"]["cargo"] and data["covertStart"]["cargo"]["covert"], {"start": data["covertStart"]})
    add("operations", "Covert delivery produces fictional bonds through the connected supply chain", data["covertEnd"]["mission"] is None and data["covertEnd"]["cargo"] is None and data["covertEnd"]["dirtyBonds"] > 0 and data["covertEnd"]["stats"]["smugglingRuns"] >= 1, {"completion": data["covertEnd"]})
    close_context(context)


def accessibility_checks(browser) -> None:
    context, page, errors = open_page(browser, "accessibility-desktop")
    page.evaluate("MBMTownLifeQA.clearWelcome();MBMTownLifeQA.setCash(999999);MBMTownLifeQA.claimPlot(1,'modern');MBMTownLifeQA.openUtility(1)")
    page.evaluate("new Promise(resolve=>requestAnimationFrame(()=>resolve()))")
    modal = page.evaluate("""() => {const m=document.getElementById('utilityModal');return {role:m.getAttribute('role'),modal:m.getAttribute('aria-modal'),hidden:m.getAttribute('aria-hidden'),display:getComputedStyle(m).display,focusTag:document.activeElement?.tagName||null,focusId:document.activeElement?.id||null,focusInside:m.contains(document.activeElement)}}""")
    add("accessibility", "Utility console exposes dialog semantics and receives focus", modal["role"] == "dialog" and modal["modal"] == "true" and modal["hidden"] == "false" and modal["focusInside"], {"modal": modal})
    trap_before = page.evaluate("""() => {const m=document.getElementById('utilityModal');const c=[...m.querySelectorAll('button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')].filter(e=>e.offsetParent!==null);c[c.length-1].focus();return {firstId:c[0].id,lastId:c[c.length-1].id,focusedId:document.activeElement.id,count:c.length}}""")
    page.keyboard.press("Tab")
    trap_after = page.evaluate("document.activeElement && document.activeElement.id")
    add("accessibility", "Keyboard focus remains trapped inside the active modal", trap_after == trap_before["firstId"], {"before": trap_before, "afterFocusedId": trap_after})
    page.keyboard.press("Escape")
    closed = page.evaluate("""() => {const m=document.getElementById('utilityModal');return {display:getComputedStyle(m).display,inlineDisplay:m.style.display,hidden:m.getAttribute('aria-hidden')}}""")
    add("accessibility", "Escape closes the utility modal", closed["inlineDisplay"] == "none" and closed["hidden"] == "true", {"afterEscape": closed})

    reduced = page.evaluate(r"""() => {
      const q=MBMTownLifeQA;const motion=document.getElementById('motionToggle'),contrast=document.getElementById('contrastToggle');motion.checked=true;motion.dispatchEvent(new Event('change',{bubbles:true}));contrast.checked=true;contrast.dispatchEvent(new Event('change',{bubbles:true}));
      q.setDriving({x:1400,y:1420,angle:0,vx:6,vy:2});const carBefore=q.getEntities().car;q.stepVehicle(1,{' ':true,d:true});q.step(1);const camera=q.cameraSnapshot();const carAfter=q.getEntities().car;
      q.claimPlot(1,'modern');q.teleport(400,360);const plot=q.getPlots()[0];
      return {state:q.getState(),camera,carBefore,carAfter,plot,bodyClass:document.body.className,sourceChecks:{addTrauma:/addTrauma\(amount\)\{if\(state\?\.reducedMotion/.test(document.scripts[0].textContent),effects:/const effects=state\.cameraEffects!==false&&!state\.reducedMotion/.test(document.scripts[0].textContent),look:/const look=effects&&isDriving/.test(document.scripts[0].textContent),zoom:/this\.targetZoom=effects&&isDriving/.test(document.scripts[0].textContent),follow:/const follow=effects\?\.085:1/.test(document.scripts[0].textContent),interior:/state\.reducedMotion\?target:lerp/.test(document.scripts[0].textContent)}};
    }""")
    add("accessibility", "Reduced motion and high contrast settings persist in state", reduced["state"]["reducedMotion"] and reduced["state"]["highContrast"] and "high-contrast" in reduced["bodyClass"], {"state": {"reducedMotion": reduced["state"]["reducedMotion"], "highContrast": reduced["state"]["highContrast"]}, "bodyClass": reduced["bodyClass"]})
    camera_detail = {
        "cameraTrauma": reduced["camera"]["trauma"],
        "cameraZoom": reduced["camera"]["zoom"],
        "cameraX": reduced["camera"]["x"],
        "carX": reduced["carAfter"]["x"],
        "lookAheadDelta": abs(reduced["camera"]["x"] - reduced["carAfter"]["x"]),
        "sourceChecks": reduced["sourceChecks"],
    }
    camera_pass = reduced["camera"]["trauma"] == 0 and abs(reduced["camera"]["zoom"] - 1) < 1e-9 and abs(reduced["camera"]["x"] - reduced["carAfter"]["x"]) < 1e-6 and all(reduced["sourceChecks"][k] for k in ("addTrauma", "effects", "look", "zoom", "follow"))
    add("accessibility", "Reduced motion short-circuits camera trauma, look-ahead, speed zoom and follow lerp", camera_pass, camera_detail)
    add("accessibility", "Reduced motion jumps interior roof alpha without interpolation", abs(reduced["plot"]["interiorAlpha"] - 0.02) < 1e-9 and reduced["sourceChecks"]["interior"], {"plotId": reduced["plot"]["id"], "interiorAlpha": reduced["plot"]["interiorAlpha"], "expectedImmediateTarget": 0.02, "sourceShortCircuitPresent": reduced["sourceChecks"]["interior"]})
    close_context(context)

    context, page, errors = open_page(browser, "accessibility-mobile", viewport={"width": 390, "height": 844}, mobile=True, touch=True)
    layout = page.evaluate("""() => {const visible=e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0};const candidates=[...document.querySelectorAll('button,a,[role=button],input,select')].filter(visible).map(e=>({tag:e.tagName,id:e.id,text:(e.textContent||e.value||'').trim().slice(0,40),height:e.getBoundingClientRect().height,width:e.getBoundingClientRect().width}));const undersized=candidates.filter(x=>x.height<44);return {innerWidth,scrollWidth:document.documentElement.scrollWidth,bodyScrollWidth:document.body.scrollWidth,mobileControls:getComputedStyle(document.getElementById('mobileControls')).display,pointerCoarse:matchMedia('(pointer: coarse)').matches,minHeight:Math.min(...candidates.map(x=>x.height)),undersized,candidateCount:candidates.length}}""")
    add("accessibility", "390px layout has no horizontal document overflow", layout["scrollWidth"] <= 390 and layout["bodyScrollWidth"] <= 390, {"layout": layout})
    add("accessibility", "Coarse-pointer mobile controls are enabled", layout["pointerCoarse"] and layout["mobileControls"] != "none", {"pointerCoarse": layout["pointerCoarse"], "mobileControlsDisplay": layout["mobileControls"]})
    add("accessibility", "Visible touch controls meet the 44px height floor", len(layout["undersized"]) == 0 and layout["minHeight"] >= 44, {"minimumVisibleControlHeight": layout["minHeight"], "undersized": layout["undersized"], "candidateCount": layout["candidateCount"]})
    close_context(context)


def storage_contract_run(browser, html: str, label: str) -> dict[str, Any]:
    authorised_write = {"mbm_town_life_v10", "__mbm_probe"}
    authorised_read = {"mbm_town_life_v10", *[f"mbm_town_life_v{i:02d}" for i in range(9, 0, -1)]}
    all_traces: dict[str, Any] = {}

    context, page, errors = open_page(browser, f"{label}-storage-boot", html=html, prelude=make_prelude("allow", "allow"))
    all_traces["boot"] = {"status": page.evaluate("window.__MBM_TOWN_LIFE_STATUS__"), "trace": page.evaluate("window.__storageTrace"), "stores": page.evaluate("window.__fakeStores")}
    close_context(context)

    context, page, errors = open_page(browser, f"{label}-storage-save", html=html, prelude=make_prelude("allow", "allow"))
    page.evaluate("""() => {document.getElementById('settingsName').value='Storage Trace';document.getElementById('saveNameBtn').click()}""")
    page.wait_for_timeout(400)
    all_traces["save"] = {"status": page.evaluate("window.__MBM_TOWN_LIFE_STATUS__"), "trace": page.evaluate("window.__storageTrace"), "stores": page.evaluate("window.__fakeStores")}
    saved_payload = all_traces["save"]["stores"]["local"].get("mbm_town_life_v10")
    close_context(context)

    context, page, errors = open_page(browser, f"{label}-storage-load", html=html, prelude=make_prelude("allow", "allow", {"mbm_town_life_v10": saved_payload or "{}"}))
    all_traces["load"] = {"status": page.evaluate("window.__MBM_TOWN_LIFE_STATUS__"), "state": page.evaluate("MBMTownLifeQA.getState()"), "trace": page.evaluate("window.__storageTrace"), "stores": page.evaluate("window.__fakeStores")}
    close_context(context)

    legacy_payload = json.dumps({"profile": "Legacy Trace", "cash": 777, "role": "Mayor", "plots": {"1": {"owner": "Legacy Trace", "house": "modern", "props": []}}})
    context, page, errors = open_page(browser, f"{label}-storage-legacy", html=html, prelude=make_prelude("allow", "allow", {"mbm_town_life_v01": legacy_payload}))
    all_traces["legacy"] = {"status": page.evaluate("window.__MBM_TOWN_LIFE_STATUS__"), "state": page.evaluate("MBMTownLifeQA.getState()"), "trace": page.evaluate("window.__storageTrace"), "stores": page.evaluate("window.__fakeStores")}
    close_context(context)

    touches = []
    for phase, block in all_traces.items():
        for item in block["trace"]:
            touches.append({"phase": phase, **item})
    written_or_removed = sorted({item["key"] for item in touches if item["method"] in ("setItem", "removeItem") and item.get("key") is not None})
    read = sorted({item["key"] for item in touches if item["method"] == "getItem" and item.get("key") is not None})
    return {
        "label": label,
        "loadingMethod": "Playwright page.set_content at about:blank?qa with instrumented fake Storage API; supplemental key-contract evidence only",
        "resolvedLocationOrigin": "null",
        "phases": all_traces,
        "sets": {"writtenOrRemoved": written_or_removed, "read": read},
        "expected": {"writtenOrRemoved": sorted(authorised_write), "read": sorted(authorised_read)},
        "passes": written_or_removed == sorted(authorised_write) and read == sorted(authorised_read),
        "savedPayloadUnicodeCharacters": len(saved_payload or ""),
    }


def hardening_and_storage_checks(browser) -> None:
    base_contract = storage_contract_run(browser, BASE_HTML, "BASE")
    candidate_contract = storage_contract_run(browser, HTML, "CANDIDATE")
    same_sets = base_contract["sets"] == candidate_contract["sets"]
    add("storage-contract", "BASE and candidate touch only the authorised read and write/remove key sets", base_contract["passes"] and candidate_contract["passes"] and same_sets, {"base": {"sets": base_contract["sets"], "expected": base_contract["expected"], "origin": base_contract["resolvedLocationOrigin"], "loadingMethod": base_contract["loadingMethod"]}, "candidate": {"sets": candidate_contract["sets"], "expected": candidate_contract["expected"], "origin": candidate_contract["resolvedLocationOrigin"], "loadingMethod": candidate_contract["loadingMethod"]}, "setsUnchanged": same_sets})

    # Persist full traces for the gate report.
    (ROOT / "qa" / "TL1_STORAGE_KEY_TRACE.json").write_text(json.dumps({"generatedAt": now_z(), "base": base_contract, "candidate": candidate_contract, "realOriginStatus": "UNPROVEN-ON-REAL-ORIGIN"}, indent=2) + "\n", encoding="utf-8")

    context, page, errors = open_page(browser, "hardening-local", prelude=make_prelude("allow", "allow"))
    local_status = page.evaluate("window.__MBM_TOWN_LIFE_STATUS__")
    add("hardening", "Available local storage selects local mode", local_status.get("storage") == "local", {"status": local_status, "trace": page.evaluate("window.__storageTrace")})
    close_context(context)

    context, page, errors = open_page(browser, "hardening-session", prelude=make_prelude("deny", "allow"))
    session_status = page.evaluate("window.__MBM_TOWN_LIFE_STATUS__")
    add("hardening", "Denied local storage falls back to session mode", session_status.get("storage") == "session", {"status": session_status, "trace": page.evaluate("window.__storageTrace")})
    close_context(context)

    context, page, errors = open_page(browser, "hardening-volatile", prelude=make_prelude("deny", "deny"))
    volatile = page.evaluate("({status:window.__MBM_TOWN_LIFE_STATUS__,badge:document.getElementById('saveState').textContent})")
    add("hardening", "Denied browser storage falls back to volatile memory", volatile["status"].get("storage") == "volatile" and "VOLATILE" in volatile["badge"], {"status": volatile["status"], "badge": volatile["badge"], "trace": page.evaluate("window.__storageTrace")})
    close_context(context)

    no_audio_prelude = make_prelude("allow", "allow") + "\nObject.defineProperty(window,'AudioContext',{configurable:true,value:undefined});Object.defineProperty(window,'webkitAudioContext',{configurable:true,value:undefined});"
    context, page, errors = open_page(browser, "hardening-no-audio", prelude=no_audio_prelude)
    audio_state = page.evaluate("({ready:__MBM_TOWN_LIFE_READY__,status:__MBM_TOWN_LIFE_STATUS__,audio:MBMTownLifeQA.getState().audio})")
    add("hardening", "Game remains playable when Web Audio is unavailable", audio_state["ready"] and audio_state["status"]["stage"] == "running", {"observed": audio_state, "pageErrors": errors})
    close_context(context)

    roundrect_prelude = make_prelude("allow", "allow") + "\ntry{delete CanvasRenderingContext2D.prototype.roundRect}catch(e){CanvasRenderingContext2D.prototype.roundRect=undefined}"
    context, page, errors = open_page(browser, "hardening-roundrect", prelude=roundrect_prelude)
    rr = page.evaluate("({type:typeof CanvasRenderingContext2D.prototype.roundRect,ready:__MBM_TOWN_LIFE_READY__})")
    add("hardening", "Canvas compatibility bridge restores roundRect", rr["type"] == "function" and rr["ready"], {"observed": rr})
    close_context(context)

    context, page, errors = open_page(browser, "hardening-malformed", prelude=make_prelude("allow", "allow", {"mbm_town_life_v10": "{broken"}))
    malformed = page.evaluate("({state:MBMTownLifeQA.getState(),status:__MBM_TOWN_LIFE_STATUS__})")
    add("hardening", "Malformed schema-10 save recovers to a fresh profile", malformed["state"]["profile"] == "Player" and malformed["state"]["schema"] == 10 and malformed["status"]["ready"], {"observed": malformed, "storageTrace": page.evaluate("window.__storageTrace")})
    close_context(context)

    # Explicit write and reload use the candidate contract payload already captured.
    save_phase = candidate_contract["phases"]["save"]
    load_phase = candidate_contract["phases"]["load"]
    payload = save_phase["stores"]["local"].get("mbm_town_life_v10", "")
    add("hardening", "Local save payload is written after explicit state changes", len(payload) > 1000 and any(item["method"] == "setItem" and item["key"] == "mbm_town_life_v10" for item in save_phase["trace"]), {"payloadUnicodeCharacters": len(payload), "trace": save_phase["trace"], "profileWritten": json.loads(payload).get("profile") if payload else None})
    add("hardening", "Saved profile restores in a fresh page context", load_phase["state"]["profile"] == "Storage Trace", {"restoredState": {"profile": load_phase["state"]["profile"], "role": load_phase["state"]["role"], "schema": load_phase["state"]["schema"]}, "trace": load_phase["trace"]})

    # Fatal recovery: this intentional page error is excluded from the one suite-level error assertion.
    context, page, errors = open_page(browser, "hardening-fatal", prelude=make_prelude("allow", "allow"), ignore_expected_errors=("QA_FATAL_RECOVERY",))
    page.evaluate("setTimeout(()=>{throw new Error('QA_FATAL_RECOVERY')},0)")
    page.wait_for_timeout(100)
    fatal = page.evaluate("({status:__MBM_TOWN_LIFE_STATUS__,ready:__MBM_TOWN_LIFE_READY__,display:getComputedStyle(document.getElementById('fatalOverlay')).display,text:document.getElementById('fatalMessage').textContent})")
    add("hardening", "Fatal errors fail readiness honestly and show recovery UI", fatal["ready"] is False and fatal["status"]["stage"] == "failed" and fatal["display"] == "grid" and "QA_FATAL_RECOVERY" in fatal["text"], {"observed": fatal, "expectedPageErrors": errors})
    close_context(context)


def main() -> None:
    static_checks()
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-gpu"])
        startup_checks(browser)
        powertrain_checks(browser)
        police_checks(browser)
        utility_checks(browser)
        cctv_checks(browser)
        context_and_roof_checks(browser)
        governance_checks(browser)
        operations_checks(browser)
        accessibility_checks(browser)
        hardening_and_storage_checks(browser)

        add("runtime", "No unexpected runtime or console errors across the executed browser suite", len(ALL_RUNTIME_ERRORS) == 0, {"unexpectedErrorCount": len(ALL_RUNTIME_ERRORS), "unexpectedErrors": ALL_RUNTIME_ERRORS, "pagesObserved": len(PAGE_METADATA)})

        # D3 is deliberately excluded from attempted assertion totals because no real-origin document committed.
        unexecuted("real-origin", "Hardening, startup and accessibility groups on file://", {"attemptedUrl": "file:///.../MBM_Town_Life_GOLD_v1_0.html?qa", "browserError": "net::ERR_BLOCKED_BY_ADMINISTRATOR", "resolvedOrigin": None, "reason": "Managed URLBlocklist [\"*\"] blocked navigation before document commit."})
        unexecuted("real-origin", "Hardening, startup and accessibility groups on http://127.0.0.1", {"attemptedOrigin": "http://127.0.0.1:18765", "browserError": "net::ERR_BLOCKED_BY_ADMINISTRATOR", "resolvedOrigin": None, "reason": "Managed URLBlocklist [\"*\"] blocked navigation before document commit."})

        names = [item["name"] for item in RESULTS]
        duplicates = sorted([name for name, count in Counter(names).items() if count > 1])
        empty_details = [item["name"] for item in RESULTS if not detail_ok(item.get("detail"))]
        passed = sum(1 for item in RESULTS if item["status"] == "PASS")
        failed = sum(1 for item in RESULTS if item["status"] == "FAIL")
        attempted = passed + failed
        report = {
            "generatedAt": now_z(),
            "version": "1.0.1",
            "schema": 10,
            "loadingMethod": "Playwright page.set_content at about:blank?qa for executed browser assertions; this is not real-origin evidence.",
            "environment": {
                "browser": subprocess.check_output(["/usr/bin/chromium", "--version"], text=True).strip(),
                "viewport": "1440x900 unless a check records another viewport",
                "headless": True,
                "softwareRenderingFlags": ["--disable-gpu"],
                "platform": platform.platform(),
            },
            "distinctAssertions": {"passed": passed, "attempted": attempted, "failed": failed, "uniqueNames": len(set(names)), "duplicateNames": duplicates, "emptyDetails": empty_details},
            "passed": passed,
            "attempted": attempted,
            "failed": failed,
            "results": RESULTS,
            "unexecuted": UNEXECUTED,
            "runtimeErrors": ALL_RUNTIME_ERRORS,
            "pages": PAGE_METADATA,
        }
        (ROOT / "qa" / "QA_SYSTEM_RESULTS.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

        hardening_names = {item["name"] for item in RESULTS if item["group"] in {"hardening", "storage-contract"}}
        hardening_results = [item for item in RESULTS if item["name"] in hardening_names]
        hardening = {
            "generatedAt": report["generatedAt"],
            "version": "1.0.1",
            "additiveToSuiteTotal": False,
            "note": "This is a filtered view of QA_SYSTEM_RESULTS.json. Do not add these counts to the distinct suite total.",
            "passed": sum(1 for item in hardening_results if item["status"] == "PASS"),
            "attempted": len(hardening_results),
            "failed": sum(1 for item in hardening_results if item["status"] == "FAIL"),
            "results": hardening_results,
            "realOriginStatus": "UNPROVEN-ON-REAL-ORIGIN",
            "realOriginNavigationAttempts": 2,
            "realOriginTestGroupsExecuted": 0,
        }
        (ROOT / "qa" / "PRODUCTION_HARDENING_RESULTS.json").write_text(json.dumps(hardening, indent=2) + "\n", encoding="utf-8")

        summary = {"passed": passed, "attempted": attempted, "failed": failed, "duplicates": duplicates, "emptyDetails": empty_details, "unexecuted": len(UNEXECUTED)}
        print(json.dumps(summary, indent=2))
        sys.stdout.flush()
        try:
            browser.close()
        except Exception:
            pass


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        failure = {"generatedAt": now_z(), "fatal": repr(exc), "traceback": traceback.format_exc(), "partialResults": RESULTS, "unexecuted": UNEXECUTED, "runtimeErrors": ALL_RUNTIME_ERRORS}
        (ROOT / "qa" / "TL1_QA_RUNNER_FAILURE.json").write_text(json.dumps(failure, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({"fatal": repr(exc)}, indent=2), file=sys.stderr)
        raise
