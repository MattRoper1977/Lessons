from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import json

ROOT=Path(__file__).resolve().parent.parent

def load(rel): return json.loads((ROOT/rel).read_text())

def yn(v): return 'PASS' if v else 'FAIL'

def fmt(v,n=2): return f'{v:.{n}f}'

def main():
    gates=load('qa/TL1_GATE_RESULTS.json')
    qa=load('qa/QA_SYSTEM_RESULTS.json')
    d1=load('_tl1/D1_HARNESS_REPAIR/D1_BEFORE_AFTER.json')
    d3=load('_tl1/D3_REAL_ORIGIN/D3_REAL_ORIGIN_RESULTS.json')
    d4=load('_tl1/D4_ROOF_MASK/D4_ROOF_MASK_RESULTS.json')
    d5=load('_tl1/D5_LEGACY_SAVE_PROVENANCE.json')
    storage=load('qa/TL1_STORAGE_KEY_TRACE.json')
    save=load('qa/TL1_SAVE_COMPATIBILITY.json')
    perf=load('qa/PERFORMANCE_PROFILE_GOLD.json')['tl1Recertification']
    phase2=load('_tl1/PHASE2_THROTTLED_PROXY/THROTTLED_PROXY_RESULTS.json')
    phase0=load('_tl1/PHASE0_BASELINE/PHASE0_MEASUREMENTS.json')
    html=gates['candidateHtml']
    d2=perf['d2Reproduction']
    now=datetime.now(timezone.utc).isoformat().replace('+00:00','Z')

    p0_rows=[
      ('B1','`sha256sum -c CHECKSUMS.sha256`','24/24 entries pass','24/24 entries passed','PASS'),
      ('B2','HTML size / ending','304,742 UTF-8 bytes; `</html>` + LF',f"{phase0['html']['utf8Bytes_wc_c']:,} UTF-8 bytes / {phase0['html']['unicodeCharacters_wc_m']:,} characters; expected ending present",'PASS'),
      ('B3','Script blocks','1',str(phase0['inlineScript']['blocks']),'PASS'),
      ('B4','Inline script size','265,585 UTF-8 bytes / 265,340 characters',f"{phase0['inlineScript']['utf8Bytes_wc_c']:,} UTF-8 bytes / {phase0['inlineScript']['unicodeCharacters_wc_m']:,} characters",'PASS'),
      ('B5','Inline script SHA-256','`5d8389e…93200`',f"`{phase0['inlineScript']['sha256']}`",'PASS'),
      ('B6','`node --check`','exit 0','exit 0','PASS'),
      ('B7','URL tokens','0','0 `http://`; 0 `https://`','PASS'),
      ('B8','HTML IDs','164, all unique','164 total / 164 unique / 0 duplicates','PASS'),
      ('B9','Viewport','exact required content; no restrictions',f"`{phase0['structure']['viewport_contents'][0]}`; maximum-scale 0; user-scalable=no 0",'PASS'),
      ('B10','Version / save schema','1.0.0 / 10','1.0.0 / 10','PASS'),
      ('B11','Storage key contract','2 write/remove; current + 9 legacy reads','measured statically at BASE and later by API instrumentation','PASS'),
    ]
    p0='\n'.join(f'| {a} | {b} | {c} | {d} | **{e}** |' for a,b,c,d,e in p0_rows)

    d2_rows=[]
    order=['auto','high','balanced','performance']
    for name in order:
      s=d2['summary'][name]; runs=d2['acceptedRunsFps'][name]
      d2_rows.append(f"| {name.title()} | {d2['packSingleRunFps'][name]:.2f} | {s['medianFps']:.2f} | {s['minFps']:.2f}–{s['maxFps']:.2f} (Δ {s['spreadFps']:.2f}) | "+', '.join(f'{x:.2f}' for x in runs)+' | N/A — no fix |')
    d2_table='\n'.join(d2_rows)

    origin_rows=[]
    for item in d3['ladder']:
      origin_rows.append(f"| {item['method']} | `{item['attemptedUrl']}` | no document commit | **none** | `{item['browserError']}` |")
    origin_rows += [
      '| BASE storage API instrumentation | `about:blank?qa` + injected content | executed | `null` | supplemental key-contract evidence only |',
      '| Candidate storage API instrumentation | `about:blank?qa` + injected content | executed | `null` | supplemental key-contract evidence only |',
      '| v1.0 → v1.0.1 save compatibility | `about:blank?qa` + injected content | executed | `null` | schema/data proof only |',
      '| Hardening storage fallbacks | `about:blank?qa` + injected content | executed | `null` | not a real-origin pass |',
    ]
    origins='\n'.join(origin_rows)

    legacy='\n'.join(f"| `{x['key']}` | **{x['verdict']}** | {'yes' if x['reachable'] else 'no'} | Generic field-compatible normaliser; no key-specific contract or genuine fixture |" for x in d5['perKey'])

    proxy_rows=[]
    for key in ['desktop1440_4x','desktop1440_6x','mobile390_4x','mobile390_6x']:
      x=phase2['scenarios'][key]; vp=f"{x['viewport']['width']}×{x['viewport']['height']}"
      proxy_rows.append(f"| {vp} | {'yes' if x['coarsePointerObserved'] else 'no'} | {x['cpuThrottlingRate']:.0f}× | {x['measurement']['frames']} | {x['measurement']['ms']:.1f} ms | **{x['measurement']['fps']:.2f} fps** | {x['finalAdaptiveBudget']['level']} |")
    proxies='\n'.join(proxy_rows)

    gate_rows=[]
    for key in [f'G{i}' for i in range(1,13)]:
      g=gates['gates'][key]
      m=g['measured']
      if key=='G1': value=f"node exit {m['exitCode']}"
      elif key=='G2': value=f"http {m['http://']}; https {m['https://']}"
      elif key=='G3': value=f"scripts {m['scriptBlocks']}; ending {m['endsHtmlWithExpectedLf']}; tag balance {m['tagBalance']}"
      elif key=='G4': value=f"{m['count']} IDs / {m['unique']} unique / {len(m['duplicates'])} duplicate"
      elif key=='G5': value=f"version {m['version']}; schema {m['schema']}"
      elif key=='G6': value=f"all {len(m['fields'])} compatibility comparison fields passed"
      elif key=='G7': value='camera trauma, drive look-ahead, speed zoom, follow lerp and interior alpha all short-circuited'
      elif key=='G8': value=f"write/remove {m['candidate']['writtenOrRemoved']}; read {m['candidate']['read']}"
      elif key=='G9': value=f"brand block byte-identical; SHA-256 `{m['brandBlockSha256']}`"
      elif key=='G10': value=f"`{m['candidate']}`; restrictive tokens 0"
      elif key=='G11': value=f"{len(m['records'])} changed/added records; 0 unauthorised; protected docs unchanged"
      else: value=f"exit {m.get('exitCode')}; {m.get('checkedEntries',0)} entries checked"
      gate_rows.append(f"| {key} | {g['name']} | **{yn(g['passes'])}** | {value} |")
    gates_table='\n'.join(gate_rows)

    file_rows=[]
    for r in gates['gates']['G11']['measured']['records']:
      plus=r['addedLines']; minus=r['deletedLines']
      file_rows.append(f"| `{r['path']}` | {r['status']} | +{plus} | −{minus} |")
    files='\n'.join(file_rows)

    written=storage['candidate']['sets']['writtenOrRemoved']
    read=storage['candidate']['sets']['read']
    open_items=[
      'Shipped `file://` startup, hardening, accessibility and storage behaviour: **UNPROVEN-ON-REAL-ORIGIN**.',
      'Loopback HTTP startup, hardening, accessibility and storage behaviour: **UNPROVEN-ON-REAL-ORIGIN**.',
      'Firefox execution: **UNEXECUTED**.',
      'Safari/WebKit execution: **UNEXECUTED**.',
      'Chromebook hardware: **UNEXECUTED**.',
      'Android hardware: **UNEXECUTED**.',
      'iOS hardware: **UNEXECUTED**.',
      'Physical low-power/thermal performance: **UNEXECUTED**; Phase 2 values are throttled proxies only.',
      'Human screen-reader, motor-access and cognitive-access evaluation: **UNEXECUTED**.',
      'Genuine earlier Town Life save artefacts for v0.9…v0.1: **UNAVAILABLE/UNPROVEN**; all migration verdicts remain PARTIAL.',
      'Adaptive-controller thrash/hysteresis instrumentation and a D2 code fix: **NOT EXECUTED BY RULE**, because the defect did not reproduce beyond run variance.',
    ]
    open_list='\n'.join(f'- {x}' for x in open_items)

    report=f'''# Town Life Gold v1.0.1 — TL-1 fix and recertification report

Generated: **{now}**  
Candidate status: **HELD — not published, not in a repository, no PR, no merge, no shelf/catalogue work**

## Overall result

The held candidate reports **{qa['passed']}/{qa['attempted']} distinct assertions passed/attempted** in executed injected Chromium contexts. Assertion names are unique; every attempted check has non-empty observed evidence; one suite-level runtime/console assertion recorded zero unexpected errors. The 10/10 hardening file is explicitly non-additive.

G1–G12 status at report generation: **{gates['passed']}/{gates['attempted']} passed**. D3 remains an explicit open real-origin gate even when the package-integrity gates are green.

No game design, balance, economy number, role permission, content name, Civic Bank flow, Washworks flow, Sylvia flow or Mischief behaviour was changed. No Git repository was created; required phase checkpoints are retained as `_tl1/` evidence artefacts instead of commits.

## Phase 0 — corrected BASE measurements

Byte counts below come from `wc -c` or `stat`. Character counts are labelled separately and come from UTF-8 `wc -m` or decoded Unicode length where applicable.

| Gate | Measurement | Expected | Measured | Result |
|---|---|---|---|---|
{p0}

BASE HTML SHA-256: `06beeed09d469ca621dd7d1ef7ecba24fd05a98f9a6a692b16fdb3dace21d15f`  
BASE inline-script SHA-256: `{phase0['inlineScript']['sha256']}`

## Candidate identity

- HTML: **{html['utf8Bytes']:,} UTF-8 bytes / {html['unicodeCharacters']:,} Unicode characters**; SHA-256 `{html['sha256']}`.
- Inline script: **{html['inlineScriptUtf8Bytes']:,} UTF-8 bytes / {html['inlineScriptUnicodeCharacters']:,} Unicode characters**; SHA-256 `{html['inlineScriptSha256']}`.
- Executable diff from BASE: two equal-length version-marker substitutions only (`1.0.0` → `1.0.1`).

## D1 — inflated assertion count

**Reproduced: YES. Fixed: YES.**

Before: 100 result records, 91 distinct names, 10 occurrences of `No runtime or console errors`, 13 empty/missing detail objects and a separately advertised 11-check hardening total. After: **99/99 distinct assertions passed/attempted**, 99 unique names, one suite-level runtime assertion, zero empty details and a 10/10 non-additive hardening view. Two real-origin groups are recorded separately as UNEXECUTED and excluded from the denominator.

The documentation sweep removed the old advertised aggregate and uses the single distinct total. Incidental digit sequences inside raw measurements, hashes or immutable BASE evidence are not assertion-count claims and were not corrupted to alter their bytes.

## D2 — Auto render budget

**Reproduced: NO. Fixed: NOT REQUIRED. Final status: NOT-A-DEFECT.**

The game ships with **Auto adaptive** as the default, initially at High (`forced = null`).

| Profile | Pack single run | Five-run median | Full accepted spread | Accepted run-order fps | After fix |
|---|---:|---:|---:|---|---|
{d2_table}

Auto median was **{d2['comparison']['autoMedianFps']:.2f} fps**. The slowest fixed median was **{d2['comparison']['slowestFixedProfile'].title()} at {d2['comparison']['slowestFixedMedianFps']:.2f} fps**. Auto was **{d2['comparison']['autoMinusSlowestFixedMedianFps']:+.2f} fps** relative to it. The much wider within-profile spreads show that the pack's one-run ordering did not reproduce as a stable Auto regression. Under Amendment E2, controller instrumentation and a code fix were skipped; therefore no mechanism is claimed and no after-fix dataset exists.

## D3 — no real-origin execution

**Reproduced: YES. Fixed: NO. Status: UNPROVEN-ON-REAL-ORIGIN.**

The existing pack used `page.set_content`, not a real origin. The authorised ladder was attempted and both browser navigations were blocked by managed Chromium `URLBlocklist: ["*"]` before document commit.

| Test | Route | Executed document | Exact resolved origin string | Result |
|---|---|---:|---|---|
{origins}

The loopback server was independently reachable and returned HTTP 200 with the correct 304,742-byte body. Because neither browser document committed, zero real-origin hardening/startup/accessibility/storage assertions executed and none were passed by substitution.

## D4 — roof-mask cache claim

**Reproduced: YES. Fixed: YES in the harness claim; rendering code unchanged.**

Opening snapshot: roof-mask cache **0**, roof-base cache **8**. Civic Bank cutaway: immediate cache 1; after 30 frames cache 11 with 21 hits; after 150 frames cache 11 with **142 hits**, 12 misses and 12 sets. Classification: **scene-dependent and actively read**. The repaired assertion now drives a cutaway scene and proves population plus repeated hits.

## D5 — legacy save provenance

**Runtime change: NO. Documentation correction: YES.**

| Legacy key | Verdict | Reachable | Basis |
|---|---|---:|---|
{legacy}

The migration assertion uses a **synthetic in-memory fixture** (`profile = Legacy`, `cash = 777`) through `MBMTownLifeQA.migrate`; it does not use a genuine earlier build/save artefact. It proves the generic code path, not an installed-base history. Release wording now describes a field-compatible bridge and discloses synthetic provenance.

## Storage key contract — BASE and candidate

API instrumentation covered boot, save, load and synthetic legacy migration in both builds.

- Keys written or removed at BASE: `{storage['base']['sets']['writtenOrRemoved']}`
- Keys written or removed at candidate: `{storage['candidate']['sets']['writtenOrRemoved']}`
- Keys read at BASE: `{storage['base']['sets']['read']}`
- Keys read at candidate: `{read}`
- Other keys observed: **none**
- Instrumentation origin: serialized `location.origin` **`null`** at `about:blank?qa`; supplemental only, not a D3 pass.

## Save compatibility proof

A v1.0 runtime wrote a schema-10 save, and a fresh v1.0.1 candidate loaded it. Profile `TL1 Compatibility`, Mayor role, claimed modern plot, five placed props, four Tier-4 businesses, three-driver fleet with nine runs, and the tested generator/solar/battery utility graph all survived exactly. The candidate retained schema 10 and updated runtime version to 1.0.1.

The first exploratory comparison is retained but rejected because active town time legitimately accrued income and consumed generator fuel between contexts. The accepted test freezes time and synchronises the utility timestamp before comparing preservation.

## Phase 2 — THROTTLED PROXIES, not devices

Each is one fresh Auto maximum-scene run after 240 warm-up frames, measuring 240 frames under CDP CPU throttling.

| Viewport | Coarse pointer observed | CPU throttle | Frames | Elapsed | Callback throughput | Final Auto budget |
|---|---:|---:|---:|---:|---:|---|
{proxies}

These numbers are constrained-browser proxies only. They are not Chromebook, Android, iOS or other physical-device measurements.

## Gates G1–G12

| Gate | Requirement | Result | Measured value |
|---|---|---:|---|
{gates_table}

## Files changed or added — line counts

Line counts compare the BASE package to the candidate. New evidence files have zero deleted lines. Binary values are labelled rather than invented.

| File | Status | Added | Deleted |
|---|---|---:|---:|
{files}

Protected files `ORIGINALITY_AND_SAFETY_NOTES.md` and `TECHNICAL_ARCHITECTURE.md` remain byte-identical to BASE. The executable HTML diff is confined to two equal-length version-marker substitutions.

## Honest assertion total

**{qa['passed']}/{qa['attempted']} distinct assertions passed/attempted.**  
Unexecuted real-origin groups are outside the attempted denominator. The hardening view is non-additive.

## Still UNPROVEN or UNEXECUTED

{open_list}

## Mischief editorial options

No Mischief-related change was made. `_tl1/MISCHIEF_OPTIONS.md` costs exactly O1–O4, identifies files/functions/line footprints, states saved-state risk and recommends nothing.

## Rollback

Delete `MBM_Town_Life_v1_0_1_CANDIDATE/` (and its ZIP); the original uploaded v1.0 ZIP remains byte-for-byte untouched.
'''
    report_path=ROOT/'VERIFICATION_REPORT.md'
    recert_path=ROOT/'_tl1'/'TL1_RECERTIFICATION_REPORT.md'
    report_path.write_text(report,encoding='utf-8')
    recert_path.write_text(report,encoding='utf-8')
    print(json.dumps({'reportLines':len(report.splitlines()),'reportUtf8Bytes':report_path.stat().st_size,'byteMeasurement':'stat','gatesPassed':gates['passed'],'gatesAttempted':gates['attempted']},indent=2))

if __name__=='__main__': main()
