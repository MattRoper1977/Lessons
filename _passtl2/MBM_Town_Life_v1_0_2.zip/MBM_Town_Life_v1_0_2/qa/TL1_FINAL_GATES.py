from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from difflib import ndiff
from hashlib import sha256
from html.parser import HTMLParser
from pathlib import Path
import json
import os
import re
import subprocess
import tempfile
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
SOURCE = Path('/mnt/data/TL1_RESUME_2026-08-18/source/MBM_Town_Life_GOLD_v1_0_2026-08-17')
HTML_PATH = ROOT / 'MBM_Town_Life_GOLD_v1_0.html'
BASE_HTML_PATH = SOURCE / 'MBM_Town_Life_GOLD_v1_0.html'
OUT = ROOT / 'qa' / 'TL1_GATE_RESULTS.json'

DOCS_ALLOWED = {
    'README.md', 'QUICK_START.txt', 'CHANGELOG.md', 'RELEASE_MANIFEST.json',
    'GOLD_MASTER_RELEASE_NOTES.md', 'VERIFICATION_REPORT.md',
    'BROWSER_COMPATIBILITY_REPORT.md', 'CHECKSUMS.sha256'
}


def text_numstat(a: Path | None, b: Path | None) -> tuple[int | str, int | str]:
    if a is None:
        try:
            return len(b.read_text(encoding='utf-8').splitlines()), 0
        except Exception:
            return 'binary', 'binary'
    if b is None:
        try:
            return 0, len(a.read_text(encoding='utf-8').splitlines())
        except Exception:
            return 'binary', 'binary'
    try:
        aa = a.read_text(encoding='utf-8').splitlines()
        bb = b.read_text(encoding='utf-8').splitlines()
    except Exception:
        return 'binary', 'binary'
    added = deleted = 0
    for line in ndiff(aa, bb):
        if line.startswith('+ '): added += 1
        elif line.startswith('- '): deleted += 1
    return added, deleted


class BalanceParser(HTMLParser):
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.opens: Counter[str] = Counter()
        self.closes: Counter[str] = Counter()
    def handle_starttag(self, tag, attrs): self.opens[tag.lower()] += 1
    def handle_endtag(self, tag): self.closes[tag.lower()] += 1


def script_from(html: str) -> tuple[list[str], str]:
    scripts = re.findall(r'<script\b[^>]*>(.*?)</script>', html, flags=re.I | re.S)
    return scripts, scripts[0] if len(scripts) == 1 else ''


def brand_block(html: str) -> str:
    start = html.index('<div id="brandBlock"')
    end = html.index('<div id="topbar"', start)
    return html[start:end]


def storage_sets() -> dict[str, Any]:
    data = json.loads((ROOT / 'qa' / 'TL1_STORAGE_KEY_TRACE.json').read_text())
    return {
        side: {
            'writtenOrRemoved': data[side]['sets']['writtenOrRemoved'],
            'read': data[side]['sets']['read'],
            'passes': data[side]['passes'],
            'resolvedLocationOrigin': data[side]['resolvedLocationOrigin'],
        }
        for side in ('base', 'candidate')
    }


def reduced_motion_evidence() -> dict[str, Any]:
    data = json.loads((ROOT / 'qa' / 'QA_SYSTEM_RESULTS.json').read_text())
    by_name = {r['name']: r for r in data['results']}
    primary = by_name['Reduced motion short-circuits camera trauma, look-ahead, speed zoom and follow lerp']
    interior = by_name['Reduced motion jumps interior roof alpha without interpolation']
    d = primary['detail']
    return {
        'cameraTrauma': {'observed': d['cameraTrauma'], 'passes': d['cameraTrauma'] == 0 and d['sourceChecks']['addTrauma'] and d['sourceChecks']['effects']},
        'driveLookAhead': {'observedDelta': d['lookAheadDelta'], 'passes': d['lookAheadDelta'] == 0 and d['sourceChecks']['look']},
        'speedZoom': {'observedZoom': d['cameraZoom'], 'passes': d['cameraZoom'] == 1 and d['sourceChecks']['zoom']},
        'followLerp': {'cameraX': d['cameraX'], 'carX': d['carX'], 'passes': d['cameraX'] == d['carX'] and d['sourceChecks']['follow']},
        'interiorAlpha': {'observed': interior['detail']['interiorAlpha'], 'expectedImmediateTarget': interior['detail']['expectedImmediateTarget'], 'passes': interior['pass'] and interior['detail']['sourceShortCircuitPresent']},
    }


def changed_files() -> dict[str, Any]:
    source_files = {p.relative_to(SOURCE).as_posix(): p for p in SOURCE.rglob('*') if p.is_file()}
    candidate_files = {p.relative_to(ROOT).as_posix(): p for p in ROOT.rglob('*') if p.is_file()}
    all_paths = sorted(set(source_files) | set(candidate_files))
    records = []
    violations = []
    for rel in all_paths:
        a = source_files.get(rel); b = candidate_files.get(rel)
        same = bool(a and b and a.read_bytes() == b.read_bytes())
        if same: continue
        status = 'modified' if a and b else 'added' if b else 'removed'
        added, deleted = text_numstat(a, b)
        allowed = (
            rel == 'MBM_Town_Life_GOLD_v1_0.html'
            or rel in DOCS_ALLOWED
            or rel.startswith('qa/')
            or rel.startswith('_tl1/')
        )
        rec = {'path': rel, 'status': status, 'addedLines': added, 'deletedLines': deleted, 'allowed': allowed}
        records.append(rec)
        if not allowed: violations.append(rec)
    unchanged_required = {}
    for rel in ('ORIGINALITY_AND_SAFETY_NOTES.md','TECHNICAL_ARCHITECTURE.md'):
        a=source_files.get(rel); b=candidate_files.get(rel)
        unchanged_required[rel] = bool(a and b and a.read_bytes()==b.read_bytes())
    return {'records': records, 'violations': violations, 'unchangedRequired': unchanged_required}


def checksum_gate() -> dict[str, Any]:
    checksum = ROOT / 'CHECKSUMS.sha256'
    if not checksum.exists():
        return {'passes': False, 'exitCode': None, 'stdout': '', 'stderr': 'CHECKSUMS.sha256 absent'}
    proc = subprocess.run(['sha256sum','-c','CHECKSUMS.sha256'],cwd=ROOT,text=True,capture_output=True)
    lines=[line for line in proc.stdout.splitlines() if line.strip()]
    return {'passes': proc.returncode == 0, 'exitCode': proc.returncode, 'checkedEntries': len(lines), 'stdout': proc.stdout, 'stderr': proc.stderr}


def main() -> int:
    html_bytes = HTML_PATH.read_bytes(); html = html_bytes.decode('utf-8')
    base_bytes = BASE_HTML_PATH.read_bytes(); base = base_bytes.decode('utf-8')
    scripts, script = script_from(html)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', suffix='.js', delete=False) as fh:
        fh.write(script); temp_js=Path(fh.name)
    script_utf8_bytes = temp_js.stat().st_size
    node = subprocess.run(['node','--check',str(temp_js)],text=True,capture_output=True)
    temp_js.unlink(missing_ok=True)

    parser=BalanceParser(); parser.feed(html); parser.close()
    differences={tag:parser.opens[tag]-parser.closes[tag] for tag in sorted(set(parser.opens)|set(parser.closes)) if tag not in parser.VOID and parser.opens[tag]!=parser.closes[tag]}
    tag_balance=sum(abs(v) for v in differences.values())
    ids=re.findall(r'\bid\s*=\s*["\']([^"\']+)["\']',html,flags=re.I)
    dupes=sorted(k for k,v in Counter(ids).items() if v>1)
    version=re.search(r"const\s+VERSION\s*=\s*'([^']+)'",html)
    schema=re.search(r'const\s+SCHEMA_VERSION\s*=\s*(\d+)',html)
    viewport=re.search(r'<meta\s+name=["\']viewport["\']\s+content=["\']([^"\']+)',html,re.I)
    base_viewport=re.search(r'<meta\s+name=["\']viewport["\']\s+content=["\']([^"\']+)',base,re.I)
    save=json.loads((ROOT/'qa'/'TL1_SAVE_COMPATIBILITY.json').read_text())
    storage=storage_sets(); motion=reduced_motion_evidence(); diffs=changed_files()
    brand=brand_block(html); base_brand=brand_block(base)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', suffix='.html', delete=False) as fh:
        fh.write(brand); brand_temp=Path(fh.name)
    brand_utf8_bytes=brand_temp.stat().st_size
    brand_temp.unlink(missing_ok=True)
    checksum=checksum_gate()

    gates={
        'G1': {'name':'node --check on inline script','passes':node.returncode==0,'measured':{'exitCode':node.returncode,'stdout':node.stdout,'stderr':node.stderr}},
        'G2': {'name':'zero runtime network URL tokens','passes':html.count('http://')==0 and html.count('https://')==0,'measured':{'http://':html.count('http://'),'https://':html.count('https://')}},
        'G3': {'name':'single script, HTML ending and tag balance','passes':len(scripts)==1 and html.endswith('</html>\n') and tag_balance==0,'measured':{'scriptBlocks':len(scripts),'endsHtmlWithExpectedLf':html.endswith('</html>\n'),'tagBalance':tag_balance,'tagDifferences':differences}},
        'G4': {'name':'unique HTML IDs','passes':len(ids)==164 and len(set(ids))==164 and not dupes,'measured':{'count':len(ids),'unique':len(set(ids)),'duplicates':dupes}},
        'G5': {'name':'candidate version 1.0.1 and schema 10','passes':bool(version and version.group(1)=='1.0.1' and schema and schema.group(1)=='10'),'measured':{'version':version.group(1) if version else None,'schema':int(schema.group(1)) if schema else None}},
        'G6': {'name':'v1.0 save compatibility','passes':bool(save.get('passed')),'measured':save.get('comparison')},
        'G7': {'name':'reduced-motion short circuits retained','passes':all(x['passes'] for x in motion.values()),'measured':motion},
        'G8': {'name':'storage key read/write sets unchanged','passes':storage['base']['passes'] and storage['candidate']['passes'] and storage['base']['writtenOrRemoved']==storage['candidate']['writtenOrRemoved'] and storage['base']['read']==storage['candidate']['read'],'measured':storage},
        'G9': {'name':'Made by Matt brand intact','passes':'Made by Matt' in html and brand==base_brand,'measured':{'madeByMattOccurrences':html.count('Made by Matt'),'brandBlockBytes':brand_utf8_bytes,'byteMeasurement':'stat on temporary UTF-8 brand block','brandBlockSha256':sha256(brand.encode()).hexdigest(),'baseBrandBlockSha256':sha256(base_brand.encode()).hexdigest(),'byteIdentical':brand==base_brand}},
        'G10': {'name':'viewport byte-identical to BASE','passes':bool(viewport and base_viewport and viewport.group(1)==base_viewport.group(1)=='width=device-width, initial-scale=1, viewport-fit=cover'),'measured':{'base':base_viewport.group(1) if base_viewport else None,'candidate':viewport.group(1) if viewport else None,'maximumScaleOccurrences':html.lower().count('maximum-scale'),'userScalableNoOccurrences':html.lower().count('user-scalable=no')}},
        'G11': {'name':'diff confined to authorised files','passes':not diffs['violations'] and all(diffs['unchangedRequired'].values()),'measured':diffs},
        'G12': {'name':'fresh package checksums verify','passes':checksum['passes'],'measured':checksum},
    }
    result={
        'generatedAt':datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
        'candidateHtml':{'utf8Bytes':HTML_PATH.stat().st_size,'byteMeasurement':'stat','unicodeCharacters':len(html),'sha256':sha256(html_bytes).hexdigest(),'inlineScriptUtf8Bytes':script_utf8_bytes,'inlineScriptByteMeasurement':'stat on temporary extracted script','inlineScriptUnicodeCharacters':len(script),'inlineScriptSha256':sha256(script.encode()).hexdigest()},
        'gates':gates,
        'passed':sum(1 for g in gates.values() if g['passes']),
        'attempted':len(gates),
        'failed':[key for key,g in gates.items() if not g['passes']],
    }
    OUT.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'passed':result['passed'],'attempted':result['attempted'],'failed':result['failed'],'output':str(OUT)},indent=2))
    return 0 if not result['failed'] else 1

if __name__=='__main__':
    raise SystemExit(main())
