# Town Life Gold Master v1.0.1 recertification candidate notes

Town Life remains the connected v1.0 simulation: home electrical grids power devices and CCTV; contextual traffic and police respond to the world; governance changes patrol, solar, business costs and yield; businesses, fleets and prosperity form one long-term economy.

TL-1 changed the release evidence rather than the game design:

- the executable version marker is now `1.0.1`, while save schema remains `10`;
- the repaired harness reports **99/99 distinct assertions passed/attempted**, with one suite-level runtime probe, unique names and non-empty observed evidence on every attempted check;
- the hardening report is a **10/10 non-additive filtered view**, not a second total;
- five-run profile reproduction closed D2 as **NOT-A-DEFECT outside run variance**: Auto median 55.08 fps, slowest fixed median 57.13 fps, while Auto’s full 52.78–56.84-fps spread overlapped every fixed-profile spread;
- the roof-mask cache was proved scene-dependent and active: 0 opening entries, 11 Civic Bank cutaway entries and 142 settled cache hits;
- the generic legacy bridge reaches keys v0.9 through v0.1, but every key is `PARTIAL` by provenance because no version-specific contract or genuine earlier save artefact is packaged; the QA fixture is synthetic;
- a v1.0 runtime save retained profile, role, plot, businesses, fleet and utility graph when loaded by v1.0.1;
- 4× and 6× CPU-throttled maximum-scene figures were added as **proxies**, never device measurements.

Managed Chromium blocked both the shipped `file:///` path and authorised loopback HTTP with `net::ERR_BLOCKED_BY_ADMINISTRATOR` before document commit. Real-origin storage, startup and accessibility therefore remain **UNPROVEN-ON-REAL-ORIGIN**. Firefox, WebKit, Chromebook, Android and iOS remain unexecuted.

No role, name, content, economy value, vehicle tuning, utility behaviour, business rule, Civic Bank flow, Washworks flow, Sylvia flow or Mischief behaviour changed. The candidate is held and unpublished.
